<template>
	<view>
		<view class="status_bar1">
			<!-- 这里是状态栏 -->
		</view>
		<view class="status_bar">
			<!-- 这里是状态栏 -->
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="less" scoped>
.status_bar {
		height: var(--status-bar-height);
		width: 100%;
		background: #176CDC;
		position: fixed;
		top: 0;
		z-index: 999999;
	}

	.status_bar1 {
		height: var(--status-bar-height);
		width: 100%;
		z-index: 99999999;
	}
</style>
