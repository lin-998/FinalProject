<template>
	<view>
		<!-- <select :style="'width:'+width" class="select" v-model="ProductActive" @change="changeClick">
			<option v-for="(item) in datalist" :key="item.id" :value='item.id'>{{item.value}}</option>
			<option value="">123</option>
		</select> -->
		<view :style="'width:'+width" class="select" @click="selectShow">
			<view class="v-mode" :style="!ProductActive?'color:#aaa':''">{{ProductActive||placeholder}}</view>
			<view :style="'width:'+width" v-show="selects" class="option">
				<view @click="changeClick(index)" v-for="(item,index) in datalist" :key="index">{{item.label}}</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		props: ['width', 'datalist', 'placeholder', 'selectIs'],
		data() {
			return {
				ProductActive: "",
				selects:false,
				num:0,
			};
		},
		watch: {
			selectIs(newValue, oldValue) {
				this.selects=false
				console.log("sad")
			}
	},
	methods: {
			selectShow() {
				setTimeout(()=>{
					if(this.num===0){
						this.selects=true;
						this.num=1
					}else{
						this.selects=false;
						this.num=0
					}
				},0)
			},
			changeClick(index) {
				// console.log(index);
				this.ProductActive = this.datalist[index].value
				this.$emit('change', this.datalist[index])

			},
			changebtn(item) {
				// console.log(item);
			}
		},
		onLoad() {
			this.$set(this.iSselect)
		}
	}
</script>

<style lang="scss">
	.select {
		font-size: 24rpx;
		font-weight: 400rpx;
		background-color: #fff;
		height: 60rpx;
		line-height: 60rpx;
		padding-left: 10rpx;
		position: relative;
		color: rgba(16, 16, 16, 1);
		font-size: 14px;
		border: 1px solid rgba(187, 187, 187, 1);
		border-radius: 10rpx;

		&::after {
			content: ">";
			position: absolute;
			right: -20rpx;
			top: 30rpx;
			transform: rotate(90deg);
			width: 14px;
			height: 8px;
			color: #888;
			font-weight: 1000;
		}

		.option {
			font-size: 24rpx;
			left: -2rpx;
			top: 56rpx;
			border: 1rpx solid #ccc;
			position: absolute;
			background: #fff;
			z-index: 99;
			border-radius:10rpx 10rpx 10rpx 10rpx;
			view {
				padding-left: 10rpx;

				&:hover {
					background: skyblue;

				}
			}
		}

		// &:active{
		// 	border-style: rgba(187, 187, 187, 1);;
		// }
	}
</style>
