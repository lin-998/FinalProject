<template>
	<view>
		<view class="upload">
			<view class="bounceIn" v-for="(Img,index) in imgUrl" :key='index'>
				<image class="animated" v-if="imgUrl.length" :src="Img" mode="widthFix"
				 @click="previewImage(index)">
				 </image>
				 <view v-if="imgUrl.length" class="img-icon" @click="unImg(index)">
				 	<u-icon name="close-circle" color="#ccc" size="50"></u-icon>
				 </view>
			</view>
			<view class="upload-img" @click="uploadImg">
				<uni-icons color="#333" type="plusempty" size="30"></uni-icons>
				<view class="upload-text">
					点击添加图片
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import uniIcons from "@/components/uni-icons/uni-icons.vue"
	export default {
		components: {
			uniIcons
		},
		data() {
			return {
				imgUrl: []
			};
		},
		methods: {
			unImg(index){
				this.imgUrl.splice(index,1);
			},
			uploadImg() {
				uni.chooseImage({
					count: 6, //默认9
					sizeType: ['original'], //可以指定是原图还是压缩图，默认二者都有
					success: res => {
						this.imgUrl = [...this.imgUrl, ...res.tempFilePaths];
						uni.uploadFile({
							// url: 'https://demo.hcoder.net/index.php?c=uperTest',
							filePath: this.imgUrl[0],
							name: 'file',
							formData: {
								'user': 'test'
							},
							success: (uploadFileRes) => {
								console.log(uploadFileRes.data);
							}
						});
					}
				});
			},
			previewImage(index) {
				uni.previewImage({
					current: index,
					urls: this.imgUrl,
					indicator: 'number',
					longPressActions: {
						itemList: ['保存图片'],
						success: function(data) {
							console.log('保存成功');
						},
						fail: function(err) {
							console.log(err.errMsg);
						}
					}
				});
			}
		}
	}
</script>

<style lang="less" scoped>
	.bounceIn{
		margin-right: 15rpx;
		margin-top: 15rpx;
		position: relative;
		.img-icon{
			position: absolute;
			right: -15rpx;
			top: -15rpx;
		}
	}
	.upload {
		// margin-top: 400rpx;
		display: flex;
		flex-wrap: wrap;
		align-items: center;

		// justify-content:space-between;
		image {
			width: 240rpx;
		}
	}

	.upload-img {
		width: 240rpx;
		height: 240rpx;
		box-sizing: border-box;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		border: 1rpx solid #eee;
		border-radius: 10rpx;

		.upload-text {
			margin-top: 40rpx;
			font-size: 24rpx;
			color: #ccc;
		}

		.uni-icons {
			font-size: 48rpx !important;
		}
	}
</style>
