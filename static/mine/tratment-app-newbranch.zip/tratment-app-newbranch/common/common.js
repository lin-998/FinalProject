export const Utils = new class {
    toast(msg) {
        uni.showToast({
            title: msg,
            position: "bottom",
            duration: 2000,
            icon: "none",
        });
    }
}