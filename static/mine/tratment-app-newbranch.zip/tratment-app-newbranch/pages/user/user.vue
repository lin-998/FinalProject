<template>
	<view>
		<view class="status_bar">
			<!-- 这里是状态栏 -->
		</view>
		<view class="user-top">
			<view class="user-cart">
				<image src="../../static/image/ico_gwc.png" mode="widthFix" @click="toProduct"></image>
			</view>
			<view class="user-info">
				<image src="../../static/image/touxiang.png" mode="widthFix"></image>
				<text>{{user}}</text>
				<view v-if="role=='分销商复核人员'" class="review" @click="toreviwe">我要复核</view>
			</view>
		</view>
		<view class="user-center">
			<view class="center-in">
				<view class="my-order">
					
					<text>我的订单</text>
					<navigator @click="myOrder()">
						<text>查看全部订单</text><u-icon name="arrow-right"></u-icon>
					</navigator>
				</view>
				<view class="order-status">
					<view class="order-process" @click="toOrder(1)">
						<!-- <u-badge :is-center="true" style="right:35rpx" count="122"></u-badge> -->
						<image src="/static/image/wd_ico_dfk.png"></image>
						<text>待复核</text>
					</view>
					<view class="order-process" @click="toOrder(2)">
						<!-- <u-badge  :is-center="true"  count="6" style="right:35rpx"></u-badge> -->
						<image src="/static/image/wd_ico_dfh.png"></image>
						<text>待发货</text>
					</view>
					<view class="order-process" @click="toOrder(3)">
						<image src="/static/image/wd_ico_psz.png"></image>
						<text>配送中</text>
					</view>
					<view class="order-process" @click="toOrder(4)">
						<image src="/static/image/wd_ico_dsh.png"></image>
						<text>已完成</text>
					</view>
					<view class="order-process" @click="toOrder(5)">
						<image src="/static/image/wd_ico_thd.png"></image>
						<text>退货单</text>
					</view>
				</view>
			</view>
		</view>
		<view class="user-bottom">
			<button type="primary" plain @click="unlogin">退出登录</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				user:"",
				image:"",
				role:''
			};
		},
		onLoad() {
			let userInfo=uni.getStorageSync("userInfo")
			this.user=userInfo.username?userInfo.username:"游客",
			this.role=uni.getStorageSync("userInfo")?uni.getStorageSync("userInfo").roles[0].roleName:"游客"
		},
		methods: {
			// 退出登录
			unlogin() {
				let loginInfo=uni.getStorageSync("loginInfo")
				uni.clearStorageSync()
				uni.setStorageSync("loginInfo",loginInfo);
				console.log(loginInfo)
				uni.redirectTo({
					url: "../login/login?type=1"
				})
			},
			myOrder(){
				let user=uni.getStorageSync("userInfo")?uni.getStorageSync("userInfo").roles[0].roleName:"游客"
				if(user=="游客"||user=="会员商家"){
					this.toast("没有权限访问,请联系管理员∩_∩")
					return
				}
				uni.navigateTo({
					url:"/pages/user/myorder/myorder?current=0"
				})
			},
			// 复核人员去复核订单
			toreviwe(){
				let user=uni.getStorageSync("userInfo")?uni.getStorageSync("userInfo").roles[0].roleName:"游客"
				if(user!="分销商复核人员"){
					this.toast("没有复核人权限访问,请联系管理员∩_∩")
					return
				}
				uni.navigateTo({
					url:"../user/review/review?current=0"
				})
			},
			// 查看全部订单
			toProduct(){
				let user=uni.getStorageSync("userInfo")?uni.getStorageSync("userInfo").roles[0].roleName:"游客"
				if(user=="游客"||user=="会员商家"){
					this.toast("没有权限访问,请联系管理员∩_∩")
					return
				}
				uni.navigateTo({
					url:'/pages/index/Products/Products'
				})
			},
			// 点击不同订单状态
			toOrder(i) {
				let user=uni.getStorageSync("userInfo")?uni.getStorageSync("userInfo").roles[0].roleName:"游客"
				if(user=="游客"||user=="会员商家"){
					this.toast("没有权限访问,请联系管理员∩_∩")
					return
				}
				if(i==5){
					uni.navigateTo({
						url:'/pages/user/returnorder/returnorder'
					})
				}else{
					uni.navigateTo({
						url: "/pages/user/myorder/myorder?current=" + i
					})
				}
			}
		}
	}
</script>

<style lang="scss">
	.status_bar {
		height: var(--status-bar-height);
		width: 100%;
	}

	.user-top {
		position: relative;
		height: 320rpx;
		background: #176CDC;
		overflow: hidden;
		color: #FFFFFF;

		.user-cart {
			position: absolute;
					top: 30rpx;
					right: 40rpx;
					width: 50rpx;
					height: 50rpx;
					image{
						width: 100%;
					}
		}

		.user-info {
			display: flex;
			align-items: center;
			margin: 50rpx 0 0 50rpx;

			image {
				width: 110rpx;
				margin-right: 40rpx;
			}

			text {
				font-size: 36rpx;
				// font-weight: 600;
			}
			.review{
				margin-left: 40rpx;
				padding: 5rpx 30rpx;
				border: 1rpx solid #FFFFFF;
				border-radius: 50rpx;
				letter-spacing: 2rpx;
			}
		}
	}

	.user-center {
		position: relative;
		top: -80rpx;
		left: 0;
		width: 100%;
		padding: 0 20rpx;
		box-sizing: border-box;

		.center-in {
			// height: 400rpx;
			padding-bottom: 40rpx;
			background: #fff;
			border-radius: 20rpx 20rpx 0 0;

			.my-order {
				font-size: 32rpx;
				display: flex;
				height: 80rpx;
				justify-content: space-between;
				padding: 20rpx 30rpx;
				border-bottom: 2rpx solid #DDDDDD;
				font-weight: 600;
				navigator {
					font-size: 24rpx;
					color: #aaa;
					font-weight: 500;
				}

			}

			.order-status {
				margin-top: 32rpx;
				display: flex;
				justify-content: center;

				.order-process {
					display: flex;
					flex-direction: column;
					align-items: center;
					position: relative;
					flex: 1;
					font-size: 26rpx;
					color: #333333;
					image {
						width: 50rpx;
						height: 50rpx;
						margin-bottom: 20rpx;
					}

				}
			}
		}
	}

	.user-bottom {
		position: absolute;
		bottom: 40rpx;
		width: 100vw;
		padding: 0 20rpx;
		box-sizing: border-box;

		// margin: 0 20rpx;
		button {
			font-size: 28rpx;
			border-radius: 40rpx;
		}
	}
</style>
