<template>
	<view style="padding-bottom: 50rpx;">
		<!-- 退货申请 -->
		<view class="form-data" style="margin-bottom: 100rpx;padding-top: 30rpx;">
			<text class="title">退货商品</text>
			<u-form :border-bottom="false" :model="form">
				<!-- 备注图片 -->
				<u-form-item :border-bottom="false" label-width="140rpx" label="实拍图片:" class="form-item" label-align="right" style="border-width: 0;">
					<image v-for="url in baseData.medicalOrderAttachments" 
					:src="url.attachmentUrl" class="remarkimg" @click="previewImg(url.attachmentUrl)"></image>
				</u-form-item>
				<u-form-item :border-bottom="false" label-width="140rpx" label="退货备注:" prop="name" class="form-item" label-align="right">
					<u-input style="width: 200rpx;" type="textarea" border="" disabled placeholder="无" v-model="baseData.remark" />
				</u-form-item>
				<view class="way">
					处理方式:自送
				</view>
				<!-- 退货商品 -->
				<view class="goods-detail">
					<text class="good-title">订单信息</text>
					<view class="good-base" style="padding-left: 60rpx;">
						<view>订单编号:{{baseData.coding}}</view>
						<view>创建时间:{{baseData.createTime}}</view>
						<view>联系人:{{baseData.contact}}&nbsp&nbsp{{baseData.phone}}</view>
					</view>
					<view class="good-list" v-for="shop in shoppes">
						<view class="title">
							<text>
							{{shop.name}}
							<text v-if="!shop.specificationsParam" style="font-size: 20rpx;color: #999999;">({{shop.specificationsName}}||{{shop.specificationsValue}})</text>
							<text v-if="shop.specificationsParam" style="font-size: 20rpx;color: #999999;">({{shop.specificationsParam}})</text>
							</text>
							<text style="font-size: 24rpx;color: #999;">已下单{{shop.goodsCount}}件</text>
						</view>
						<view class="number-bar">
							X{{shop.count}}
							<!-- <u-number-box disabled v-model="shop.count" :min="0" :max="shop.max" @change="" class="number"></u-number-box> -->
						</view>
					</view>
				</view>
			</u-form>
		</view>
		<view style="text-align: center;" class="btn">
			<view style="background-color: #007AFF;" v-if="status==1" class="submit-btn" @click="confirmOrder()">确定</view>
			<view style="background-color: #007AFF;" v-if="status==2&&type==1" class="submit-btn" @click="confirmReview()">确定</view>
		</view>
		<u-toast ref="uToast" />
	</view>
</template>

<script>
	import {
		getbsaereturnorderinfo,
		getreturnordershopinfo,
		checkreturnorder,
		confirmRollBack,
		reviewRollBack
	} from '@/util/request.js'
	export default {
		data() {
			return {
				reject:"",
				fileList:[],
				attIds:[],
				selectis:false,
				addressVal:'',
				selecValue: '',
				form: {},
				value: 2,
				textareaVal: '',
				shoppes:'',
				baseData:{},
				id:'',
				type:0,
				status:0,
				selValue:"自提",
				selList:[
					{text:"自提",value:0},
					{text:"物流",value:1}
				]
			}
		},
		onLoad(option) {
			// 获取商品基本信息
			this.id=option.id
			this.status=option.status
			this.type=option.type
			this.init()
		},
		methods: {
			init(){
				getbsaereturnorderinfo({id:this.id}).then(res=>{
					if(res.code===200){
						console.log(res.data)
						this.baseData=res.data
						
					}
				})
				getreturnordershopinfo({id:this.id}).then(res=>{
					if(res.code===200){
						let arr=res.data[0].medicalRoolBackOrderDtoList
						arr.forEach(val=>{
							val.max=val.count
						})
						this.status=res.data[0].status
						this.shoppes=arr
				}
				})
			},
			confirmReview(){
				let self=this
				uni.showModal({
					content:"是否确定复核该退货单?",
					success: function (res) {
								if (res.confirm) {
										reviewRollBack({rollBackId:self.id}).then(res=>{
											if(res.code==200){
												self.init()
												self.toast("已复核该退货单")
											}
										})
								} else if (res.cancel) {
										self.toast("已取消")
								}
						}
				})
			},
			confirmOrder(){
				let self=this
				uni.showModal({
					content:"是否确定退货单?",
					success: function (res) {
								if (res.confirm) {
										confirmRollBack({rollBackId:self.id}).then(res=>{
											if(res.code==200){
												self.init()
												self.toast("已确定退货单")
											}
										})
								} else if (res.cancel) {
										self.toast("已取消")
								}
						}
				})
			},
			previewImg(logourl) {
				let _this = this;
				let imgsArray = [];
				imgsArray[0] = logourl
				uni.previewImage({
					current: 0,
					urls: imgsArray
				});
			},
			check(status){
				checkreturnorder({id:this.id,status:status}).then(res=>{
					if(res.code===200){
						uni.navigateTo({
							url:'/pages/user/review/review?current=4',
							fail(){
								uni.switchTab({
								    url: '/pages/user/review/review?current=4'
								});
							}
						})
					}
				})
			},
			toReject(status){
				let self=this
				uni.showModal({
						content: '是否驳回订单',
						success: function (res) {
								if (res.confirm) {
										checkreturnorder({id:self.id,status:status,reject:self.reject}).then(res=>{
											if(res.code===200){
												uni.navigateTo({
													url:'/pages/user/review/review?current=4',
													fail(){
														uni.switchTab({
														    url: '/pages/user/review/review?current=4'
														});
													}
												})
											}
										})
								} else if (res.cancel) {
										console.log('用户点击取消');
								}
						}
				});
			}
				
			}
	}
</script>

<style lang="scss">
	// 3
	.data-list {
		display: flex;
		align-items: center;
		justify-content: space-between;
		width: 100%;
		.title {
			font-size: 32rpx;
			text{
				display: block;
				height: 48rpx;
			}
		}
		.number-bar{
			text{
				border: 1rpx solid #ccc;
				text-align: center;
				display: inline-block;
				width: 48rpx;
				height: 48rpx;
				line-height: 48rpx;
				background-color: #fff;
			}
		}
	}
	.form-data {
		// background-color: #FFFFFF;
		// padding: 0rpx 30rpx;
		.way{
			margin-bottom: 20rpx;
			text-align: right;
			margin-right: 30rpx;
		}
		.title{
			font-size: 36rpx;
			letter-spacing: 2rpx;
			font-weight: bold;
			margin-left: 30rpx;
		}
		.form-item{
			padding:30rpx 0 ;
			padding: 30rpx 30rpx;
			// border-bottom: 1rpx solid #DDDDDD;
			.form-input{
				width: 421rpx;
				background: #FAFAFA;
				border: 1rpx solid #DDDDDD;
				border-radius: 10rpx;
			}
		}
		.text-area {
			border: 1rpx solid #ccc;
			position: relative;

			.text-max {
				color: #888;
				font-size: 24rpx;
				position: absolute;
				bottom: 0;
				right: 30rpx;
			}

			textarea {
				width: 396rpx;
				height: 150rpx;
				font-size: 28rpx;
				padding: 10rpx;
				box-sizing: border-box;
			}
		}
		}
		
		// 选择退货商品
	.goods-detail{
		border-top: 2rpx solid #CCCCCC;
		.good-title{
			display: block;
			padding-top: 30rpx;
			font-size: 36rpx;
			letter-spacing: 2rpx;
			font-weight: bold;
			margin-left: 30rpx;
		}
		.good-list{
			display: flex;
			padding:20rpx 30rpx;
			.title{
				flex: 1;
				display: flex;
				flex-direction: column;
				text{
					flex: 1;
				}
			}
			.number-bar{
				flex: 1;
				text-align: right;
				align-self: center;
			}
		}
	}
	// 订单信息
	.order{
		width: 100%;
		box-sizing: border-box;
		.title{
			font-size: 29rpx;
			font-weight: bold;
			padding-bottom: 28rpx;
		}
		.content{
			display: flex;
			.order-main{
				flex:2;
				font-size: 24rpx;
				display: flex;
				flex-direction: column;
				justify-content: space-between;
				view{
					flex:1;
					margin-bottom: 10rpx;
					font-size: 24rpx;
					text{
						display: inline-block;
						vertical-align: top;
					}
					image{
						width: 120rpx;
						height: 121rpx;
					}
				}
			}
			.info-btn{
				flex:1;
				text-align: right;
				.btn{
					display: inline-block;
					width: 110rpx;
					height: 38rpx;
					border: 1rpx solid #176CDC;
					border-radius: 100rpx;
					text-align: center;
					line-height: 38rpx;
					font-size: 24rpx;
					color: #176CDC;
				}
			}
		}	
	}
	.btn{
		// position: fixed;
		// bottom: 200rpx;
		margin-top: 100rpx;
		height: 100rpx;
		width: 100%;
		margin:0 auto;
		line-height: 100rpx;
		.submit-btn{
			display: inline-block;
			width: 600rpx;
			height: 88rpx;
			background: #CCCCCC;
			border-radius: 44rpx;
			text-align: center;
			line-height: 88rpx;
			font-size: 32rpx;
			color: #FFFFFF;
		}
	}
	.remarkimg{
		width:140rpx;
		height: 140rpx;
		margin-right: 20rpx;
	}
	.btn-content{
		position: fixed;
		bottom: 0rpx;
		height: 100rpx;
		width: 100%;
		margin:0 auto;
		line-height: 100rpx;
		display: flex;
		.but{
			flex:1;
			text-align: center;
			view{
				display: inline-block;
				width: 250rpx;
				height: 66rpx;
				background: #CCCCCC;
				border-radius: 44rpx;
				text-align: center;
				line-height:66rpx;
				font-size: 32rpx;
				color: #FFFFFF;
				text-align: center;
			}
		}
	}
	.text-area {
		border: 1rpx solid #ccc;
		padding: 10rpx;
		box-sizing: border-box;
		width: 540rpx;
		height: 170rpx;
		background: #FAFAFA;
		border: 1rpx solid #DDDDDD;
		opacity: 1;
		border-radius: 10rpx;
		color: red;
	}
</style>
