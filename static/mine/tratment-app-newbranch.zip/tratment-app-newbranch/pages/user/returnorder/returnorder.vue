<template>
	<!-- 退货单 -->
	<view class="order">
		<view class="content">
			<view v-for="orderList in orderLists" class="orderlist">
				<view class="order-type">
					<text v-if="orderList.coding" class="coding">订单编号:{{orderList.coding}}</text>
					<text class="state" v-if="orderList.status==0">未审批</text>
					<text class="state"  v-if="orderList.status==1">待确认</text>
					<text class="state" v-if="orderList.status==2">待复核</text>
					<text class="state" style="color:#19BE6B;" v-if="orderList.status==3">已退货</text>
				</view>
				<view class="main" v-for="(item,index) in orderList.medicalRoolBackOrderDtoList" :key="index">
					<view class="main-top">
						<view class="main-top-left">
							<image :src="item.attachmentUrl" mode=""></image>
						</view>
						<view class="main-top-center" v-if="item.specificationsName">
							<view>{{item.name}}</view>
							<view style="color: #999999;">{{item.specificationsName}}||{{item.specificationsValue}}</view>	
						</view>
						<view class="main-top-center" v-if="item.specificationsParam">
							<view>{{item.name}}</view>
							<view style="color: #999999;">{{item.specificationsParam}}</view>	
						</view>
						<view class="main-top-right">
							<text>X{{item.count}}</text>
							<view>
								<text>￥</text>
								<text>{{item.money}}</text>
							</view>
						</view>
					</view>
				</view>
				<view class="main-bottom">
					<view class="main-bottom-left">
						<text>合计:</text>
						<text>￥</text>
						<text>{{orderList.sum}}</text>
					</view>
					<view class="main-bottom-right">
						<!-- <view @click="cancle(orderList.id)" class="btn-right" v-if="orderList.status==0">取消退货</view>
						<view @click="deleteorder(orderList.id)" class="btn-right" v-if="orderList.status==6">删除订单</view>
						<view @click="lookDetail(orderList.status,orderList.id,2)" 
						v-if="orderList.status==0||orderList.status==1||
						orderList.status==2||orderList.status==3||orderList.status==5"
						 class="btn-right">查看详情</view> -->
						 <view @click="lookDetail(orderList.status,orderList.id,2)" class="btn-right">查看详情</view>
					</view>
				</view>
			</view>
		</view>
		<view v-if="orderLists.length==0" class="null" style="text-align: center;height: 100%;margin-top: 50%;">
			<image src="../../../static/null.png" 
			style="width: 240rpx;height: 240rpx;"></image>
			<view style="width: 100%;text-align: center;">空空如也</view>
		</view>
	</view>
</template>

<script>
	import {getreturnorderinfo,
						canclereturnorder,
						deletereturnorder} from "@/util/request.js"
	export default{
		data(){
			return{
				type:0,
				orderLists:[],
				show:false,
				id:"",
				pageNum:1,
				total:''
			}
		},
		props:['status'],
		watch: {
		    status:function () {
					this.pageNum=1
					this.orderLists=[]
		      this.init()
		    }
		},
		created(option) {
			this.type=uni.getStorageSync('type')
			this.init()
		},
		onReachBottom() {
			this.tobottom()
		},
		methods:{
			// 到达底部加载更多
			tobottom(){
				if(this.total>this.pageNum*10){
					this.pageNum++
					this.init()
				}else{
					return
				}
			},
			init(){
				uni.hideLoading()
				uni.showLoading({
				    title: '加载中'
				});
				getreturnorderinfo({pageSize:10,pageNum:this.pageNum,status:-3}).then(res=>{
					if(res.code===200){
						this.total=res.data.total
						if(res.data.rows){
							this.orderLists=this.orderLists.concat(res.data.rows)
							this.orderLists.forEach(val=>{
								let theSum=0;
								val.medicalRoolBackOrderDtoList.forEach(value=>{
									value.money=parseFloat(value.money).toFixed(2)
									theSum+=parseFloat(value.money)
								})
								val.sum=theSum.toFixed(2)
							})
							
						}
					}
					uni.hideLoading()
				}).catch(err=>{
					uni.hideLoading()
				})
			},
			deleteorder(id){
				let self=this
				uni.showModal({
				    // title: '提示',
				    content: '是否删除订单',
				    success: function (res) {
				        if (res.confirm) {
				            deletereturnorder({id:id}).then(res1=>{
											if(res1.code===200){
												self.orderLists=[]
												self.pageNum=1
												self.total=0
												uni.showToast({
													title: '删除订单成功',
													icon:"none"
												});
												self.init()
											}
										})
				        } else if (res.cancel) {
				            console.log('用户点击取消');
				        }
				    }
				});
			},
			// 查看订单详情
			lookDetail(status,id,type){
				uni.navigateTo({
				    url: '/pages/user/returnorder/detail/detail?status='+status+'&id='+id+'&type='+type
				});
			},
			// 已取消查看详情
			cancle(id){
				let self=this
				uni.showModal({
				    // title: '提示',
				    content: '是否取消退货申请',
				    success: function (res) {
				        if (res.confirm) {
				            canclereturnorder({id:id}).then(res1=>{
											self.orderLists=[]
											self.pageNum=1
											self.total=0
											if(res1.code===200){
												uni.showToast({
													title: '成功取消退货申请',
													icon:"none"
												});
												self.init()
											}
										})
				        } else if (res.cancel) {
				            console.log('用户点击取消');
				        }
				    }
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.order{
		// background-color: #f6f6f6;
	}
	.orderlist{
		background-color: #FFFFFF;
		margin-top: 30rpx;
		.order-type{
			padding:0rpx 30rpx 10rpx 0rpx;
			font-size: 30rpx;
			display: flex;
			.coding{
				flex: 2;
				color:#000000;
				padding-left: 10px;
			}
			.state{
				flex: 1;
				text-align: right;
				color: red;
			}
		}
	}
	.content{
		background-color: #f6f6f6;
		// height: 2000rpx;
	}
	.main{
		margin-left: 30rpx;
		box-sizing: border-box;
		width: 690rpx;
		// height: 290rpx;
		background: #FFFFFF;
		border-radius: 10rpx;
		// margin-top: 20rpx;
		// padding: 0rpx 30rpx 0 30rpx;
		.main-top{
			height: 200rpx;
			box-sizing: border-box;
			display: flex;
			// padding-top: 20rpx;
			border-top: 1rpx solid #DDDDDD;
			.main-top-left{
				flex:2;
				align-self: center;
				image{
					width: 140rpx;
					height: 140rpx;

				}
			}
			.main-top-center{
				flex:4;
				height: 180rpx;
				display: flex;
				margin-left:20rpx;;
				flex-direction: column;
				justify-content: space-around;
				view:nth-child(1){
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;

				}
				view:nth-child(2){
					font-size: 22rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
				}
				view:nth-child(3){
					text:nth-child(1){
						font-size: 20rpx;
						color: #FF4040;
						
					}
					text:nth-child(2){
						font-size: 32rpx;
						font-family: PingFang SC;
						font-weight: bold;
						color: #FF4040;
					}
				}
			}
			.main-top-right{
				flex:2;
				padding: 30rpx 0;
				//height: 180rpx;
				display: flex;
				flex-direction: column;
				justify-content: space-between;
				text-align: right;
				text:nth-child(1){
					flex:1;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #FF4040;
				}
				text:nth-child(2){
					flex:1;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #FF4040;
				}
			}
		}
		
	}
	.main-bottom{
		display: flex;
		padding: 20rpx 30rpx;
		border-top: 1rpx solid #DDDDDD;
		.main-bottom-left{
			flex: 1;
			text:nth-child(1){
				font-size: 24rpx;
				color:#333333;
			}
			text:nth-child(2){
				font-size: 20rpx;
				color: #FF4040;
			}
			text:nth-child(3){
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #FF4040;
			}
		}
		.main-bottom-right{
			flex:2;
			text-align: right;
			
			view{display: inline-block;}
			.btn-left{
				width: 140rpx;
				height: 48rpx;
				border: 1rpx solid #999999;
				border-radius: 100px;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #999999;
				text-align: center;
				line-height: 48rpx;
				
			}
			.btn-right{
				width: 140rpx;
				height: 48rpx;
				border: 1rpx solid #999999;
				border-radius: 100px;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #FFFFFF;
				background: #176CDC;
				text-align: center;
				line-height: 48rpx;
				margin-left: 42rpx;
			}
		}
	}
	
</style>
