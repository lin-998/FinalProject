<template>
	<view>
		<u-tabs bg-color="#eee" :list="list" :bold="false" :current="current" @change="change2"></u-tabs>
		<view class="child-tabs">
			<!-- 正常订单审批 -->
			<review-normal  ref="examineOrder"
			 v-if="this.current==0||this.current==1||this.current==2" :current='current'></review-normal>
			<!-- 退货订单审批-->
			<review-returngood ref="examineOrder" v-if="current===3||current===4" :current='current'></review-returngood>
		</view>
	</view>
</template>

<script>
	export default {
			data() {
				return {
					list: [
						{name: '全部'}, 
						{name: '待复核'}, 
						{name: '已复核'},
						{name: '待复核退货单'},
						{name: '已复核退货单'}
					],
					 current: 0,
					 status:-1
				}
			},
			onLoad(option) {
				console.log(typeof(option.current))
				this.current=parseInt(option.current);
				// this.$refs.examineOrder
			},
			// 下拉刷新
			onPullDownRefresh(){
				this.$refs.examineOrder.refresh()
			},
			// 点击跳转首页
			onNavigationBarButtonTap(){
				let loginInfo=uni.getStorageSync("loginInfo")
				// uni.clearStorageSync()
				// uni.setStorageSync("loginInfo",loginInfo);
				console.log("123")
				uni.switchTab({
					url:"/pages/index/index"
				})
			},
			created() {
				this.current=0
			},
			mounted() {
				this.change2(this.current)
			},
			// 下拉到底
			onReachBottom() {
				this.$refs.examineOrder.tobottom()
			},
			methods: {
				change2(index) {
					this.current = index;
				}
			}
		}
</script>

<style lang="scss">
	.child-tabs{
		background-color: #f6f6f6;
		padding-bottom: 10rpx;
	}
</style>
