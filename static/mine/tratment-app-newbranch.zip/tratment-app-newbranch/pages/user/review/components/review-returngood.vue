<template>
	<!-- 待复核 -->
	<view class="order">
		<view class="content">
			<!-- 没有数据返回时 -->
			<view v-if="orderLists.length==0" class="null" style="text-align: center;background-color:#f6f6f6;;height: 100%;margin-top: 50%;">
				<image src="../../../../static/null.png" 
				style="width: 240rpx;height: 240rpx;background-color: #f6f6f6;"></image>
				<view style="width: 100%;text-align: center;background-color: #f6f6f6;">空空如也</view>
			</view>
			<!-- 有数据返回 -->
			<view v-for="orderList in orderLists" class="orderlist" :key="orderList.id" >
				<view class="order-type">
					<text v-if="orderList.coding" class="coding">订单编号:{{orderList.coding}}</text>
					<text class="state" v-if="orderList.status==2">待复核</text>
					<text class="state" v-if="orderList.status!=2">已复核</text>
					<!-- <text class="state" v-if="orderList.status==2">已复核</text>
					<text class="state" v-if="orderList.status==3">已复核</text>
					<text class="state" v-if="orderList.status==6">已复核</text> -->
				</view>
				<!-- 遍历商品 -->
				<view v-for="(item,index) in orderList.medicalRoolBackOrderDtoList" class="main" :key="index">
					<view class="main-top">
						<view class="main-top-left">
							<image :src="item.attachmentUrl" mode=""></image>
						</view>
						<view class="main-top-center">
							<view>{{item.name}}</view>
							<view>{{item.specificationsName}}</view>
							
						</view>
						<view class="main-top-right">
							<text>X{{item.count}}</text>
							<view>
								<text>￥</text>
								<text>{{item.money}}</text>
							</view>
						</view>
					</view>
				</view>
				<view class="main-bottom">
					<view class="main-bottom-left">
						<text>合计:</text>
						<text>￥</text>
						<text>{{orderList.total}}</text>
					</view>
					<view class="main-bottom-right">
						<!-- <view @click="reject(orderList.id)" v-if="orderList.status==0" class="btn-left">取消订单</view> -->
						<view @click="lookDetail(orderList.status,orderList.id,1)" v-if="orderList.status==2" class="btn-right">去复核</view>
						<view @click="lookDetail(orderList.status,orderList.id,3)" class="btn-right">查看详情</view>
					</view>
				</view>
			</view>
		</view>
		<!-- 取消弹框 -->
		<u-popup mode="center" v-model="show" class="popup">
					<view class="content" style="padding: 50rpx;text-align: center;">
						<text>是否该取消订单?</text>
					</view>
					<view style="padding:0 40rpx 40rpx 40rpx;">
						<u-button type="default" size="medium" style="margin-right: 20rpx;" @click="show=false">取消</u-button>
						<u-button type="primary" size="medium" style="margin-left: 20rpx;" @click="confirm">确定</u-button>
					</view>
		</u-popup>
	</view>
</template>

<script>
	import {getreturncheckorder,cancleorder} from "@/util/request.js"
	export default{
		data:function(){
			return{
				type:0,
				orderLists:[],
				show:false,
				id:"",
				total:'',
				pageNum:1,
				status:0
			}
		},
		props:['current'],
		watch: {
		    current:function () {
					if(this.current==3){
						this.status=2
					}else if(this.current==4){
						this.status=-5
					}
					this.pageNum=1
					this.orderLists=[]
		      this.init()
		    }
		},
		created(option) {
			if(this.current==3){
				this.status=2
			}else if(this.current==4){
				this.status=-5
			}
			this.pageNum=1
			this.orderLists=[]
			this.type=uni.getStorageSync('type')
			this.init()
		},
		methods:{
			change(status){
				this.pageNum=1
				this.orderLists=[]
				this.status=status
				this.init()
			},
			// 下拉刷新
			refresh(){
				this.pageNum=1
				this.orderLists=[]
				this.type=uni.getStorageSync('type')
				this.init()
			},
			init(){
				uni.hideLoading()
				uni.showLoading({
				    title: '加载中'
				});
				getreturncheckorder({pageSize:10,pageNum:this.pageNum,status:this.status}).then(res=>{
					if(res.code==200){
						let arr=res.data.rows?res.data.rows:[]
						arr.forEach(val=>{
							let sum=0
							if(val.medicalRoolBackOrderDtoList){
								val.medicalRoolBackOrderDtoList.forEach(value=>{
									sum+=parseFloat(value.money)
									value.money=(parseFloat(value.money)).toFixed(2)
								})
								val.total=sum.toFixed(2)
							}
						})
						this.orderLists=this.orderLists.concat(arr)
						this.total=res.data.total
					}
					uni.hideLoading()
					uni.stopPullDownRefresh()
				}).catch(err=>{
					uni.hideLoading()
					uni.stopPullDownRefresh()
				})
			},
			// 到达底部加载更多
			tobottom(){
				if(this.total>this.pageNum*10){
					this.pageNum++
					this.init()
				}else{
					return
				}
			},
			// 查看详情
			lookDetail(status,id,type){
				uni.navigateTo({
				    url: '/pages/user/returnorder/detail/detail?status='+status+'&id='+id+'&type='+type
				});
			},
			// 点击取消订单
			reject(id){
				this.show=true;
				this.id=id
			},
			// 已取消查看详情
			cancle(){
				uni.navigateTo({
					url:"/pages/user/myorder/cancel/cancel"
				})
			},
			confirm(){
				cancleorder({id:this.id}).then(res=>{
					if(res.code===200){
						console.log(res.data)
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.order{
		background-color: #f6f6f6;
	}
	.orderlist{
		background-color: #FFFFFF;
		margin-top: 30rpx;
		.order-type{
			padding:0rpx 30rpx 10rpx 0rpx;
			font-size: 30rpx;
			display: flex;
			.coding{
				flex:2;
				color:#000000;
				padding-left: 10px;
			}
			.state{
				flex: 1;
				text-align: right;
				color: red;
			}
		}
	}
	.content{
		background-color: #f6f6f6;
		// height: 2000rpx;
	}
	.main{
		margin-left: 30rpx;
		box-sizing: border-box;
		width: 690rpx;
		// height: 290rpx;
		background: #FFFFFF;
		border-radius: 10rpx;
		// margin-top: 20rpx;
		// padding: 0rpx 30rpx 0 30rpx;
		.main-top{
			height: 200rpx;
			box-sizing: border-box;
			display: flex;
			// padding-top: 20rpx;
			border-top: 1rpx solid #DDDDDD;
			.main-top-left{
				flex:2;
				align-self: center;
				image{
					width: 140rpx;
					height: 140rpx;

				}
			}
			.main-top-center{
				flex:4;
				height: 180rpx;
				display: flex;
				margin-left:20rpx;;
				flex-direction: column;
				justify-content: space-around;
				view:nth-child(1){
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;

				}
				view:nth-child(2){
					font-size: 22rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
				}
				view:nth-child(3){
					text:nth-child(1){
						font-size: 20rpx;
						color: #FF4040;
						
					}
					text:nth-child(2){
						font-size: 32rpx;
						font-family: PingFang SC;
						font-weight: bold;
						color: #FF4040;
					}
				}
			}
			.main-top-right{
				flex:2;
				padding: 30rpx 0;
				//height: 180rpx;
				display: flex;
				flex-direction: column;
				justify-content: space-between;
				text-align: right;
				text:nth-child(1){
					flex:1;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #FF4040;
				}
				text:nth-child(2){
					flex:1;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #FF4040;
				}
			}
		}
		
	}
	.main-bottom{
		display: flex;
		padding: 20rpx 30rpx;
		.main-bottom-left{
			flex: 1;
			text:nth-child(1){
				font-size: 24rpx;
				color:#333333;
			}
			text:nth-child(2){
				font-size: 20rpx;
				color: #FF4040;
			}
			text:nth-child(3){
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #FF4040;
			}
		}
		.main-bottom-right{
			flex:2;
			text-align: right;
			view{display: inline-block;}
			.btn-left{
				width: 140rpx;
				height: 48rpx;
				border: 1rpx solid #999999;
				border-radius: 100px;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #999999;
				text-align: center;
				line-height: 48rpx;
				
			}
			.btn-right{
				width: 140rpx;
				height: 48rpx;
				border: 1rpx solid #999999;
				border-radius: 100px;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #FFFFFF;
				background: #176CDC;
				text-align: center;
				line-height: 48rpx;
				margin-left: 42rpx;
			}
		}
	}
	
</style>
