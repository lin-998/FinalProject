<template>
	<view>
		<view class="status_bar">
			<!-- 这里是状态栏 -->
		</view>
		<view class="status_bar1">
			<!-- 这里是状态栏 -->
		</view>
		<uni-nav-bar fixed @clickLeft="clickLeft" left-icon="back" background-color="#f6f6f6">
			<view slot="default" class="title">我的订单</view>
		</uni-nav-bar>
		<u-tabs class="tab" bg-color="#eee" :list="list" :bold="false" :current="current" @change="change2"></u-tabs>
		<view class="child-tabs">
			<!-- 全部 -->
			<!-- <order-all v-if="current===0"></order-all> -->
			<!-- 待复核 -->
			<!-- <order-check v-if="current===1"></order-check> -->
			<!-- 待发货 -->
			<!-- <order-back v-if="current===2"></order-back> -->
			<!-- 待收货 -->
			<!-- <order-progress v-if="current===3"></order-progress> -->
			<!-- 已完成 -->
			<!-- <order-completed v-if="current===4"></order-completed> -->
			<!-- 已取消 -->
		<!-- 	<order-cancel v-if="current===5"></order-cancel> -->
		<order-check :status='status' ref="orderList" class="order"></order-check>
		</view>
	</view>
</template>

<script>
	export default {
			data() {
				return {
					list: [{
						name: '全部'
					}, {
						name: '待复核'
					}, {
						name: '待发货'
					},{
						name: '待收货'
					}, {
						name: '已完成'
					}, {
						name: '已取消'
					}],
					 current: 0,
					 status:-1
				}
			},
			onLoad(option) {
				console.log(typeof(option.current))
				this.current=parseInt(option.current);
				this.change2(this.current)
			},
			onReachBottom(){
				this.$refs.orderList.tobottom()
			},
			mounted() {
				this.change2(this.current)
			},
			methods: {
				clickLeft(){
					uni.switchTab({
						url:"/pages/user/user"
					})
				},
				change2(index) {
					this.current = index;
					switch(index){
						case 0:
							this.status=-3;
							break;
						case 1:
							this.status=0;
							break;
						case 2:
							this.status=1;
							break;
						case 3:
							this.status=2;
							break;
						case 4:
							this.status=3;
							break;
						case 5:
							this.status=6;
							break;
					}
					this.$forceUpdate()
					// console.log(this.status)
				}
			}
		}
</script>

<style lang="scss" scoped>
	.title {
		margin: 0 auto;
		font-size: 36rpx;
		font-family: Source Han Sans CN;
		font-weight: 400;
		color: #333333;
	}
	
	.status_bar {
		height: var(--status-bar-height);
		width: 100%;
		background-color: #f6f6f6;
		position: fixed;
		top: 0;
		z-index: 999999;
	}
	
	.status_bar1 {
		height: var(--status-bar-height);
		width: 100%;
	}
	/deep/.uni-navbar--border {
		border: none;
		width: 100%;
	}
	
	/deep/.uni-searchbar__box {
		width: 100%;
		border: none;
	}
	.child-tabs{
		background-color: #f6f6f6;
		padding-bottom: 10rpx;
	}
	// .tab{
	// 	position: fixed;
	// 	top:var(--status-bar-height);
	// }
	// .order{
	// 	margin-top: var(--status-bar-height);
	// }
</style>
