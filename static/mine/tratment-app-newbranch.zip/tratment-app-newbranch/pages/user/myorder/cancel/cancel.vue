<template>
	<view class="cacle" style="background: #F6F6F6;">
		<!-- 订单取消栏 -->
		<view class="cancle-nav">
			<view>X</view>
			<text>订单取消</text>
		</view>
		<!-- 商品信息栏 -->
		<cancle-shop v-bind:id="id"></cancle-shop>
		<!-- 价格栏 -->
		<!-- <view class="cancle-price">
			<view>
				<text>商品总价</text>
				<text>+￥3338.00</text>
			</view>
			<view>
				<text>运费</text>
				<text>+￥10</text>
			</view>
			<view>
				<text>实付金额</text>
				<text>+￥3338.00</text>
			</view>
		</view> -->
		<!-- 用户信息地址栏 -->
		<view class="cancle-address">
			<!-- 位置图标 -->
			<view class="cancle-address-left">
				<uni-icons type="location-filled" color="#176CDC"></uni-icons>
			</view>
			<!-- 用户姓名，电话，地址 -->
			<view class="cancle-address-right">
				<view>
					<text>{{name}}</text>
					<text>{{form.phone}}</text>
				</view>
				<view>
					{{form.address}}
				</view>
			</view>
		</view>
		<!-- 订单信息栏 -->
		<view class="cancle-order">
			<view class="cancle-order-left">
				<view class="col1">订单信息</view>
				<view class="col2">订单编号：<text>{{form.coding}}</text></view>
				<view class="col2">创建时间：<text>{{form.createTime}}</text></view>
				<view class="col2">
					<text style="display: inline-block;vertical-align: top;">二维码：</text>
					<image :src="form.qrCode" style="width: 120rpx;height: 120rpx;" @click="previewImg(form.qrCode)"></image>
				</view>
			</view>
			<view class="cancle-order-right">
				<!-- <view @click="copy(form.codeing)">复制</view> -->
			</view>
		</view>
		<!-- 底部按钮栏 -->
		<view class="cancle-but">
			<view class="but" @click="deleteorder">
				删除订单
			</view>
		</view>
	</view>
</template>

<script>
	import {getbaseorderinfo,checkorder,getorderdetail} from '@/util/request.js'
	import {deleteorder} from "@/util/request.js"
	export default{
		data(){
				return{
					id:"",
					name:'',
					form:{},
				}
		},
		onLoad(option) {
			this.id=option.id
			this.name=uni.getStorageSync("userInfo").username
			getorderdetail({id:option.id}).then(res=>{
				if(res.code===200){
					console.log(res.data)
					this.form=res.data[0]
					this.switchVal=res.data.certificate==0?false:true
					this.logisticsMode=res.data.logisticsMode=='1'?'自提':'物流'
				}
			})
		},
		methods:{
			copy(data){
				let self=this
				uni.setClipboardData({
					data:"231231",
					success() {
						self.toast("复制成功")
					}
				})
			},
			previewImg(logourl) {
				let _this = this;
				let imgsArray = [];
				imgsArray[0] = logourl
				uni.previewImage({
					current: 0,
					urls: imgsArray
				});
			},
			deleteorder(){
				let self=this
				uni.showModal({
				    // title: '提示',
				    content: '是否删除订单',
				    success: function (res) {
				        if (res.confirm) {
										deleteorder({id:self.id}).then(res=>{
											if(res.code===200){
												uni.showToast({
													title: '删除订单成功',
													icon:"none"
												});
												uni.navigateTo({
													url:'/pages/user/myorder/myorder?current=5'
												})
											}
										})
				        } else if (res.cancel) {
				            console.log('用户点击取消');
				        }
				    }
				});
				
			}
		}
	}
</script>

<style lang="scss" scoped>
	.cancle-nav{
		width: 750rpx;
		height: 78rpx;
		background: #FFFFFF;
		line-height: 78rpx;
		padding: 0 30rpx;
		margin-bottom: 20rpx;
		view{
			display: inline-block;
			width: 38rpx;
			height: 38rpx;
			line-height: 38rpx;
			text-align: center;
			border-radius: 50%;
			background: #FF4040;
			color:#FFFFFF;
			font-size: 24rpx;
		}
		text{
			font-size: 24rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #FF4040;
			margin-left: 15rpx;
		}
	}
	.cancle-price{
		background-color: #FFFFFF;
		margin-top: 20rpx;
		padding: 0 30rpx;
		view:nth-child(1){
			padding: 25rpx 0;
			display: flex;
			text:nth-child(1){
				flex:1;
				font-size: 29rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
			}
			text:nth-child(2){
				flext:1;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #666666;
				text-align: right;
			}
		}
		view:nth-child(2){
			padding: 25rpx 0;
			display: flex;
			border-top: 1px solid #EEEEEE;
			border-bottom: 1px solid #EEEEEE;
			text:nth-child(1){
				flex:1;
				font-size: 29rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
			}
			text:nth-child(2){
				flext:1;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #666666;
				text-align: right;
			}
		}
		view:nth-child(3){
			padding: 25rpx 0;
			display: flex;
			text:nth-child(1){
				flex:1;
				font-size: 29rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
			}
			text:nth-child(2){
				flex: 1;
				text-align: right;
				font-size: 29rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #FF4040;
			}
		}
	}
	.cancle-but{
		width: 750rpx;
		height: 99rpx;
		background: #FFFFFF;
		text-align: center;
		// position: fixed;
		// bottom: 0;
		
		line-height: 99rpx;
		.but{
			display: inline-block;
			width: 600rpx;
			height: 68rpx;
			background: #176CDC;
			border-radius: 44rpx;
			font-size: 32rpx;
			font-family: PingFang SC;
			font-weight: 400;
			line-height: 69rpx;
			color: #FFFFFF;
			text-align: center;
		}
	}
	.cancle-address{
		width: 750rpx;
		height: 160rpx;
		background: #FFFFFF;
		border-radius: 10rpx;
		padding: 20rpx 30rpx;
		box-sizing: border-box;
		margin-top: 20rpx;
		display: flex;
		align-items: center;
		.cancle-address-left{
			flex:1;
		}
		.cancle-address-right{
			flex:9;
			display: flex;
			flex-direction: column;
			view:nth-child(1){
				flex:1;
				text:nth-child(1){
					font-size: 29rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
				}
				text:nth-child(2){
					font-size: 22rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					margin-left: 10rpx;
				}
			}
			view:nth-child(2){
				flex:1;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #666666;
			}
		}
	}
	.cancle-order{
		width: 750rpx;
		// height: 231rpx;
		background: #FFFFFF;
		border-radius: 10rpx;
		display: flex;
		padding: 20rpx 30rpx;
		box-sizing: border-box;
		margin-top: 20rpx;
		margin-bottom: 100rpx;
		.cancle-order-left{
			flex: 3;
			.col1{
				font-size: 29rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #333333;
				margin-bottom: 30rpx;
			}
			.col2{
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
				line-height: 40rpx;
			}
		}
		.cancle-order-right{
			flex: 1;
			text-align: center;
			view{
				display: inline-block;
				margin-top: 60rpx;
				width: 110rpx;
				height: 38rpx;
				border: 1rpx solid #176CDC;
				border-radius: 100rpx;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				line-height: 38rpx;
				color: #176CDC;
				text-align: center;
			}
		}
	}
</style>
