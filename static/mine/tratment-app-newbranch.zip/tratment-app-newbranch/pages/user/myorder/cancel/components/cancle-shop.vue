<template>
	<view class="shoppes">
		<view class="shangpin">
			<text>已下单商品</text>
			<view v-for="(item,index) in shoppes[0].medicalOrderDtos" class="shop" :key="index">
				<view>
					<image :src="item.attachmentUrl" mode=""></image>
				</view>
				<view class="shop-detail" v-if="item.specificationsName">
					<text>{{item.name}}</text>
					<text style="color: #999999;">{{item.specificationsName}}||{{item.specificationsValue}}</text>
				</view>
				<view class="shop-detail" v-if="item.specificationsParam">
					<text>{{item.name}}</text>
					<text style="color: #999999;">{{item.specificationsParam}}</text>
				</view>
				<view>
					<view class="num">X{{item.count}}</view>
					<view class="price"><text>￥</text>{{item.money}}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {getbaseorderinfo,checkorder,getorderdetail} from '@/util/request.js'
	export default{
		data:function(){
			return{
				shoppes:[]
			}
		},
		props:{
			id:{
				type: String,
				required: true
			}
		},
		created() {
			getorderdetail({id:this.id}).then(res=>{
				if(res.code===200){
					this.shoppes=res.data
					console.log(res.data)
				}
			})
			
		}
	}
</script>

<style lang="scss" scoped>
	.shangpin{
		padding: 25rpx 30rpx;
		background-color: #FFFFFF;
		text{
			font-size: 29rpx;
			font-family: PingFang SC;
			font-weight: bold;
			line-height: 40rpx;
			color: #333333;
		}
		.shop{
			display: flex;
			padding: 20rpx 0;
			border-bottom: 1rpx solid #DDDDDD;
			opacity: 1;
			.shop-detail{
				display: flex;
				flex-direction: column;
				justify-content: space-around;
			}
			view:nth-child(1){
				flex:1;
				image{
					width: 120rpx;
					height: 120rpx;
					border: 1px solid #707070;
					border-radius: 6px;
				
				}
			}
			view:nth-child(2){
				flex:3;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
				line-height: 33rpx;
				margin-left: 19rpx;
				// display: flex;
				// flex-direction: column;
			}
			view:nth-child(3){
				flex:2;
				text-align: right;
				display: flex;
				flex-direction: column;
				justify-content: space-between;
				.num{
					flex:1;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #FF4040;
				}
				.price{
					flex:1;
					font-size: 32rpx;
					font-family: PingFang SC;
					font-weight: bold;
					color: #FF4040;
					text{
						font-size: 20rpx;
						color: #FF4040;
					}	
				}
			}
		}
	}
</style>
