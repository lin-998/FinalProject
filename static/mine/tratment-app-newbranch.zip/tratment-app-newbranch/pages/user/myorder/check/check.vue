<template>
	<!-- 复核订单，查看复核信息 -->
	<view>
		<view class="form-data">
			<u-form :model="form">
				<!-- 公司 -->
				<u-form-item label-width="140rpx" label="公司:" prop="name" class="company fornitem" label-align="right">
					<view class='inp'>
						<u-input v-model="form.companyName" disabled border class="uinput"></u-input>
					</view>
				</u-form-item>
				<!-- 医院 -->
				<u-form-item label-width="140rpx" label="医院:" prop="name" class="hospital fornitem" label-align="right">	
					<view class='inp'>
						<u-input disabled v-model="form.hospital"></u-input>
					</view>
				</u-form-item>
				<!-- 品牌 -->
				<u-form-item label-width="140rpx" label="品牌:" prop="name" class="brand fornitem" label-align="right">
					<view class='inp'>
						<u-input disabled  v-model="form.brand" placeholder="无"></u-input>
					</view>
				</u-form-item>
				<!-- 显示已下单商品 -->
				<view class="shangpin">
					<text>已下单商品</text>
					<view v-for="(item,index) in shopes[0].medicalOrderDtos" class="shop" :key="index">
						<view>
							<image :src="item.attachmentUrl" mode=""></image>
						</view>
						<view class="shop-detail" v-if="item.specificationsName">
							<text>{{item.name}}</text>
							<text style="color: #999999;">{{item.specificationsName}}||{{item.specificationsValue}}</text>
						</view>
						<view class="shop-detail" v-if="item.specificationsParam">
							<text>{{item.name}}</text>
							<text style="color: #999999;">{{item.specificationsParam}}</text>
						</view>
						<view>
							<view class="num">X{{item.count}}</view>
							<view class="price"><text>￥</text>{{item.money}}</view>
						</view>
					</view>
				</view>
				<!-- </u-form-item> -->
				<!-- 联系人电话 -->
				<u-form-item label-width="140rpx" label="联系人:" prop="name" class="tel fornitem" label-align="right">
					<view class='inp'>
						<u-input  disabled v-model="form.phone" />
					</view>
				</u-form-item>
				
				<!-- 备注图片 -->
				<u-form-item label-width="140rpx" label="备注图片:" class="img fornitem" label-align="right">
					<image v-for="(itme,index) in form.medicalOrderAttachments" 
					:key="index" 
					:src="itme.attachmentUrl"
					@click="previewImg(itme.attachmentUrl)"
					style="width:140rpx;height:140rpx;margin-right: 20rpx;"></image>
				</u-form-item>
				<!-- 物流方式 -->
				<u-form-item label-width="140rpx" label="物流方式:" prop="name" class="met fornitem" label-align="right">
					<u-input disabled v-model="logisticsMode" class="inp" />
				</u-form-item>
				<!-- 合格证 -->
				<u-form-item label-width="140rpx" label="带合格证:" class="swi fornitem" label-align="right">
					<u-switch  slot="right" v-model="switchVal" disabled></u-switch>
				</u-form-item>
				<!-- 收货地址 -->
				<u-form-item label-width="140rpx" label="收货地址:" prop="name" class="address fornitem" label-align="right">
					<view class='inp'>
						<u-input disabled v-model="form.address"/>
					</view>
				</u-form-item>
				<!-- 手术时间 -->
				<u-form-item label-width="140rpx" label="手术时间:" prop="name" class="remark fornitem" label-align="right">
					<view class='inp'>
						<u-input disabled  v-model="form.surgeryTime" placeholder="无" />
					</view>
				</u-form-item>
				<!-- 备注 -->
				<u-form-item label-width="140rpx" label="备注:" prop="name" class="remark fornitem" label-align="right">
					<view class='inp'>
						<u-input disabled  v-model="form.remark" placeholder="无" />
					</view>
				</u-form-item>
				<!-- 备注 -->
				<u-form-item label-width="140rpx" label="订单编号:" prop="name" class="remark fornitem" label-align="right">
					<view class='inp'>
						<u-input disabled  v-model="form.coding" placeholder="无" />
					</view>
				</u-form-item>
				<u-form-item label-width="140rpx" label="驳回理由:" prop="name" class="remark fornitem" v-if="type==1" label-align="right">
					<view class='inp'>
						<textarea class="text-area"
						v-model="reject"
						placeholder="请输入驳回理由"
						placeholder-style="color:#F76260" />
					</view>
				</u-form-item>
				<view class="but">
					<!-- <u-button class="submit-btn bg-btn1" @click="submit" v-if="type==1">确定复核</u-button> -->
					<u-button class="submit-btn bg-btn2" v-if="type==0">待复核</u-button>
				</view>
				<view v-if="type==1"  class="btn-content">
					<view class="btn1 but">
						<view style="background-color: red;" @click="toReject('5')">驳回</view>
					</view>
					<view class="btn2 but">
						<view style="background-color: #007AFF;" @click="submit('1')">确定审核</view>
					</view>
				</view>
			</u-form>
		</view>
	</view>
</template>

<script>
	import {getbaseorderinfo,checkorder,getorderdetail} from '@/util/request.js'
	import {
		uploadAttachment,
		deleteAttachment,
		createAttachment,
		imageUpload
	} from "@/util/request.js"
	export default {
		
		data() {
			return {
				reject:'',
				fileList: [],
				id:'',
				// 上传图片
				attIds: [],
				header: {
					'X-Requested-Token': uni.getStorageSync('token')
				},
				action: imageUpload,
				// 物流方式
				logisticsMode:'',
				certificate:"0",
				addressVal:'',
				selecValue: '',
				url:"http://192.168.105.31:80/file/",
				shopselect:"shopselect",
				shopcancle:"shopcancle",
				selectShop:[],
				shopes:[
					{
						img:"../../static/1.jpg",
						detail:"3件装 | MEDIHEAL 美迪惠尔 N.M.F 医用手术刀/10把",
						num:"1",
						price:"999"
					},
					{
						img:"../../static/1.jpg",
						detail:"3件装 | MEDIHEAL 美迪惠尔 N.M.F 医用手术刀/10把",
						num:"1",
						price:"999"
					},
					{
						img:"../../static/1.jpg",
						detail:"3件装 | MEDIHEAL 美迪惠尔 N.M.F 医用手术刀/10把",
						num:"1",
						price:"999"
					}
				],
				form: {},
				// 是否带合格证
				switchVal: false,
				textareaVal: '',
				type:0,
			}
		},
		onLoad(option){
			// let storage=uni.getStorageSync('selectShop')
			// this.selectShop=storage ? storage : [],
			this.type=option.type
			this.id=option.id
			// getbaseorderinfo({id:option.id}).then(res=>{
			// 	if(res.code===200){
			// 		console.log(res.data)
			// 		this.form=res.data
			// 		this.switchVal=res.data.certificate==0?false:true
			// 		this.logisticsMode=res.data.logisticsMode=='0'?'自提':'物流'
			// 	}
			// })
			getorderdetail({id:option.id}).then(res=>{
				if(res.code===200){
					this.form=res.data[0]
					this.switchVal=res.data[0].certificate==0?false:true
					this.logisticsMode=res.data[0].logisticsMode=='0'?'物流':'自提'
					this.shopes=res.data
					console.log(res.data)
				}
			})
			
		},
		methods: {
			previewImg(logourl) {
				let _this = this;
				let imgsArray = [];
				imgsArray[0] = logourl
				uni.previewImage({
					current: 0,
					urls: imgsArray
				});
			},
			submit(status){
				checkorder({id:this.id,status:status}).then(res=>{
					if(res.code===200){
						uni.navigateTo({
							url:'/pages/user/review/review?current=2',
							fail(){
								uni.switchTab({
								    url: '/pages/user/review/review'
								});
							}
						})
					}
				})
			},
			toReject(status){
				let self=this
				if(this.reject==''||this.reject==undefined){
					this.toast("请填写驳回理由")
					return
				}
				uni.showModal({
								    // title: '提示',
								    content: '是否驳回订单',
								    success: function (res) {
								        if (res.confirm) {
														checkorder({id:self.id,status:status,reject:self.reject}).then(res=>{
															if(res.code===200){
																uni.navigateTo({
																	url:'/pages/user/review/review?current=2',
																	fail(){
																		uni.switchTab({
																		    url: '/pages/user/review/review'
																		});
																	}
																})
															}
														})
								        } else if (res.cancel) {
								            console.log('用户点击取消');
								        }
								    }
								});
				console.log(this.reject)
				
			},
			selectOne(options) {
				this.selecValue = options.label
				console.log(options.label);
			},
			changeClick(e) {
				console.log(e.detail);
				this.textareaVal = e.detail
			},
			selectBtn() {},
			clickLeft() {
				uni.switchTab({
					url: "../index"
				})
			},
			butSlect(i){
				this.selectShop[i].checked=!this.selectShop[i].checked;
			},
			// 上传图片
			getUploadpicList(res, index, lists, name) {
				this.attIds.push(JSON.parse(res.data).data.id)
				console.log(this.attIds)
			},
			// 删除图片
			handleRemovelist(index, lists, name) {
				console.log(index);
				deleteAttachment({
					id: this.attIds[index]
				}).then(res => {
					if (res.code === 200) {
						this.attIds.splice(index, 1)
					}
				})
			},
		},
	}
</script>

<style lang="scss" scoped>
	/deep/.uni-navbar--border {
		border: none;
	  width: 100%;
	}
	/deep/.uni-searchbar__box{
		width: 100%;
		border: none;
	}
	.form-data {
		background-color: #FFFFFF;
		margin-bottom: 100rpx;
		 .fornitem{
			 font-size: 28rpx;
			 font-family: PingFang SC;
			 font-weight: 400;
			 color: #333333;
			 padding: 30rpx;
			 background-color: #FFFFFF;
			 .uinput{
			 			 width: 420rpx;
			 			 vertical-align: middle;
			 			 background: #FAFAFA;
			 			 border: 1rpx solid #DDDDDD;
			 			 border-radius: 10rpx;
			 			 box-sizing: border-box;
			 }
		 }
		 .shop-item{
			  padding: 30rpx;
			 width: 540rpx;
			 // height: 200rpx;
			 background: #FAFAFA;
			 border: 1rpx solid #DDDDDD;
			 border-radius: 10rpx;
			 .shop{
				 // padding-bottom: 25rpx;
				 display: flex;
				 view{
					 flex:1;
					 // text-align: right;
					 // padding-right: 10rpx;
					 width: 100%;
					 .shopselect{
						 width: 30rpx;
						 height: 30rpx;
						 border-radius:15rpx;
						 background: #176CDC;
					 }
					 .shopcancle{
						 width: 30rpx;
						 height: 30rpx;
						 border-radius:15rpx;
						 background: #ffffff;
						 display: inline-block;
						 border: 2rpx solid #DDDDDD;
					 }
				 }
				 .shopname{
					 flex:5;
					 // height: 33rpx;
					 font-size: 24rpx;
					 color: #333333;
					 text-align: left;
				 }
				 .shopnum{
					 flex:1;
					 text-align: right;
					 font-size: 24rpx;
					 color: #176CDC;
				 }
			 }
		 }
		 
		.text-area {
			border: 1rpx solid #ccc;
			padding: 10rpx;
			box-sizing: border-box;
			width: 540rpx;
			height: 170rpx;
			background: #FAFAFA;
			border: 1rpx solid #DDDDDD;
			opacity: 1;
			border-radius: 10rpx;
		}

		.demand-goods {
			display: flex;
			justify-content: space-between;

			navigator {
				padding: 20rpx 28rpx;
				font-size: 28rpx;
				color: #57A1F9;
			}
		}
	}

	.u-field {
		padding-left: 0;

		.u-textarea-inner {
			display: flex;
			align-items: center !important;
		}

		.fild-body {
			border: 1rpx solid #C0C0C0 !important;
		}
	}

	.u-form-item {
		// line-height: 0rpx;
		font-size: 28rpx;
	}

	.u-border-bottom:after {
		border: 0 solid #bbbbbb;
		border-bottom-width: 1px;
	}

	.uni-textarea-placeholder {
		color: #888888;
		padding: 10rpx;
		box-sizing: border-box;
	}

	.u-label {
		flex: 0 0 20rpx !important;
	}

	.select-easy {
		width: 400rpx !important;
		height: 60rpx !important;
	}
	/deep/.u-line-1{
		height: 100% !important;
		line-height: 200% !important;
	}
	.address-inp{
		width: 400rpx;
		height: 60rpx;
		padding-left: 20rpx;
		box-sizing: border-box;
		border-radius: 10rpx;
		border: 1rpx solid #bbb;
		font-size: 28rpx;
		&::after{
			content: ">";
			position: absolute;
			right:80rpx;
			top: 50rpx;
			transform: rotate(90deg);
			width: 14px;
			height: 8px;
			color: #888;
			font-weight: 1000;
		}
	}
	.shangpin{
		padding: 25rpx 30rpx;
		background-color: #FFFFFF;
		text{
			font-size: 29rpx;
			font-family: PingFang SC;
			font-weight: bold;
			line-height: 40rpx;
			color: #333333;
		}
		.shop{
			display: flex;
			padding: 20rpx 0;
			border-bottom: 1rpx solid #DDDDDD;
			opacity: 1;
			.shop-detail{
				display: flex;
				flex-direction: column;
				justify-content: space-around;
			}
			view:nth-child(1){
				flex:1;
				image{
					width: 120rpx;
					height: 120rpx;
					border: 1px solid #707070;
					border-radius: 6px;
				
				}
			}
			view:nth-child(2){
				flex:3;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
				line-height: 33rpx;
				margin-left: 19rpx;
				// display: flex;
				// flex-direction: column;
			}
			view:nth-child(3){
				flex:2;
				text-align: right;
				display: flex;
				flex-direction: column;
				justify-content: space-around;
				.num{
					flex:1;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #FF4040;
				}
				.price{
					flex:1;
					font-size: 32rpx;
					font-family: PingFang SC;
					font-weight: bold;
					color: #FF4040;
					text{
						font-size: 20rpx;
						color: #FF4040;
					}	
				}
			}
		}
	}
	.but{
		padding-bottom: 50rpx;
		.submit-btn{
			color: #fff !important;
			height: 88rpx !important;
			// margin-bottom: 90rpx !important;
			margin-top: 70rpx !important;
			width: 600rpx;
			background: #176CDC;
			border-radius: 44rpx;
		}
		.bg-btn2{
			background: #CCCCCC;;
		}
	}
	.inp{
		margin-left: 10rpx;
	}
	.btn-content{
		// position: fixed;
		// bottom: 0rpx;
		height: 100rpx;
		width: 100%;
		margin:0 auto;
		z-index: 10;
		background-color: #FFFFFF;
		line-height: 100rpx;
		display: flex;
		.but{
			flex:1;
			text-align: center;
			view{
				display: inline-block;
				width: 250rpx;
				height: 66rpx;
				background: #CCCCCC;
				border-radius: 44rpx;
				text-align: center;
				line-height:66rpx;
				font-size: 32rpx;
				color: #FFFFFF;
				text-align: center;
			}
		}
	}
</style>
