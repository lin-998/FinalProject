<template>
	<view>
		<!-- 退货申请 -->
		<view class="form-data">
			<u-form :model="form">
				<!-- 物流方式 -->
				<u-form-item label-width="140rpx" label="处理方式:" prop="name" class="form-item" label-align="right">
					<!-- <uni-select :selectIs="selValue" :placeholder="'自提（必填）'" @change="selectBtn" :width="'400rpx'" :datalist="selectList">
					</uni-select> -->
					<!-- <u-input disabled border v-model="form.receiptAddress" class="form-input" /> -->
					<view>
						<u-input border class="form-input" value="自送" disabled />
					</view>
				</u-form-item>
				<!-- 添加备注 -->
				<u-form-item label-width="140rpx" label="备注:" prop="name" class="form-item" label-align="right">
					<view class="text-area">
						<textarea value="" placeholder="添加备注..." @input="changeClick">
						 </textarea>
						<text class="text-max">{{textareaVal.cursor||0}}/500</text>
					</view>
				</u-form-item>
				<!-- 退货商品 -->
				<!-- <view class="goods-detail form-item">
					<text class="good-title">选择退货商品</text>
					<view class="good-list" v-for="shop in shoppes">
						<view class="title">
							<text>
							{{shop.name}}
							<text style="font-size: 20rpx;color: #999999;">({{shop.specificationsName}}||{{shop.specificationsValue}})</text>
							</text>
							<text style="font-size: 24rpx;color: #999;">已下单{{shop.max}}件</text>
						</view>
						<view class="number-bar">
							<u-number-box v-model="shop.count" :min="0" :max="shop.max" @change="" class="number"></u-number-box>
						</view>
					</view>
				</view> -->
				<!-- 备注图片 -->
				<u-form-item label-width="140rpx" label="补充材料:" class="form-item" label-align="right">
					<u-upload :header="header" :action="action" upload-text="点击上传" :show-progress="false" to-json :file-list="fileList"
					 @on-change="getUploadpicList" @on-remove="handleRemovelist"></u-upload>
				</u-form-item>
				<!-- 订单信息 -->
				<!-- <view class="form-item order">
					<view class="title">
						订单信息
					</view>
					<view class="content">
						<view class="order-main">
							<view>订单编号：{{baseData.coding}}</view>
							<view>创建时间：{{baseData.createTime}}</view>
							<view class="img">
								<text>二维码：</text>
								<image :src="baseData.qrCode"></image>
							</view>
						</view>
						<view class="info-btn">
							<view class="btn">复制</view>
						</view>
					</view>
				</view> -->
				<!-- 寄出地址 -->
				<u-form-item label-width="140rpx" label="收货地址:" class="form-item" label-align="right">
					<view>
						<u-input disabled border v-model="form.receiptAddress" class="form-input" />
					</view>
				</u-form-item>
				<!-- 联系人 -->
				<u-form-item label-width="140rpx" label="联系人:" class="form-item" label-align="right">
					<view>
						<u-input disabled border v-model="form.contact" class="form-input" />
					</view>
				</u-form-item>
				<!-- 联系方式 -->
				<u-form-item label-width="140rpx" label="联系方式:" class="form-item" label-align="right">
					<view>
						<u-input disabled border v-model="form.phone" class="form-input" />
					</view>
				</u-form-item>
				<!-- 提交退货申请按钮 -->
			</u-form>
			
		</view>
		<view class="btm">
			<view class="submit-btn" @click="submit">提交申请</view>
		</view>
		<u-toast ref="uToast" />
	</view>
</template>

<script>
	import {
		getbaseorderinfo,
		getorderdetail,
		deleteremark,
		returngoodsinfo,
		createRoolbackOrder,
		createRoolbackQR,
		imageUpload
	} from '@/util/request.js'
	export default {
		data() {
			return {
				header: {
					'X-Requested-Token': uni.getStorageSync('token')
				},
				action: imageUpload,
				fileList:[],
				attIds:[],
				selectis:false,
				addressVal:'',
				selecValue: '',
				form: {
					receiptAddress:"昆明光明顶",
					contact:"张无忌",
					phone:"13266677389"
					
				},
				value: 2,
				textareaVal: '',
				shoppes:'',
				baseData:{},
				selValue:"",
				notAllowed:true,
				selectList: [{
						label: '自送',
						value: "自送"
					},
					// {
					// 	label: '物流',
					// 	value: "物流"
					// }
				],
			}
		},
		onLoad(option) {
			// 获取商品基本信息
			this.form.orderId=option.id
			getbaseorderinfo({id:option.id}).then(res=>{
				if(res.code===200){
					console.log(res.data)
					this.baseData=res.data
				}
			})
			returngoodsinfo({id:option.id}).then(res=>{
				if(res.code===200){
					let arr=res.data
					arr.forEach(val=>{
						val.max=val.count
					})
					this.shoppes=arr
					console.log(res.data)
				}
			})
		},
		methods: {
			submit(){
				if(!this.notAllowed){
					this.toast("请勿重复点击")
					return
				}
				this.notAllowed=false
				setTimeout(()=>{
						this.notAllowed = true;
				}, 2000)
				this.form.medicalRoolbackGoodsDtos=this.shoppes.filter(val=>{
					return val.count>0
				});
				this.form.logisticsMode='1'
				this.form.ids=this.attIds;
				this.form.remark=this.textareaVal.value
				console.log(this.shoppes)
				if(!this.check()){
					return
				}
				console.log(this.form)
				createRoolbackOrder(this.form).then(res=>{
					if(res.code===200){
						console.log(res.data);
						this.getQR(res.data)
					}else{
						this.toast(res.msg)
						this.notAllowed = true;
					}
				})
			},
			getQR(id){
				createRoolbackQR({id:id}).then(res=>{
					if(res.code==200){
					uni.showToast({
						title: '已提交申请',
						icon:"none"
					});
					uni.navigateTo({
							url:'/pages/user/myorder/myorder?current=4'
						})
					}
				})
			},
			// 检查校验
			check(){
				if(this.form.remark==""){
					this.notAllowed = true;
					uni.showToast({
						title: '请填写备注信息!!!',
						icon:"none"
					});
					return false
				}
				if(this.form.ids.length==0){
					this.notAllowed = true;
					uni.showToast({
						title: '未上传补充材料或上传补充材料中!!!',
						icon:"none"
					});
					return false
				}
				return true
			},
			selectBtn(e) {
				this.selValue = e.value=='自送'?'0':'1'
			},
			// 上传图片
			getUploadpicList(res, index, lists, name) {
				console.log(JSON.parse(res.data))
				this.attIds.push(JSON.parse(res.data).data.id)
				console.log(this.attIds)
			},
			// 删除图片
			handleRemovelist(index, lists, name) {
				// console.log(index);
				deleteremark({
					id: this.attIds[index]
				}).then(res => {
					if (res.code === 200) {
						this.attIds.splice(index, 1)
						console.log(this.attIds,"attIds")
					}
				})
			},
			changeClick(e) {
				console.log(e.detail);
				this.textareaVal = e.detail
			}
		},
	}
</script>

<style lang="scss" scoped>
	// 3
	.data-list {
		display: flex;
		align-items: center;
		justify-content: space-between;
		width: 100%;
		.title {
			font-size: 32rpx;
			text{
				display: block;
				height: 48rpx;
			}
		}
		.number-bar{
			text{
				border: 1rpx solid #ccc;
				text-align: center;
				display: inline-block;
				width: 48rpx;
				height: 48rpx;
				line-height: 48rpx;
				background-color: #fff;
			}
		}
	}
	.form-data {
		background-color: #FFFFFF;
		padding: 0rpx 30rpx;
		margin-bottom: 50rpx;
		.form-item{
			padding:30rpx 0 ;
			border-bottom: 1rpx solid #DDDDDD;
			.form-input{
				width: 421rpx;
				background: #FAFAFA;
				border: 1rpx solid #DDDDDD;
				border-radius: 10rpx;
			}
		}
		.text-area {
			border: 1rpx solid #ccc;
			position: relative;

			.text-max {
				color: #888;
				font-size: 24rpx;
				position: absolute;
				bottom: 0;
				right: 30rpx;
			}

			textarea {
				width: 396rpx;
				height: 150rpx;
				font-size: 28rpx;
				padding: 10rpx;
				box-sizing: border-box;
			}
		}
		}
		// 选择退货商品
	.goods-detail{
		.good-title{
			font-size: 29rpx;
			font-weight: bold;
			padding-bottom: 28rpx;
		}
		.good-list{
			display: flex;
			padding:20rpx 0;
			.title{
				flex: 1;
				display: flex;
				flex-direction: column;
				text{
					flex: 1;
				}
			}
			.number-bar{
				flex: 1;
				text-align: right;
				align-self: center;
			}
		}
	}
	// 订单信息
	.order{
		width: 100%;
		box-sizing: border-box;
		.title{
			font-size: 29rpx;
			font-weight: bold;
			padding-bottom: 28rpx;
		}
		.content{
			display: flex;
			.order-main{
				flex:2;
				font-size: 24rpx;
				display: flex;
				flex-direction: column;
				justify-content: space-between;
				view{
					flex:1;
					margin-bottom: 10rpx;
					font-size: 24rpx;
					text{
						display: inline-block;
						vertical-align: top;
					}
					image{
						width: 120rpx;
						height: 121rpx;
					}
				}
			}
			.info-btn{
				flex:1;
				text-align: right;
				.btn{
					display: inline-block;
					width: 110rpx;
					height: 38rpx;
					border: 1rpx solid #176CDC;
					border-radius: 100rpx;
					text-align: center;
					line-height: 38rpx;
					font-size: 24rpx;
					color: #176CDC;
				}
			}
		}	
	}
	.btm{
		// position: fixed;
		// bottom: 0rpx;
		height: 150rpx;
		box-sizing: border-box;
		line-height: 150rpx;
		width: 100%;
		text-align: center;
		z-index: 10;
		.submit-btn{
			display: inline-block;
			width: 600rpx;
			height: 88rpx;
			background: #176CDC;
			border-radius: 44rpx;
			text-align: center;
			line-height: 88rpx;
			font-size: 32rpx;
			color: #FFFFFF;
		}
	}
</style>
