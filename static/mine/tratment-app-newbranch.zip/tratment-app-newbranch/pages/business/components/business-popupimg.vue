<template>
	<view class="upload-img">
		<view class="img-popup">
			<u-upload
			:show-progress="false"
			:deletable="statusType!==0&&statusType!==1"
			:file-list="filePositive"
			:form-data="{type:3}" 
			:header="header" 
			ref="Upload" 
			custom-btn 
			:action="action" 
			max-count="1"
			@on-change="getUploadpicList1" 
			@on-remove="handleRemovelist1" 
			@on-progress="onProgress1"
			:auto-upload="true">
				<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
					<image src="/static/image/positive.png" mode="widthFix" />
				</view>
			</u-upload>
		</view>

		<view class="img-popup">
			<u-upload
			:show-progress="false"
			:deletable="statusType!==0&&statusType!==1"
			:file-list="fileBack"
			:form-data="{type:3}" 
			:header="header" 
			ref="uUpload" 
			custom-btn 
			:action="action" 
			max-count="1"
			@on-change="getUploadpicList2" 
			@on-remove="handleRemovelist2"
			@on-progress="onProgress2"
			:auto-upload="true">
				<view slot="addBtn" class="slot-btn" hover-class="slot-btn__hover" hover-stay-time="150">
					<image src="/static/image/back.png" mode="widthFix" />
				</view>
			</u-upload>
		</view>
	</view>
</template>

<script>
	import {imageUpload} from "@/util/request.js"
	export default {
		props:['statusType','filePositive','fileBack'],
		data(){
			return {
				// loginImg1:false,
				// loginImg2:false,
				// fileList1: [],
				// fileList2: [],
				header: {
					'X-Requested-Token': uni.getStorageSync('token')
				},
				action: "https://tech.a6shop.net:8058/smartMedical-app/hd-website-server/medicalStoreAttachment/upload",
			}
		},
		methods:{
			onProgress1(res, index, lists, name){
				// this.loginImg1=true
			},
			onProgress2(res, index, lists, name){
				// this.loginImg2=true
			},
			deleteImg(){
				this.$refs.uUpload.clear()
				this.$refs.Upload.clear()
			},
			// 上传身份证正面
			getUploadpicList1(res, index, lists, name) {
				// setTimeout(()=> {
				// 	this.loginImg1=false
				// }, 0);
				this.$emit('UploadPositive',JSON.parse(res.data).data.id)
			},
			// 删除身份证正面
			handleRemovelist1(index, lists, name) {
				this.$emit('UploadBack',index)
			},
			// 上传身份证反面
			getUploadpicList2(res, index, lists, name) {
				// setTimeout(()=> {
				// 	this.loginImg2=false
				// }, 0);
				this.$emit('RemovePositive',JSON.parse(res.data).data.id)
			},
			// 删除身份证反面
			handleRemovelist2(index, lists, name) {
				this.$emit('RemoveBack',index)
			},
		},
		onLoad() {
			console.log(this.$route);
		}
	}
</script>

<style lang="scss" scoped>
	.img-popup{
		position: relative;
		.login{
			top: 12rpx;
			left: 12rpx;
			position: absolute;
			width: 200rpx;
			height: 200rpx;
			background: rgba(0,0,0,0.5);
			border-radius: 10rpx;
			image{
				width: 100%;
				height: 100%;
			}
		}
	}
	.upload-img{
		display: flex;
		justify-content: space-around;
		margin-bottom: 50rpx;
	}
	.slot-btn{
		width: 260rpx;
		height: 180rpx;
		image{
			width: 100%;
			height: 100%;
		}
	}
</style>
