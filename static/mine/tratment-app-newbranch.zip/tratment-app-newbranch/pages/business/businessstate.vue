<template>
	<view>
		<view class="business">
			<u-form :model="form" ref="uForm">
				<u-form-item label-width="170rpx" label="申请状态: ">
					<u-input style="margin-left: 20rpx;" v-model="form.supplierName" placeholder="请输入供应商名称" />
				</u-form-item>
				<u-form-item label-width="170rpx" label="供应商名称 : ">
					<u-input style="margin-left: 20rpx;" v-model="form.supplierName" placeholder="请输入供应商名称" />
				</u-form-item>
				<u-form-item label-width="170rpx" label="主营项目 :">
					<u-input style="margin-left: 20rpx;" v-model="form.mainProject" placeholder="请输入主营项目" />
				</u-form-item>
				<u-form-item label-width="170rpx" label="联系人 :">
					<u-input style="margin-left: 20rpx;" v-model="form.contactsPerson" placeholder="请输入联系人" />
				</u-form-item>
				<u-form-item label-width="170rpx" label="联系人电话 :">
					<u-input type="number" style="margin-left: 20rpx;" v-model="form.phone" maxlength="11" placeholder="请输入联系人电话" />
				</u-form-item>
				<u-form-item label-width="170rpx" label="营业执照 :">
							<image src="../../static/123131.png" mode="" style="width: 120rpx;height: 120rpx;"></image>
				</u-form-item>
				
				<view class="agreement" style="text-align: center;margin-top:40rpx ;">
					<text @click="onAgreement" style="color: red;">《供应商入驻协议》</text>
				</view>
			</u-form>
		</view>
		<agreement ref="agre">
		</agreement>
		<u-toast ref="uToast" />
	</view>
</template>

<script>
	import agreement from "./agreement.vue"
	import {
		uploadAttachment,
		deleteAttachment,
		createAttachment,
		imageUpload
	} from "@/util/request.js"
	export default {
		components: {
			agreement
		},
		data() {
			return {
				fileList: [],
				checked: false,
				form: {},
				header: {
					'X-Requested-Token': uni.getStorageSync('token')
				},
				action: "https://tech.a6shop.net:8058/smartMedical-app/hd-website-server/medicalStoreAttachment/upload",
				attIds: []
			};
		},
		methods: {
			// 提交
			submit() {
				this.form.attIds = this.attIds
				this.form.status = 0
				createAttachment(this.form).then(res => {
					if (res.code === 200) {
						//轻提示
						this.$refs.uToast.show({
							title: res.msg,
							type: 'success',
						})
					}else{
						this.$refs.uToast.show({
							title: res.msg,
							type: 'error',
						})
					}
				})
			},
			//显示入驻协议
			onAgreement() {
				this.$refs.agre.onAgreement();
				this.Agreement = true
			}
		}
	}
</script>

<style lang="scss" scoped>
	/deep/.u-form-item--left__content__label{
	  display: inline-block !important;
		text-align: right;
	}
	.business {
		padding: 0 30rpx;
		background: #FFFFFF;
		/deep/.u-border-bottom:after {
			border: 0 solid #666;
			border-bottom-width: 1px;
		}

		.agreement {
			font-size: 28rpx;
			margin: 10rpx 0 100rpx;

			text {
				color: $zhbgColor;
			}
		}
	}
</style>
