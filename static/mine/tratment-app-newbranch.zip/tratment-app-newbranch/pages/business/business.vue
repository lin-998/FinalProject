<template>
	<view class="business">
		<view>
			<u-form :model="form" ref="uForm">
				<u-form-item label-width="170rpx" label="申请状态 : " v-if="form.status||form.status===0">
					<u-input v-if="form.status==1" disabled style="margin-left: 20rpx;color:#34b24b;" v-model="typeList[form.status]" />
					<u-input v-else disabled style="margin-left: 20rpx;color:#FF4040;" v-model="typeList[form.status]" />
				</u-form-item>
				<u-form-item label-width="170rpx" label="供应商名称 : ">
					<u-input :disabled="form.status==1||form.status==0" style="margin-left: 20rpx;" v-model="form.supplierName" placeholder="请输入供应商名称" />
				</u-form-item>
				<u-form-item label-width="170rpx" label="主营项目 :">
					<u-input :disabled="form.status==1||form.status==0" style="margin-left: 20rpx;" v-model="form.mainProject" placeholder="请输入主营项目" />
				</u-form-item>
				<u-form-item label-width="170rpx" label="联系人 :">
					<u-input :disabled="form.status==1||form.status==0" style="margin-left: 20rpx;" v-model="form.contactsPerson" placeholder="请输入联系人" />
				</u-form-item>
				<u-form-item label-width="170rpx" label="联系人电话 :">
					<u-input :disabled="form.status==1||form.status==0" type="number" style="margin-left: 20rpx;" v-model="form.phone" maxlength="11" placeholder="请输入联系人电话" />
				</u-form-item>
				<u-form-item label-width="170rpx" label="营业执照 :">
				</u-form-item>
				<business-popupimg ref="upload" :statusType="form.status" :filePositive="fileList1" :fileBack="fileList2"
				 @UploadPositive="uploadPositive" @UploadBack="uploadBack" @RemovePositive="removePositive" @RemoveBack="removeBack"></business-popupimg>
				<view class="agreement" v-if="form.status===1||form.status===0">
					<text @click="onAgreement">《商户入驻协议》</text>
				</view>
				<view class="agreement" v-else>
					<u-checkbox shape="circle" label-size="28rpx" active-color="#176CDC" v-model="checked">请阅读并同意</u-checkbox>
					<text @click="onAgreement">《商户入驻协议》</text>
				</view>
				<u-form-item label-width="170rpx" label="驳回理由 :" v-if="form.reject">
					<text style="color: red;word-break: break-all">{{form.reject || '无'}}</text>
				</u-form-item>
				<!-- <view class="status-text" v-if="form.status===2">
					<view class="reason">驳回理由</view>
					<view>{{form.reject || '无'}}</view>
				</view> -->
				<u-button v-if="form.status!==1&&form.status!==0" hover-class="none" class="merchantbtn" type="primary" shape="circle"
				 @click="submit" :disabled="canClick">提交</u-button>
			</u-form>
		</view>
		<agreement ref="agre">
		</agreement>
		<u-toast ref="uToast" />
	</view>
</template>

<script>
	import agreement from "./agreement.vue"
	import {
		uploadAttachment,
		deleteAttachment,
		createAttachment,
		getResult,
		submitAgain,
		imageUpload
	} from "@/util/request.js"
	export default {
		components: {
			agreement
		},
		data() {
			return {
				canClick:false,
				typeList: ['申请中', '已通过', '已驳回'],
				fileList1: [],
				fileList2: [],
				checked: false,
				form: {},
				header: {
					'X-Requested-Token': uni.getStorageSync('token')
				},
				action: "https://tech.a6shop.net:8058/smartMedical-app/hd-website-server/medicalStoreAttachment/upload",
				attIds: [],
				updateattIds: []
			};
		},
		methods: {
			// 提交
			submit() {
				console.log(this.attIds)
				this.canClick=true
				setTimeout(()=>{
					this.canClick=false
				},2000)
				if (!this.checked) {
					this.toast('请先勾选入驻协议')
					return
				}
				if (this.attIds.length < 2) {
					this.toast("图片不能少于两张");
					return
				}
				if (!this.form.supplierName || !this.form.mainProject) {
					this.form.supplierName ? this.toast("请输入主营项目") : this.toast("请输入供应商名称");
					return
				}
				if (!this.form.contactsPerson || !this.form.phone) {
					this.form.contactsPerson ? this.toast("请输入联系人") : this.toast("请输入联系人电话");
					return
				}
				if (this.form.id) {
					this.form.attIds = this.updateattIds
					delete this.form.attUrls
					submitAgain({
						...this.form,
						status: 0
					}).then(res => {
						if (res.code === 200) {
							//轻提示
							this.$refs.uToast.show({
								title: res.msg,
								type: 'success',
							})
							uni.switchTab({
								url:"/pages/index/index"
							})
						} else {
							this.$refs.uToast.show({
								title: res.msg,
								type: 'error',
							})
						}
					})
				} else {
					this.form.attIds = this.attIds
					createAttachment({
						...this.form,
						status: 0
					}).then(res => {
						if (res.code === 200) {
							//轻提示
							this.$refs.uToast.show({
								title: res.msg,
								type: 'success',
							})
							uni.switchTab({
								url:"/pages/index/index"
							})
						} else {
							this.$refs.uToast.show({
								title: res.msg,
								type: 'error',
							})
						}
					})
				}

			},
			// // 上传图片
			// getUploadpicList(res, index, lists, name) {
			// 	this.attIds.push(JSON.parse(res.data).data.id)
			// 	this.updateattIds.push(JSON.parse(res.data).data.id)


			// },
			// // 删除图片
			// handleRemovelist(index, lists, name) {
			// 	console.log(index);
			// 	deleteAttachment({
			// 		id: this.attIds[index]
			// 	}).then(res => {
			// 		if (res.code === 200) {
			// 			this.attIds.splice(index, 1)
			// 			this.updateattIds.splice(index, 1)
			// 		}
			// 	})
			// },
			// 上传身份证正面
			uploadPositive(data) {
				this.attIds.push(data)
				this.updateattIds.push(data)
			},
			// 删除身份证正面
			uploadBack(index) {
				deleteAttachment({
					id: this.attIds[0]
				}).then(res => {
					if (res.code === 200) {
						this.attIds.splice(0, 1)
						this.updateattIds.splice(0, 1)
					}
				})
			},
			// 上传身份证反面
			removePositive(data) {
				this.attIds.push(data)
				this.updateattIds.push(data)
			},
			// 删除身份证反面
			removeBack(index) {
				deleteAttachment({
					id: this.attIds[1]
				}).then(res => {
					if (res.code === 200) {
						this.attIds.splice(1, 1)
						this.updateattIds.splice(1, 1)
					}
				})
			},
			//显示入驻协议
			onAgreement() {
				this.$refs.agre.onAgreement();
				this.Agreement = true
			}
		},
		onLoad() {
			getResult({}).then(res => {
				if (res.code === 200) {
					this.form = res.data
					this.form.status = +this.form.status
					this.attIds = []
					// this.attIds=res.data.medicalStoreAttachments
					let imgUrl = res.data.medicalStoreAttachments
					imgUrl.map(val => {
						this.attIds.push(val.id)
					})
					this.fileList1 = [{
						url: imgUrl[0].attachmentUrl
					}]
					this.fileList2 = [{
						url: imgUrl[1].attachmentUrl
					}]
				}
			})
		}
	}
</script>

<style lang="scss" scoped>
	.u-border-bottom:after {
		border: 0 solid #DDDDDD;
		border-bottom-width: 1px;
	}

	.input-status {
		color: #FF2F2F !important;
	}

	/deep/.u-mode-center-box {
		border-radius: 10rpx;
	}

	/deep/.u-input {
		background: #F9F9F9;
		border-radius: 10rpx;
		margin: 10rpx 0;

		.u-input__input {
			padding-left: 20rpx;
			color: inherit;
		}
	}

	.merchantbtn {
		width: 500rpx;
		height: 80rpx;
		background: #176CDC;
		border-radius: 100rpx;
		margin-top: 60rpx;
	}

	/deep/.u-form-item--left__content__label {
		display: inline-block !important;
		text-align: right;
	}

	.business {
		padding: 0 30rpx;
		background: #FFFFFF;
		height: 100%;

		.agreement {
			text-align: center;
			font-size: 28rpx;
			padding: 30rpx 0;
			border-bottom: 1rpx solid #DDDDDD;

			text {
				color: #176CDC;
			}
		}
	}

	.status-text {
		// display: flex;
		font-size: 24rpx;
		color: #666666;
		margin-top: 20rpx;

		.reason {
			width: 320rpx;
			font-size: 30rpx;
			color: #FF2F2F;
			margin-bottom: 20rpx;
		}
	}
</style>
