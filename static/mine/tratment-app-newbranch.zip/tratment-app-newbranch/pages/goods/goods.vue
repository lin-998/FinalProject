<template>
	<!-- 商品列表 -->
	<view class="shoplist">
		<view class="status_bar">
			<!-- 这里是状态栏 -->
		</view>
		<uni-nav-bar @clickLeft="barLeft" left-icon="back" title="菜单列表">
			<navigator url="../goods/vague-search/vague-search" slot="right">
				<!-- <uni-icons class="nav-icon" type="search" size="20"></uni-icons> -->
				<image src="../../static/ico_ss_sp@2x.png" style="width: 28rpx;height: 28rpx;"></image>
			</navigator>
		</uni-nav-bar>
		<!-- 商品列表上面的导航条部分 -->
		<view class="shoplistnav">
			<view class="nav">
				<u-tabs font-size="32" :list="tabBars" :current="current" @change="onTabTap"></u-tabs>
			</view>
		</view>
		<!-- 正常订单中间主体部分 -->
		<view class="shoplist-main" v-if="type==0">
			<!-- 左边的类别部分 -->
			<view class="shoplist-main-left">
				<u-collapse ref="collapse1" >
					<u-collapse-item :open="index==0" class="collapse-item" align="center" @change="changeCollapse(item.id,index)" :title="item.name"  v-for="(item,index) in subMenus" :key="item.id">
						<view class="collapse-child" @click="brank(child,index1)" :class="tabnum == index1? changebg : normal" v-for="(child,index1) in item.threeMenu" :key="child.id">
							{{child.name}}
						</view>
						<!-- <view style="height: 0rpx;" v-if="children.length==0">1</view> -->
					</u-collapse-item>
				</u-collapse>
			</view>
			<!-- 右边的商品及其数量部分 -->
			<view class="shoplist-main-right">
				<view class="smrbox">
					<view class="smr-top">
						<view @click="buyGoods(0)" :class="Active==0?'active':''">下单区</view>
						<view @click="buyGoods(1)" :class="Active==1?'active':''">商品展示区</view>
					</view>
					<view class="smr-bottom">
						<!-- 商品遍历 -->
						<view v-if="subMenusList.length>0">
							<view v-for="(shop,index) in subMenusList" class="smr-shop" :key="shop.id">
								<text @click="naviGator(shop,shop.id)">{{shop.text}}</text>
							</view>
						</view>
						<view v-else class="no-subMenusList">
							<u-empty></u-empty>
						</view>
				</view>
				</view>
			</view>
		</view>
		<!-- 常用套餐中间主体部分 -->
		<view class="shoplist-main" v-if="type==1">
			<!-- 左边的类别部分 -->
			<view class="shoplist-main-left">
				<!-- <view v-for="(item,index) in subMenus" :key="index" >
					<text @click="changeshop(index)" 
					style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis"
					:class="tabnum == index ? changebg : normal">{{item.type}}</text>
				</view> -->
				<u-collapse ref="collapse1">
					<u-collapse-item :open="index==0" @change="changeCollapse(item.id,index)" class="collapse-item" align="center" :title="item.name"  v-for="(item,index) in subMenus" :key="item.id">
						<view class="collapse-child" @click="brank(child,index1)" :class="tabnum == index1? changebg : normal" v-for="(child,index1) in item.threeMenu" :key="child.id">
							{{child.name}}
						</view>
					</u-collapse-item>
				</u-collapse>
			</view>
			<!-- 右边的商品及其数量部分 -->
			<view class="shoplist-main-right">
				<view class="smrbox">
					<view class="smr-top">
						<view @click="buyGoods(0)" :class="Active==0?'active':''">下单区</view>
						<view @click="buyGoods(1)" :class="Active==1?'active':''">商品展示区</view>
					</view>
					<view class="smr-bottom">
						<!-- 商品遍历 -->
						<view v-if="subMenusList.length>0" :key="current">
							<view  @click="naviGatorsetMral(shop,shop.id)" v-for="(shop,index) in subMenusList" class="smr-shop" :key="shop.id">
								<text>{{shop.text}}</text>
								<!-- <text>X{{shop.packageCount}}</text> -->
							</view>
						</view>
						<view v-else class="no-subMenusList">
							<u-empty></u-empty>
						</view>
				</view>
				</view>
			</view>
		</view>
		<!-- 底部的按钮 -->
		<view class="shoplist-footer" v-if="type==1">
			<view>
				<view @click="toProduct()">已选产品</view>
			</view>
			<view>
				<view @click="confirmSelect">确定选择</view>
			</view>
		</view>
		
	</view>
</template>

<script>
	import {gateGorylist,getTreelist,addselectshop,getMenuTwoList,getTree,insertSetMeal} from "@/util/request.js"
	export default{
		data:function(){
			return{
				itemStyle: {
						height: '0px'
				},
				children:[],
				children1:[{text:"ada"}],
				// 控制class类名
				Active:0,
				changebg:"changebg",
				normal:"",
				// 控制切换病类别
				current:0,
				// 病类别数组
				tabBars:[],
				// 控制切换子类别
				tabnum:0,
				twonum:0,
				// 当前病型下所有子类别及其子类别里面的商品
				subMenus:[],
				// 需要展示的商品数组
				subMenusList:[],
				type:0,
				notAllowed:true,
				brankNum:0,
				returnShop:{},
				towId:"",
				threeId:""
			}
		},
		onLoad(option) {
			if(option.active){
				this.Active=1
			}
			// console.log(this.Active)
		},
		methods:{
			// 点击三级目录显示商品
			brank(child,index){
				// console.log(child)
				this.tabnum=index
				this.subMenusList=[]
				uni.hideLoading()
				// console.log(child)
				uni.showLoading({
					title:"加载中"
				})
				this.threeId=child.id
				let threeId=child.id
				console.log()
				getTree({categoryId:child.id}).then(res=>{
					if(res.code==200){
						this.subMenusList=[]
						if(this.threeId==threeId){
							this.returnShop=res.data
							if(this.Active==0){
								this.subMenusList=this.returnShop.buyGoods?this.returnShop.buyGoods:[];
							}else{
								this.subMenusList=this.returnShop.goods?this.returnShop.goods:[];
							}
						}
						
						console.log(this.subMenusList)
					}
					uni.hideLoading()
				}).catch(err=>{
					uni.hideLoading()
				})
			},
			// 点击二级目录发送请求
			changeCollapse(id,index){
				this.tabnum=0
				this.twonum=index
				// console.log(index)
				this.brank(this.subMenus[index].threeMenu[0],0)
				// this.$refs.collapse.init()
			},
			//返回上一层
			barLeft(){
				// uni.navigateBack({delta:1})
				uni.navigateTo({
					url:"/pages/index/demand/demand"
				})
			},
			// 切换商品下单区和商品展示区
			buyGoods(index){
				this.Active=index
				console.log(this.Active)
				// this.subMenusList=this.subMenus[0].buyGoods?this.subMenus[0].buyGoods:[];
				if(this.Active==0){
					this.subMenusList=this.returnShop.buyGoods?this.returnShop.buyGoods:[];
				}else{
					this.subMenusList=this.returnShop.goods?this.returnShop.goods:[];
				}
			},
			// 正常单跳转商品详情页面
			naviGator(shop,id){
				console.log(shop)
				let setMealId=this.subMenus[this.twonum].threeMenu[this.tabnum].id
				uni.navigateTo({
					// this.Active
					url:"/pages/goods/good-detail/good-detail?id="+id+"&type=0"+"&isshow="+this.Active+"&setMealId="+setMealId
				})
			},
			// 套餐跳转商品详情页面
			naviGatorsetMral(shop,id){
				// console.log(shop)
				let setMealId=this.subMenus[this.twonum].threeMenu[this.tabnum].id
				// console.log(this.subMenus[this.twonum].threeMenu[this.tabnum].id)
				uni.navigateTo({
					// this.Active
					url:"/pages/goods/setMeal-detail/setMeal-detail?goodsId="+id+"&type=1"+"&isshow="+this.Active+"&setMealId="+setMealId
				})
			},
			// 切换大类触发事件
			onTabTap(index) {
				this.current=index
				this.subMenus=[]
				this.subMenusList=[]
				// 判断是否是常用套餐
				if(this.tabBars[index].name&&this.tabBars[index].name=="常用套餐"){
					this.type=1;
				}else{
					this.type=0;
				}
				let requestCurrnet=this.current
				// 获取二级分类和三级分类
				getMenuTwoList({oneId:this.tabBars[index].id}).then(res=>{
					if(res.code===200){
						this.subMenus=[]
						this.subMenusList=[]
						if(requestCurrnet==this.current){
							this.subMenus=res.data?res.data:[]
							if(this.subMenus.length!=0){
								this.changeCollapse("id",0)
							}
							
						}	
						}
						this.tabBars[index].subMenus=this.subMenus
				});
			},
			// 切换商品类别
			changeshop(i){
				this.tabnum=i
				if(this.Active==0){
					this.subMenusList=this.subMenus[this.tabnum].buyGoods?this.subMenus[this.tabnum].buyGoods:[];
				}else{
					this.subMenusList=this.subMenus[this.tabnum].goods?this.subMenus[this.tabnum].goods:[];
				}
				// this.subMenusList=this.subMenus[i].subMenusList;
				// console.log(this.subMenusList)
				
				this.$forceUpdate() 
			},
			// 切换病型
			changetype(t){
				// console.log(t)
				// this.type=t
				// this.$forceUpdate() 
			},
			// 跳转到已选产品页面
			toProduct(shoppes){
				uni.navigateTo({
					url:"/pages/index/Products/Products",
				})
			},
			// 确定选择常用套餐商品
			confirmSelect(){
				if(!this.notAllowed){
					this.toast("请勿重复点击")
					return
				}
				if(this.Active==1){
					this.toast("展示商品不支持下单")
					return
				}
				let setMealId=this.subMenus[this.twonum].threeMenu[this.tabnum].id?this.subMenus[this.twonum].threeMenu[this.tabnum].id:[]
				console.log(this.subMenusList.length)
				if(this.subMenusList.length==0){
					this.toast("该套餐下没有商品")
					return
				}
				this.notAllowed=false
				setTimeout(()=>{
						this.notAllowed = true;
				}, 1000)
				
				// console.log(setMealId)
				// for(let i=0;i<result.length;i++){
				// 	if(result[i].packageCount>result[i].count){
				// 		this.toast("库存不足,无法下单")
				// 		return
				// 	}
				// }
				insertSetMeal({setMealId:setMealId,times:"1"}).then(res=>{
					if(res.code==200){
						// console.log(res.data)
						uni.showToast({
							title: '成功加入已选',
							icon:"none",
							success() {
								uni.navigateTo({
									url:'/pages/index/Products/Products'
								})
							}
						});
					}else{
						this.toast(res.msg)
					}
				})
			},
			// 商品数量改变的时候触发的函数
			valChange(shop) {
				let arr=this.shoppes
				let index=arr.findIndex(item=>item.id==shop.id);
				if(index==-1){
					arr.push(shop)
				}else{
					arr[index]=shop
				}
				let result=[];
				arr.forEach(function(value){
					if(value.goodNum>0){
						result.push(value)
					}
				})
				this.shoppes=result
				console.log(this.shoppes)
				// this.shoppes.push(shop)
			}
		},
		onHide() {
			uni.hideLoading()
		},
		onShow() {
			// console.log("onshow")
			gateGorylist({}).then(res=>{
				if(res.code===200){
					this.tabBars = JSON.parse(JSON.stringify(res.data).replace(/categoryName/g, "name"));
					// console.log(this.tabBars)
					this.onTabTap(0)
				}
			})
		},
		mounted(){
			// console.log("mounted")
			gateGorylist({}).then(res=>{
				if(res.code===200){
					this.tabBars = JSON.parse(JSON.stringify(res.data).replace(/categoryName/g, "name"));
					// console.log(this.tabBars)
					this.onTabTap(0)
				}
			})
		}
	}
</script>

<style lang="scss" scoped>
	.status_bar {
		height: var(--status-bar-height);
		width: 100%;
		background: #FFFFFF;
	}
	.nav-icon{
		color: $zhbgColor !important;
	}
	.shoplist{
		width: 750rpx;
		// height: 1334rpx;
		background: #FAFAFA;
	}
	.shoplist-main{
		display: flex;
		width: 100%;
		margin-bottom: 150rpx;
		.shoplist-main-left{
			// flex:1 1 220rpx;
			// display: inline-block;
			// width: 20%;
			// height: 1130rpx;
			background: #FFFFFF;
			opacity: 1;
			box-sizing: border-box;
			display: inline-block;
			margin-top: 0;
			width: 220rpx;
			// padding: 0 20rpx;
			view{
				width: 100%;
				// height: 88rpx;
				background: #FFFFFF;
				line-height: 88rpx;
				text-align: center;
				text{
					display: block;
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
				}
				.collapse-item{
					width: 100%;
					// border-bottom: 1rpx solid #CCCCCC;
					.collapse-child{
						overflow:hidden; //超出的文本隐藏
						text-overflow:ellipsis; //溢出用省略号显示
						white-space:nowrap; 
						width: 100%;
						height: 88rpx;
						// background: #f7f7f7;
						font-size: 28rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #333333;
					}
				}

			}
		}
		.shoplist-main-right{
			flex: 2 1 530rpx;
			display: inline-block;
			padding: 0 30rpx;
			width:530rpx;
			box-sizing: border-box;
			// display: flex;
			.smrbox{
				flex:1;
				.smr-top{
						text-align: center;
						padding: 25rpx 0;
						view{
							width: 200rpx;
							height: 80rpx;
							color: #2966C1;
							border: 2px solid #2966C1;
							border-radius: 100rpx 0rpx 0rpx 100rpx;
							font-size: 29rpx;
							font-family: PingFang SC;
							font-weight: 400;
							line-height: 80rpx;
							text-align: center;
							display: inline-block;
							
						}
						view:nth-child(2){
							border-radius: 0rpx 100rpx 100rpx 0rpx;
						}
						.active{
							background: #2966C1;
							color: #FFFFFF;
						}
					}
					.smr-bottom{
						height: 1000rpx;
						overflow: auto;
						.smr-shop{
							// width: 471rpx;
							height: 78rpx;
							background: #FFFFFF;
							display: flex;
							align-items: center;
							padding: 0 20rpx;
							text{
								// width: 267px;
								flex: 2;
								font-size: 24rpx;
								font-family: PingFang SC;
								font-weight: 400;
								color: #333333;	
								text-align: center;
								overflow:hidden; //超出的文本隐藏
								text-overflow:ellipsis; //溢出用省略号显示
								white-space:nowrap; 
							}
						}
					}
					
				}
			}
	}
	.shoplist-footer{
		width: 750rpx;
		height: 140rpx;
		background: #FFFFFF;
		box-shadow: 0px -1px 4px rgba(86, 86, 86, 0.16);
		position: fixed;
		bottom:0rpx;
		display: flex;
		align-items: center;
		view:nth-child(1){
			flex:1;
			text-align: right;
			margin-right: 25rpx;
			view{
				display: inline-block;
				width: 260rpx;
				height: 80rpx;
				background: #176CDC;
				border-radius: 66rpx;
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: 400;
				line-height: 80rpx;
				color: #FFFFFF;
				text-align: center;	
			}
		}
		view:nth-child(2){
			flex:1;
			view{
				width: 260rpx;
				height: 80rpx;
				background: #FF4040;
				border-radius: 66rpx;
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: 400;
				line-height: 80rpx;
				color: #FFFFFF;
				text-align: center;
				margin-left: 25rpx;
			}
		}
	}
	.changebg{
		background: #d9e1e0 !important;
	}
	/deep/.scroll-h{
		border: none;
	}
	.shoplistnav{
		// display: flex;
		width: 750rpx;
		// height: 88rpx;
		background: #FFFFFF;
		align-items: center;
		padding: 0 0rpx;
		overflow: hidden;
		box-sizing: border-box;
		.nav{
			// height: 88rpx;
			font-size: 32rpx !important;
		}
		.u-line-1{
			font-size: 32rpx !important;
		}
	}
	.normal{
		color: #666666;
	}
	.active{
		color:$zhbgColor;
	}
</style>
