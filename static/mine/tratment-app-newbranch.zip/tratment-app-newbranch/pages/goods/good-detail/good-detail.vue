<template>
	<!-- 商品详情界面 -->
	<view class="shopdetail">
		<view class="shopdetail-main">
			<!-- 图片 -->
			<view class="shopdetail-main-image">
				<!-- <image :src="attachments" mode=""></image> -->
				<u-swiper :list="lists"  height="500"></u-swiper>
			</view>
			<text class="shopdetail-main-detail">商品描述</text>
			<view class="shopdetail-main-bottom">
				<text>{{shopdetail.description}}</text>
				<!-- <image src="a4.jpg" mode=""></image> -->
			</view>
			<!-- 商品 -->
			<view class="shopdetail-main-shoptype">
				<text style="padding: 0rpx 0 30rpx 30rpx;">产品规格</text>
				<view v-for="(item,index) in items" class="shoptype" :key="index">
					<view class="shoptype-left">
						<view class="shoptype-left-top">
							<text>
								<text v-if="item.specificationsParam">{{item.specificationsParam}}</text>
								<text v-if="item.specificationsName">
									{{item.specificationsName}}({{item.specificationsValue}})
								</text>
								
							</text>
							<!-- <text>{{item.specificationsValue}}</text> -->
							<text>￥{{item.money}}</text>
						</view>
						<view class="shoptype-left-bom">
							<!-- <text>￥{{item.money}}</text> -->
							<text>当前库存:{{item.count}}</text>
						</view>
					</view>
					<view class="shoptype-right">
						<!-- 数量 -->
						<view class="num" v-if="type==='0'&&isShow==='0'">
							<u-number-box @change="valChange(item)" :max="item.count" v-model="item.num" :input-width="44" :input-height="44" :key="item.id"></u-number-box>
						</view>
						<view class="num" v-if="type==='1'||isShow==='1'">
							<u-number-box disabled v-model="item.counts" :input-width="44" :input-height="44" :key="item.id"></u-number-box>
						</view>
					</view>
				</view>
				<view class="total" v-if="type==='0'&&isShow==='0'">
					合计:
					<text>¥{{total}}</text>
				</view>
			</view>
			<!-- 	商品详情 -->

		</view>
		<!-- 底部的按钮 -->
		<view class="shoplist-footer" v-if="type=='0'&&isShow=='0'">
			<view>
				<view @click="toProduct()">查看已选</view>
			</view>
			<view>
				<view @click="toDemand()">加入已选</view>
			</view>
		</view>
		<u-toast ref="uToast" />
	</view>
</template>

<script>
	import {viewGoods,addselectshop} from "@/util/request.js"
	export default{
		data:function(){
			return{
				lists:[],
				items:[],
				shopdetail:[],
				shoppes:[],
				header:"https://tech.a6shop.net:8058/smartMedicalFile/file/",
				id:'',
				total:0,
				type:"0",
				isShow:'0',
				dis:true
			}
		},
		computed:{
			// total:function(){
			// 	let sum=0;
			// 	this.items.forEach(value=>{
			// 		sum=parseInt(value.num)*parseInt(value.money)+sum
			// 	})
			// 	return sum
			// }
		},
		onLoad(option) {
			if(option.type){this.type=option.type}
			if(option.isshow){this.isShow=option.isshow}
			console.log(option.id)
			this.id=option.id
			this.init()
			this.setMealId=option.setMealId
		},
		onShow() {
			this.shoppes=[]
			this.dis=true
			this.lists=[]
			this.items=[],
			this.total=0
			this.init()
			this.$forceUpdate()
		},
		methods: {
			init(){
				viewGoods({id:this.id}).then(res=>{
					if(res.code===200){
						this.shopdetail = res.data
						if(res.data.medicalGoodsSpecifications){
							let med = res.data.medicalGoodsSpecifications
							for (let i = 0; i < med.length; i++) {
								med[i].num = 0
							}
							this.items = med
						}
						console.log(this.items)
						if (res.data.attachments) {
							let urls = res.data.attachments;
							let url;
							for (let i = 0; i < urls.length; i++) {
								this.lists.push(this.header + urls[i].attachmentUrl)
							}
						}
					}
				})
			},
			// 商品数量改变的时候触发的函数
				valChange(shop) {
					// console.log(shop)
					let arr=this.shoppes
					if(shop.num==0){
						let result=[];
						arr.forEach(function(value){
							// console.log(value,'value')
							if(value.num>0){
								result.push(value)
							}
						})
						this.computedtotal()
						this.shoppes=result
						this.$forceUpdate()
						return
					}
					let obj={}
					obj.count=shop.num
					obj.specificationsId=shop.id
					obj.goodsId=this.id
					obj.money=shop.money
					obj.times=shop.num
					obj.setMealId=this.setMealId
					let index=arr.findIndex(item=>item.specificationsId==shop.id);
					if(index==-1){
						arr.push(obj)
					}else{
						arr[index]=obj
					}
					let result=[];
					arr.forEach(function(value){
						// console.log(value,'value')
						if(value.count>0){
							result.push(value)
						}
					})
					this.computedtotal()
					this.shoppes=result
					this.$forceUpdate()
					// this.items.forEach(value=>{
					// 	console.log(parseInt(value.num)*parseInt(value.money))
					// })
				},
				// 计算商品总价
				computedtotal(){
					let sum=0;
					this.items.forEach(value=>{
						sum=parseFloat(value.num)*parseFloat(value.money)+sum
					})
					this.total=sum.toFixed(2)
				},
				// 跳转到已选产品页面
				toProduct(shoppes){
					if(!this.dis){return}
					this.dis=!this.dis
					uni.navigateTo({
						url:"/pages/index/Products/Products",
						success() {
							this.dis=!this.dis
						}
					})
				},
				// 跳转到下单页面
				toDemand(){
					console.log(this.shoppes,"123")
					if(!this.dis){return}
					this.dis=!this.dis
					if(this.shoppes.length>0){
						addselectshop(this.shoppes).then(res=>{
							if(res.code==200){
								console.log(res.data)
								this.$refs.uToast.show({
									title: '成功加入已选',
									type: 'success',
									url:"/pages/index/Products/Products"
								})
							}else{
								this.dis=!this.dis
								this.$refs.uToast.show({
									title: '添加商品失败',
									type: 'warning'
								})
							}
						})
					}else{
						this.dis=!this.dis
						this.$refs.uToast.show({
							title: '请选择商品规格',
							type: 'warning'
						})
					}
				}
			}
		}
</script>

<style lang="scss" scoped>
	.shopdetail {
		width: 750rpx;
		height: 1334rpx;
		background: #FAFAFA;
	}

	.shopdetil-header {
		width: 100%;
		height: 84rpx;
		line-height: 84rpx;
		background-color: white;
		display: flex;
		padding: 0 30rpx;
		box-sizing: border-box;

		text:nth-child(1) {
			flex: 1;
		}

		text:nth-child(2) {
			font-family: Source Han Sans CN;
			font-size: 36rpx;
			font-weight: 400;
			flex: 1;
			color: #333333;
			text-align: center;
		}

		view {
			flex: 1;
			text-align: right;

			image {
				width: 29rpx;
				height: 28rpx;
			}

		}
	}

	.shopdetail-main {
		.shopdetail-main-image {
			// height: 400rpx;
			// image {
			// 	width: 100%;
			// 	height: 470rpx;
			// }
		}

		.shopdetail-main-shoptype {
			.shoptype {
				display: flex;
				align-items: center;
				background: #FFFFFF;
				box-sizing: border-box;
				border-top: 1rpx solid #EEEEEE;
				padding: 20rpx 30rpx;

				.shoptype-left {
					flex: 3;
					font-family: PingFang SC;
					font-weight: 400;
					display: flex;
					flex-direction: column;

					.shoptype-left-top {
						display: flex;
						padding-bottom: 10rpx;

						text {
							flex: 1;
							font-size: 32rpx;
						}
						text:nth-child(1){
							font-size: 28rpx;
							flex: 2;
						}
						text:nth-child(2){
							color: red;
						}
					}

					.shoptype-left-bom {
						display: flex;

						text:nth-child(1) {
							flex: 1;
							font-size: 22rpx;
							// color: red;
						}

						text:nth-child(2) {
							flex: 1;
							font-size: 24rpx;
							// color: #E5E5E5;
						}
					}
				}

				.shoptype-right {
					flex: 2;

					.num {
						width: 132rpx;
						height: 38rpx;
						display: flex;
						margin-right: 30rpx;
						margin-left: auto;
					}

				}
			}
		}

		.shopdetail-main-detail {
			display: inline-block;
			padding: 22rpx 0 23rpx 30rpx;
			font-size: 32rpx;
			font-family: PingFang SC;
			font-weight: bold;
			color: #176CDC;
		}

		.shopdetail-main-bottom {
			width: 100%;
			background: #FFFFFF;
			padding: 25rpx 30rpx;
			margin-bottom: 100rpx;
			text {
				word-break: break-all;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
			}

			image {
				width: 690rpx;
				height: 322rpx;
				margin-top: 20rpx;
			}
		}

	}

	.shoplist-footer {
		width: 750rpx;
		height: 99rpx;
		background: #FFFFFF;
		box-shadow: 0px -1px 4px rgba(86, 86, 86, 0.16);
		position: fixed;
		bottom: 0rpx;
		display: flex;
		align-items: center;

		view:nth-child(1) {
			flex: 1;
			text-align: right;
			margin-right: 25rpx;

			view {
				display: inline-block;
				width: 260rpx;
				height: 68rpx;
				background: #176CDC;
				border-radius: 44rpx;
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: 400;
				line-height: 68rpx;
				color: #FFFFFF;
				text-align: center;
			}
		}

		view:nth-child(2) {
			flex: 1;

			view {
				width: 260rpx;
				height: 68rpx;
				background: #FF4040;
				border-radius: 44rpx;
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: 400;
				line-height: 68rpx;
				color: #FFFFFF;
				text-align: center;
				margin-left: 25rpx;
			}
		}
	}
	.total{
		display: inline-block;
		text-align: right;
		width: 100%;
		margin-bottom: 150rpx;
		padding-right: 30rpx;
		margin-top: 50rpx;
		font-size: 32rpx;
		text{
			padding-left:20rpx;
			color:red;
		}
	}
</style>
