<template>
	<view class="search">
		<!-- <uni-nav-bar fixed>
			<view slot="left" @click="back()"><uni-icons type="back"></uni-icons></view>
			<view slot="default" class="title">搜索产品</view>
		</uni-nav-bar> -->
	<!-- 	搜索栏 -->
		<view class="search-nav">
			<view class="search-icon">
				<uni-icons type="search" class="icon"></uni-icons>
			</view>
			<input type="text" placeholder="请输入搜索内容" cursor="2" v-model="name">
			<text @click="searchMethod()">搜索</text>
		</view>
		<!-- 搜索商品结果展示 -->
		<view class="search-show">
			<view class="shop-result" v-for="result  in results">
				<text>{{result.name}}</text>
				<view>
					<view class="confirm" @click="confirm(result.id,result.setMealId)">确认选择</view>
				</view>
			</view>
			
		</view>
		<!-- 搜索结果为空 -->
		<view v-if="results.length==0" style="background-color:#FAFAFA;">
			<u-empty mode="search"></u-empty>
		</view>
	</view>
</template>

<script>
	import {gateGorylist,searchGoods} from "@/util/request.js"
	export default {
		data() {
			return {
				name:"",
				results:[],
				total:0,
				pageNum:1
			}
		},
		// 下拉到底
		onReachBottom(){
			if(this.total>(15*this.pageNum)){
				this.pageNum++
				this.search()
			}
		},
		methods: {
			changeClick(e) {
				console.log(e.detail);
				this.textareaVal = e.detail
			},
			back(){
				uni.navigateBack({
					delta:1
				})
			},
			searchMethod(){
				this.results=[]
				this.total=0
				this.pageNum=1
				this.search()
			},
			// 点击搜索
			search(){
				searchGoods({name:this.name,pageSize:15,pageNum:this.pageNum}).then(res=>{
					if(res.code===200){
						if(res.data.rows){
							console.log(res.data.rows)
							this.results=this.results.concat(res.data.rows)
							this.total=res.data.total
						}
					}
				})
			},
			// 跳转至商品详情页面
			confirm(id,setMealId){
				uni.navigateTo({
					url:"/pages/goods/good-detail/good-detail?id="+id+"&type=0"+"&setMealId="+setMealId
				})
				// console.log(id)
			}
		}
	}
</script>

<style lang="scss" scoped>
	.search{
		width: 100%;
		height: 1334rpx;
		background: #FAFAFA;
		font-family: PingFang SC;
		font-weight: 400;
	}
	.status_bar {
		height: var(--status-bar-height);
		width: 100%;
		background: #FFFFFF;
		position: fixed;
		top: 0;
		z-index: 999999;
	}
	.status_bar1 {
		height: var(--status-bar-height);
		width: 100%;
	}
	/deep/.uni-navbar--border {
		border: none;
	  width: 100%;
	}
	/deep/.uni-searchbar__box{
		width: 100%;
		border: none;
	}
	.title{
		margin:0 auto;
		font-size: 36rpx;
		font-family: Source Han Sans CN;
		font-weight: 400;
		color: #333333;
	}
	.search-nav{
		width:100%;
		height: 88rpx;
		background: #FFFFFF;
		opacity: 1;
		display: flex;
		align-items: center;
		box-sizing: border-box;
		padding: 0 30rpx;
		.search-icon{
			flex:1;
			width: 100%;
			height: 58rpx;
			background: #FAFAFA;
			border-radius: 34rpx 0rpx 0rpx 34rpx;
			text-align: right;
			line-height: 58rpx;
		}
		input{
			flex: 9;
			width:100%;
			height: 58rpx;
			background: #FAFAFA;
			border-radius: 0rpx 34rpx 34rpx 0;
			font-size: 24rpx;
			color: #AAAAAA;
		}
		text{
			flex:2;
			text-align: right;
			font-size: 29rpx;
			color: #176CDC;
		}
	}
	.search-show{
		width: 100%;
		box-sizing: border-box;
		padding:0 30rpx;
		margin-top: 20rpx;
		background: #FFFFFF;
		opacity: 1;
		.shop-result{
			display: flex;
			align-items: center;
			padding: 30rpx 0;
			text{
				flex:2;
				font-size: 29rpx;
				color: #666666;
			}
			view{
				flex:1;
				text-align: right;
				
				.confirm{
					width: 140rpx;
					height: 58rpx;
					line-height: 58rpx;
					background: #176CDC;
					text-align: center;
					border-radius: 29rpx;
					display: inline-block;
					font-size: 24rpx;
					color: #FFFFFF;
				}
			}
		}
	}
</style>
