<template>
	<view>
		<view class="my-tabs">
			<text :class="active===index?'active':''" v-for="(item,index) in datalist" :key="index" @click="changeClick(index)">{{item.value}}</text>
		</view>
	</view>
</template>
<script>
	export default {
		props:['datalist'],
		data() {
			return {
				active:0,
			}
		},
		methods: {
			changeClick(index){
				this.active=index
				this.$emit('change',index)
			}
		}
	}
</script>

<style lang="scss">
.my-tabs{
	display: flex;
	border-bottom: 2rpx solid #bbb;
	width: 100%;
	justify-content: space-around;
	text{
		// flex: 1;
		padding: 10rpx 20rpx;
		text-align: center;
	}
	.active{
		color: #E94B6C;
		border-bottom: 4rpx solid #E94B6C;
	}
}
</style>
