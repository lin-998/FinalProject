<template>
	<view>
		<view class="material-tab">
			<view :class="Active===1?'x active':'tabs'" @click="changeClick(1)">
				{{value}}
				<u-icon name="arrow-down" :class="Active===1?'uIcon active':'uIcon'" size="28"></u-icon>
			</view>
			<view :class="Active===2?'tabs active':'tabs'" @click="changeClick(2)">
				关于我们
			</view>
			<view :class="Active===3?'tabs active':'tabs'" @click="changeClick(3)">
				公告
			</view>
			<view v-show="dropdownactive" class="dropdown">
				<view v-for="(item,index) in valList" :key="index" @click="dropdownClick(index)">{{item}}</view>
			</view>
		</view>
		<view class="tabs-list">
			<view v-show="Active===1">
				<slot name="tab1"></slot>
			</view>
			<view v-show="Active===2">
				<slot name="tab2"></slot>
			</view>
			<view v-show="Active===3">
				<slot name="tab3"></slot>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		getOursList,
		getNotice,
		getInformationList
	} from "@/util/request.js"
	export default {
		props: ['activelist'],
		data() {
			return {
				Active: 2,
				valList:['视频相关','图片相关','文件相关'],
				value:'资料相关',
				dropdownactive: false
			}
		},
		watch: {
			activelist(newValue) {
				this.Active = newValue
				this.changeClick(this.Active)
			}
		},
		methods: {
			changeClick(index) {
				uni.setStorageSync("material",index)
				if(index === 1){
					this.dropdownactive=true
					return
				}
				this.value="资料相关"
				this.dropdownactive=false
				if (index === 2) {
					this.Active = index
					getOursList({
						pageSize: 10,
						pageNum: 1
					}).then(res => {
						this.$emit("getOursList", res.data.rows)
						// this.aboutList=res.data.rows
					});
				} else if (index === 3) {
					this.Active = index
					getNotice({
						pageSize: 10,
						pageNum: 1
					}).then(res => {
						this.$emit("getNotice", res.data.rows)
					});
				}
			},
			dropdownClick(index) {
				getInformationList({
					pageSize: 10,
					pageNum: 1,
					type:index
				}).then(res => {
					this.$emit("getInformationList", res.data.rows)
				});
				this.value=this.valList[index]
				this.dropdownactive=false
				this.Active = 1
			}
		},
	}
</script>

<style lang="scss">
	.uIcon {
		color: $zhbgColor !important;
	}

	.material-tab {
		position: relative;
		padding: 15rpx 0;
		background: #FFFFFF;
		display: flex;
		justify-content: space-around;
		color: $zhbgColor;

		.tabs {
			display: flex;
			justify-content: space-around;
			text-align: center;
			line-height: 58rpx;
			font-size: 28rpx;
			width: 184rpx;
			height: 58rpx;
			border: 1rpx solid $zhbgColor;
			border-radius: 10rpx;
		}

		.dropdown {
			position: absolute;
			top: 80rpx;
			left: 0;
			width: 100%;
			background: #FFFFFF;
			z-index: 9999;
			display: flex;
			flex-direction: column;

			view {
				padding: 20rpx 40rpx;
				border-bottom: 1rpx solid #eeeeee;
				&:hover {
					background: $zhbgColor;
					color: #fff !important;
				}
			}

		}
	}

	// .dropdown-active{
	// 	background: $zhbgColor;
	// 	color: #fff !important;
	// }
	.tabs-list>view {
		// padding-top: 20rpx;
	}

	.tabs.active,
	.uIcon.active {
		background: $zhbgColor;
		color: #fff !important;
	}
</style>
