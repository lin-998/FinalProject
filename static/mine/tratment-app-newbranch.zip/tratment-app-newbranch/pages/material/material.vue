<template>
	 <!-- @click="datatype=false" -->
	<view class="material" style="margin-bottom: 150rpx;">
		<view class="material-top">
			<view @click="tabsActive(0)" :class="activeId===0?'tabs data-list active':'tabs data-list'">
				<view style="display: flex;justify-content: space-around;">
					<text>{{dataValue}}</text>
					<u-icon name="arrow-down" size="28"></u-icon>
				</view>
				<view class="data-modal" v-show="datatype">
					<view class="data-list-in">
						<view @click.stop="dataTypelist(2)" style="border-bottom: 1rpx solid #176CDC">图片相关</view>
						<view @click.stop="dataTypelist(1)" style="border-bottom: 1rpx solid #176CDC">视频相关</view>
						<view @click.stop="dataTypelist(0)">文档相关</view>
					</view>
				</view>
			</view>
			<view @click="tabsActive(1)" :class="activeId===1?'tabs active':'tabs'">关于我们</view>
			<view @click="tabsActive(2)" :class="activeId===2?'tabs active':'tabs'">公告</view>
		</view>
			<view class="about-list">
				<view class="about" v-for="item in aboutList" :key="item.id">
					<view class="about-title">
						{{item.title}}
					</view>
					<image style="border-radius: 10rpx;"
					 v-show="dataValue==='视频相关'" 
					 :src="item.screenshotUrl" @click="toVideo(item)"></image>
					<image 
					v-show="dataValue==='图片相关'" 
					:src="item.attachmentUrl" 
					@click="previewImg(item.attachmentUrl)"
					style="width: 100%;border-radius: 10rpx;" mode="widthFix"></image>
					<a v-show="dataValue==='文档相关'">{{item.attachmentName}}</a>
					<!-- <a v-show="dataValue==='文档相关'" style="width: 100%;">{{item.attachmentName}}</a> -->
					<image 
					v-if="item.medicalAboutOursAttachmentList" 
					@click="previewImg(item.medicalAboutOursAttachmentList[0].attachmentUrl)"
					:src="item.medicalAboutOursAttachmentList[0].attachmentUrl"
					style="border-radius: 10rpx;"
					mode="widthFix"></image>
					<view class="about-content">
						<view class="about-subtitle">
							<text>{{item.description}}</text>
							<text>{{item.createTime}}</text>
						</view>
						<a v-show="dataValue==='文档相关'">
							<u-button shape="circle" size="medium" type="primary" @click="loaddown(item.attachmentUrl)">查看</u-button>
						</a>
						<!-- <u-button v-show="dataValue!=='文档相关'" @click="download(item.id)" v-if="activeId!==2" shape="circle" size="medium" type="primary">下载</u-button> -->
					</view>
				</view>
			</view>
	</view>
</template>

<script>
	import {
		getOursList,
		getNotice,
		getInformationList,
		getDownload
	} from "@/util/request.js"
	export default {
		data() {
			return {
				material:null,
				dataValue: "资料",
				activeId: 1,
				datatype: false,
				aboutList: [],
				InformationList: []
			}
		},
		methods: {
			toVideo(item){
				let obj = encodeURIComponent(JSON.stringify(item))
				uni.navigateTo({
					url:"/pages/material/video/video?item="+obj
				})
			},
			loaddown(url){
				// let user=uni.getStorageSync("userInfo").roles[0].roleName
				// if(user=="游客"){
				// 	this.toast("没有权限访问,请联系管理员∩_∩")
				// 	return
				// }
				uni.downloadFile({
				  url: url,
				  success: function (res) {
				    var filePath = res.tempFilePath;
				    uni.openDocument({
				      filePath: filePath,
				      success: function (res) {
				        console.log('打开文档成功');
				      }
				    });
				  }
				});
			},
			previewImg(logourl) {
				let _this = this;
				let imgsArray = [];
				imgsArray[0] = logourl
				uni.previewImage({
					current: 0,
					urls: imgsArray
				});
			},
			vds(){
				uni.navigateTo({
					url:"../goods/good-detail/good-detail"
				})
			},
			// download(id) {
			// 	getDownload({id: id}).then(res => {
			// 		console.log(res);
			// 	})
			// },
			tabsActive(index) {
				console.log(index===1)
				uni.setStorageSync("material", index)
				if (index === 0) {
					return this.datatype = !this.datatype
				}
				// if(uni.getStorageSync("material")==index && this.aboutList.length!=0)return
				if (index === 1) {
					getOursList({
						pageSize: 10,
						pageNum: 1
					}).then(res => {
						this.activeId = index
						this.aboutList = res.data.rows?res.data.rows:[]
					});
				} else if (index === 2) {
					getNotice({
						pageSize: 10,
						pageNum: 1
					}).then(res => {
						this.activeId = index
						this.aboutList = res.data.rows?res.data.rows:[]
						this.aboutList.map(val => {
							val.description = val.content
						})
					});
				}
				this.datatype = false
				this.dataValue = '资料'
			},
			// attachmentClass
			dataTypelist(index) {
				// this.activeId = index
					getInformationList({pageSize: 10,pageNum: 1,type:index}).then(res => {
						if(res.code==200){
							this.aboutList = res.data.rows?res.data.rows:[]
							this.aboutList.map(val=>{
								val.title=val.name
								val.description=val.attachmentDesc
							})
							this.dataValue = index==0?"文档相关":index==1?"视频相关":"图片相关"
							this.datatype = false
							this.activeId = 0
						}
					});
			}
		},
		onLoad() {
			console.log(13);
			if (uni.getStorageSync("material")) {
				this.tabsActive(uni.getStorageSync("material"))
			} else {
				this.tabsActive(1)
			}
		},
		onShow() {
			if(!uni.getStorageSync("material"))return
			this.material=uni.getStorageSync("material")
		},
		watch:{
			material(){
				this.tabsActive(this.material)
			}
		}
	}
</script>

<style lang="scss" scoped>
	a{
		text-decoration: none;
	}
	.data-modal{
		margin-left: -45rpx;
		width: 100vw;
		height: 100vh;
	}

	.material-top {
		display: flex;
		justify-content: space-around;
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		z-index: 9999;
		padding: 15rpx;
		background-color: #FFFFFF;
		margin-bottom: 20rpx;

		.tabs {
			width: 184rpx;
			height: 58rpx;
			border: 1rpx solid $zhbgColor;
			line-height: 58rpx;
			text-align: center;
			opacity: 1;
			border-radius: 10rpx;
			color: $zhbgColor;
			font-size: 28rpx;
		}

		.data-list {
			position: relative;
			.data-list-in {
				z-index: 999;
				position: absolute;
				top: 56rpx;
				left: 0;
				width: 100%;
				background-color: #FFFFFF;
				color: $zhbgColor;
				border: 1rpx solid $zhbgColor;
				border-radius: 10rpx;
				view {
					// border: 1rpx solid $zhbgColor;
					border-top: none;
					// border-radius: 10rpx;
					&:active {
						color: #FFFFFF;
						background: $zhbgColor;
					}
				}
			}
		}

		.active {
			color: #FFFFFF;
			background: $zhbgColor;
		}
	}
.about-list{
	margin: 80rpx 0 0;
}
	.about {
		background: #FFFFFF;
		padding: 25rpx 30rpx;
		margin-top: 20rpx;
		.about-title {
			font-size: 32rpx;
			color: $zhbgColor;
			margin-bottom: 20rpx;
		}

		image {
			width: 100%;
			// margin: 20rpx 0;
		}

		.about-content {
			display: flex;
			justify-content: space-between;
			align-items: center;

			.about-subtitle {
				flex: 1;
				display: flex;
				flex-direction: column;

				text {
					font-size: 24rpx;
					padding: 10rpx 0;

					&:nth-child(2) {
						color: #999999;
						padding: 0;
					}
				}
			}
		}
	}
</style>
