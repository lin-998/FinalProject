<template>
	<view class="about-list">
		<view class="about">
			<view class="about-title" style="text-align: center;">
				{{item.title}}
			</view>
			<video :src="item.attachmentUrl" controls autoplay class='video'></video>
			<view class="about-content">
				<view class="about-subtitle">
					<text>{{item.description}}</text>
					<text>{{item.createTime}}</text>
				</view>
				<u-button @click="download(item.attachmentUrl)" shape="circle" size="medium" type="primary">下载</u-button>
			</view>
		</view>
		<u-toast ref="uToast" />
	</view>
</template>

<script>
	export default({
		data:function(){
			return{
				item:{},
				header: {
					'X-Requested-Token': uni.getStorageSync('token')
				},
			}
		},
		onLoad(option) {
			const obj = JSON.parse(decodeURIComponent(option.item));
			this.item=obj
			console.log(obj)
		},
		methods:{
			async download(url){
				let user=uni.getStorageSync("userInfo")?uni.getStorageSync("userInfo").roles[0].roleName:"游客"
				if(user=="游客"){
					this.toast("没有权限访问,请联系管理员∩_∩")
					return
				}
				let self=this
				// 1.将远程文件下载到小程序的内存中,tempFilePath
				this.$refs.uToast.show({
								title: '下载中'
				})
				const result1 = await uni.downloadFile({ url:url})
				const {tempFilePath} = result1[1]
				// 2.将小程序内存中的临时文件下载到本地上
				const result2 = await uni.saveVideoToPhotosAlbum({
					// uni.saveVideoToPhotosAlbum()
					filePath:tempFilePath,
					success: function () {
							self.$refs.uToast.show({
									title: '下载成功'
							})
						}
				})
				
				// uni.downloadFile({
				//     url: url, //仅为示例，并非真实的资源
				// 		// header:self.header,
				//     success: (res) => {
				// 			if (res.statusCode === 200) {
				// 				const result2 = await uni.saveImageToPhotosAlbum({
				// 								// uni.saveVideoToPhotosAlbum()
				// 								filePath:tempFilePath
				// 							})
				// 					console.log('下载成功');
				// 					console.log(res,'下载成功');
				// 			}
				//     },
				// 		fail() {
				// 			this.toast("fail")
				// 		}
				// });
			}
		}
	})
</script>

<style lang="less" scoped>
	.about-list{
		padding: 0 30rpx;
		.about-title{
			padding: 20rpx 0;
			font-size:32rpx;
		}
		.video{
			width: 100%;
		}
	}
	.about-content {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 0 30rpx;
		.about-subtitle {
			flex: 1;
			display: flex;
			flex-direction: column;
			text {
				font-size: 24rpx;
				padding: 10rpx 0;
	
				&:nth-child(2) {
					color: #999999;
					padding: 0;
				}
			}
		}
	}
</style>
