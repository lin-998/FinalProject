<template>
	<view>
		<view class="status_bar">
			<!-- 这里是状态栏 -->
		</view>
		<view class="status_bar1">
			<!-- 这里是状态栏 -->
		</view>
		<uni-nav-bar fixed @clickLeft="clickLeft" left-icon="back">
			<view slot="default" class="title">要货单</view>
		</uni-nav-bar>
		<view class="form-data">
			<u-form :model="form" :border-bottom="false">
				<!-- 公司 -->
				<u-form-item :border-bottom="false" label-width="160rpx" label="公司:" class="company fornitem" label-align="right">
					<view>
						<u-input  style="font-size: 24rpx;" disabled border :value="form.companyName" class="uinput"></u-input>
					</view>
				</u-form-item>
				<!-- 医院 -->
				<u-form-item :border-bottom="false"  label-width="160rpx" label="医院:" prop="name" class="hospital fornitem" label-align="right">
					<view>
						<u-input v-model="form.hospital" border class="uinput"></u-input>
					</view>
				</u-form-item>
				<!-- 手术时间 -->
				<u-form-item :start-year="2020" :border-bottom="false" label-width="160rpx" label="手术时间:" prop="name" label-align="right" class="hospital fornitem">
					<view>
						<view style="padding-left: 20rpx;" @click="show=true" class="uinput" v-if="data!=''&&data!=undefined">{{data}}</view>
						<view style="padding-left: 20rpx;" @click="show=true"  class="uinput" v-if="data==''||data==undefined">请选择手术时间</view>
						<u-picker mode="time" v-model="show" :params="params" @confirm="bindPickerChange">
						</u-picker>
					</view>
				</u-form-item>
				<!-- 品牌 -->
				<u-form-item :border-bottom="false" label-width="160rpx" label="品牌:"  class="brand fornitem" label-align="right">
					<view>
						<u-input v-model="form.brand" border class="uinput"></u-input>
					</view>
				</u-form-item>
				<!-- 产品-->
				<u-form-item :border-bottom="false" label-width="160rpx" label="产品:" class="pro fornitem" label-align="right">
					<view class="demand-goods">
						<!-- <text @click="addshop('/pages/index/Products/Products')">已选</text>
						<text @click="addshop('/pages/goods/vague-search/vague-search')">模糊搜索</text>
						<text @click="addshop('/pages/goods/goods')">类别搜索</text> -->
						<view>
							<u-button type="primary" class="but" @click="addshop('/pages/index/Products/Products')">已选</u-button>
						</view>
						<view>
							<u-button type="primary" class="but" @click="addshop('/pages/goods/vague-search/vague-search')">模糊搜索</u-button>
						</view>
						<view>
							<u-button type="primary" class="but" @click="addshop('/pages/goods/goods')">类别搜索</u-button>
						</view>
						<!-- <navigator url="/pages/index/Products/Products">已选</navigator>
						<navigator url="/pages/goods/vague-search/vague-search">模糊搜索</navigator>
						<navigator url="/pages/goods/goods">类别搜索</navigator> -->
					</view>
				</u-form-item>

				<!-- 显示已选商品 -->
				<u-form-item :border-bottom="false" class="fornitem" label-width="160rpx" label="已选商品:"  v-if="selectShop.length>0" label-align="right">
					<view class="shop-item">
						<view class="shop" v-for="(item,index) in selectShop" :key="index">
							<view>
								<uni-icons v-bind:class="item.checked ? shopselect : shopcancle" type="checkmarkempty" @click="butSlect(index)"
								 v-show="item.checked"></uni-icons>
								<uni-icons v-bind:class="item.checked ? shopselect : shopcancle" @click="butSlect(index)" v-show="!item.checked"></uni-icons>
							</view>
							<view class="shopname">
								<text class="name">
									{{item.name}}
									<text v-if="item.specificationsName">
									({{item.specificationsName}}||{{item.specificationsValue}})
									</text>
									<text v-if="item.specificationsParam">
									({{item.specificationsParam}})
									</text>
								</text>
							</view>
							<text class="shopnum">X{{item.count}}</text>
						</view>
					</view>
				</u-form-item>
				<!-- 联系人电话 -->
				<u-form-item :border-bottom="false" label-width="160rpx" label="联系人:" class="tel fornitem" label-align="right">
					<view>
						<u-input v-model="form.phone" type="number" placeholder-style="color: #888888;" border class="uinput" />
					</view>
				</u-form-item>

				<!-- 备注图片 -->
				<u-form-item :border-bottom="false" label-width="160rpx" label="备注图片:" class="img fornitem" label-align="right">
					<u-upload :max-count="4" :header="header" :action="action" upload-text="点击上传" :show-progress="false" to-json :file-list="fileList"
					 @on-change="getUploadpicList" ref="uUpload" @on-remove="handleRemovelist">
					 </u-upload>
				</u-form-item>
				<!-- 物流方式 -->
				<u-form-item :border-bottom="false" label-width="160rpx" label="物流方式:" class="met fornitem" label-align="right">
					<uni-select :selectIs="logisticsMode" :placeholder="'自提（必填）'" 
					@change="selectBtn" :width="'400rpx'" 
					style="font-weight: 400;"
					:datalist="selectList">
					</uni-select>
				</u-form-item>
			
				<!-- 合格证 -->
				<u-form-item :border-bottom="false" label-width="160rpx" label="带合格证:" class="swi fornitem" label-align="right">
					<u-switch slot="right" v-model="switchVal"></u-switch>
				</u-form-item>
				<!-- 收货地址 -->
				<u-form-item :border-bottom="false" label-width="160rpx" label="收货地址:" class="met fornitem" label-align="right">
					<view>
						<picker :range="addressArray" value="index" @change="chooseAddress">
							<view style="padding-left: 20rpx;" class="uinput">
							{{addressArray[index]}}
							</view>
						</picker>
					</view>
				</u-form-item>
				<!-- 收货地址 -->
				<!-- <u-form-item :border-bottom="false" label-width="160rpx" label="收货地址:" prop="name" class="address fornitem" label-align="right">
					<view>
						<u-input v-model="form.address" border class="uinput" />
					</view>
				</u-form-item> -->
				<!-- 备注 -->
				<u-form-item :border-bottom="false" label-width="160rpx" label="备注:" prop="name" class="remark fornitem" label-align="right">
					<view class="text-area">
						<textarea v-model="textareaVal.value" placeholder="请输入备注信息" @input="changeClick">
						 </textarea>
						<text class="text-max">{{textareaVal.cursor||0}}/500</text>
					</view>
				</u-form-item>
				<u-button shape="circle" class="submit-btn allColor" @click="submit">下单</u-button>
			</u-form>
			<u-toast ref="uToast" />
		</view>
	</view>
</template>

<script>
	import {
		overBooking,
		createQR,
		imageUpload,
		getAddressAll
	} from "@/util/request.js"
	import {
		uploadAttachment,
		deleteremark
	} from "@/util/request.js"
	export default {
		data() {
			return {
				data:"",
				params: {
					year: true,
					month: true,
					day: true,
					hour: true,
					minute: true,
					second: true
				},
				show:false,
				addressArray:[],
				index:0,
				fileList: [],
				// 上传图片
				attIds: [],
				header: {
					'X-Requested-Token': uni.getStorageSync('token')
				},
				action: imageUpload,
				// 物流方式
				logisticsMode: "",
				certificate: "0",
				addressVal: '',
				selecValue: '',
				shopselect: "shopselect",
				shopcancle: "shopcancle",
				selectShop: [],
				selectList: [{
						label: '自提',
						value: "自提"
					},
					{
						label: '物流',
						value: "物流"
					}
				],
				notAllowed:true,
				form: {},
				// 是否带合格证
				switchVal: false,
				textareaVal: {}
			}
		},
		onLoad(option) {
			// this.getQR("74")
			// 调用接口地址,获取全部地址
			getAddressAll().then(res=>{
				if(res.code===200){
					res.data.forEach(val=>{
						console.log(val)
						this.addressArray.push(val.address)
					})
					console.log(res.data)
				}
			})
			// 获取要下单的商品信息
			let storage = uni.getStorageSync('selectShop')
			this.selectShop = storage ? storage : [],
			// 获取选择商品前已填写的信息
			this.form = uni.getStorageSync("form") ? uni.getStorageSync("form") : {};
			this.data=this.form.surgeryTime?this.form.surgeryTime:''
			this.textareaVal.value=this.form.remark?this.form.remark:''
			// 获取登录时保存的个人信息
			let userInfo=uni.getStorageSync("userInfo")
			this.form.companyId = userInfo.companyId;
			this.form.phone=userInfo.phone
			this.form.address=userInfo.companyAddress
			this.form.companyName=userInfo.companyName
			// if(uni.getStorageSync('orderData')){
			// 	let orderData=JSON.parse(uni.getStorageSync('orderData'))
			// 	console.log(orderData)
			// 	orderData.medicalOrderDtos.forEach(val=>{
			// 		val.checked=true
			// 	})
			// 	this.selectShop = orderData.medicalOrderDtos
			// 	this.form.phone=orderData.phone
			// 	this.form.address=orderData.address
			// 	this.form.companyName=orderData.companyName
			// 	this.form.hospital=orderData.hospital
			// 	this.form.brand=orderData.brand
			// 	this.data=orderData.surgeryTime
			// 	// this.selectBtn({label: "物流",value: "物流"})
			// 	this.form.hospital=orderData.hospital
			// 	this.switchVal=orderData.certificate==1?true:false
			// 	this.textareaVal={
			// 		value:orderData.brand,
			// 		cursor:orderData.brand.length
			// 	}
			// }
			
		},
		onShow(){
			if(!uni.getStorageSync('orderData')){
				let storage = uni.getStorageSync('selectShop')
				this.selectShop = storage ? storage : []
				// this.form = uni.getStorageSync("form") ? uni.getStorageSync("form") : {};
				let userInfo=uni.getStorageSync("userInfo")
				this.form.companyId = userInfo.companyId;
				this.form.phone=userInfo.phone
				// this.form.address=userInfo.companyAddress
				this.form.companyName=userInfo.companyName
			}
		},
		methods: {
			// 选择收货地址
			chooseAddress(e){
				console.log(e)
				
				if(e.detail.value.toString()=="NaN"){
					this.index=0
				}else{
					this.index=e.detail.value
					console.log(this.index)
				}
				
			},
			// 选择手术时间
			bindPickerChange(e) {
					console.log(e)
					this.data=`${e.year}-${e.month}-${e.day} ${e.hour}:${e.minute}:${e.second}`
       },
			// 点击下单按钮触发事件
			submit() {
				if(!this.notAllowed){
					this.toast("已下单,请勿重复点击")
					return
				}
				this.form.surgeryTime=this.data
				this.form.brand=this.form.brand?this.form.brand:"无"
				// 物流方式
				this.form.logisticsMode =this.logisticsMode;
				// 是否带合格证
				this.form.certificate = this.switchVal==true?1:0;
				// 上传图片id
				this.form.attIds = this.attIds
				this.form.address=this.addressArray[this.index]
				// 返回选中的商品详情
				this.form.medicalOrderGoods =this.selectShop.filter(val=>{
					return val.checked==true
				})
				this.form.remark=this.textareaVal.value
				this.form.money=this.getTotal(this.form.medicalOrderGoods)
				console.log(this.form)
				if(!this.check()){
					return
				}
				this.notAllowed=false
				overBooking(this.form).then(res => {
					if(res.code===200){
						let QRId=res.data+''
						this.selectShop=[]
						this.showToast("下单成功！！", "success");
						uni.removeStorageSync('form');
						uni.removeStorageSync('selectShop')
						this.selectShop=[]
						this.form = {}
						this.attIds=[]
						this.fileList=[]
						this.getQR(QRId)
					}else{
						this.toast(res.msg)
						this.notAllowed = true;
					}
				}).catch(err=>{
					this.notAllowed = true;
					this.toast(err)
				})
			},
			getQR(id){
				createQR({id:id}).then(r=>{
					if(r.code===200){
						if(this.textareaVal.value){
							this.textareaVal.value=''
						}
						if(this.textareaVal.cursor){
							this.textareaVal.cursor=0
						}
						this.switchVal=false;
						this.$refs.uUpload.clear();
						this.$forceUpdate()
						uni.navigateTo({
							url:"/pages/user/myorder/myorder?current=0"
						})
						
					}
				})
			},
			// 计算总价
			getTotal(arr){
				console.log(arr)
				let total=0;
				arr.forEach(val=>{
					if(val.singleCount){
						total+=parseFloat(val.times)*parseFloat(val.money)
					}else{
						total+=parseFloat(val.count)*parseFloat(val.money)
					}	
				})
				return total
			},
			// 检查校验
			check() {
				let date1= this.form.surgeryTime;  //开始时间
				let date2 = new Date();    //现在时间
				let date3 =new Date(date1).getTime()-date2.getTime();
				if (this.form.hospital == undefined||this.form.hospital == '') {
					this.showToast("未填写医院名称")
					return
				} else if (this.form.surgeryTime== undefined||this.form.surgery== '') {
					this.showToast("请选择手术时间！！")
					return
				}else if (date3<=0) {
					this.showToast("手术时间不能选择过去时间！！")
					return
				}else if (this.form.medicalOrderGoods.length== 0) {
					this.showToast("未选中商品！！")
					return
				} else if (this.logisticsMode == "") {
					this.showToast("请选择物流方式！！")
					return
				}else{
					return true
				}
			},
			selectOne(options) {
				this.selecValue = options.label
				console.log(options.label);
			},
			// 备注信息
			changeClick(e) {
				console.log(e.detail);
				this.textareaVal = e.detail
			},
			// 选择物流方式
			selectBtn(e) {
				this.logisticsMode = e.value=='自提'?'1':'0'
				console.log(e)
			},
			clickLeft() {
				uni.switchTab({
					url: "../index"
				})
			},
			// 去选择商品
			addshop(u) {
				console.log(this.form)
				this.form.surgeryTime=this.data
				this.form.remark=this.textareaVal.value?this.textareaVal.value:''
				uni.setStorageSync("form", this.form)
				this.attIds=[]
				this.fileList=[]
				this.$refs.uUpload.clear();
				uni.navigateTo({
					url: u
				})

			},
			// 是否选中商品
			butSlect(i) {
				this.selectShop[i].checked = !this.selectShop[i].checked;
			},
			// 上传图片
			getUploadpicList(res, index, lists, name) {
				console.log(JSON.parse(res.data))
				this.attIds.push(JSON.parse(res.data).data.id)
				console.log(this.attIds)
			},
			// 删除上传的图片
			handleRemovelist(index, lists, name) {
				console.log(index);
				deleteremark({
					id: this.attIds[index]
				}).then(res => {
					if (res.code === 200) {
						this.attIds.splice(index, 1)
						console.log(this.attIds,"attIds")
					}
				})
			},
			// 显示提示内容
			showToast(title, type = "error") {
				this.$refs.uToast.show({
					title: title,
					type: type
				})
			}
		},
		onUnload() {
			// console.log(areaData);
			this.form={}
			uni.removeStorageSync("form");
			
		}
	}
</script>

<style lang="scss" scoped>
	
	.title {
		margin: 0 auto;
		font-size: 36rpx;
		font-family: Source Han Sans CN;
		font-weight: 400;
		color: #333333;
	}

	.status_bar {
		height: var(--status-bar-height);
		width: 100%;
		background: #FFFFFF;
		position: fixed;
		top: 0;
		z-index: 999999;
	}

	.status_bar1 {
		height: var(--status-bar-height);
		width: 100%;
	}

	/deep/.uni-navbar--border {
		border: none;
		width: 100%;
	}

	/deep/.uni-searchbar__box {
		width: 100%;
		border: none;
	}

	.form-data {
		height: 100%;
		background-color: #FFFFFF;
		.fornitem {
			font-size: 32rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #333333;
			padding: 30rpx;
			background-color: #FFFFFF;
			.uni-input-placeholder{
				font-size: 24rpx;
			}
			.uinput {
				font-size: 24rpx;
				font-weight: 400;
				width: 420rpx;
				vertical-align: middle;
				background: #FAFAFA;
				border: 1rpx solid #DDDDDD;
				border-radius: 10rpx;
				box-sizing: border-box;
				margin-left: 10rpx;
				overflow: hidden;
				text-overflow: ellipsis;
			}
		}

		.shop-item {
			padding: 30rpx;
			width: 540rpx;
			// height: 200rpx;
			background: #FAFAFA;
			border: 1rpx solid #DDDDDD;
			border-radius: 10rpx;
			.shop {
				// padding-bottom: 25rpx;
				display: flex;
				view {
					flex: 1;
					// text-align: right;
					// padding-right: 10rpx;
					width: 100%;
					align-self: center;
					.shopselect {
						width: 30rpx;
						height: 30rpx;
						border-radius: 15rpx;
						background: #176CDC;
					}

					.shopcancle {
						width: 30rpx;
						height: 30rpx;
						border-radius: 15rpx;
						background: #ffffff;
						display: inline-block;
						border: 2rpx solid #DDDDDD;
					}
				}

				.shopname {
					flex: 5;
					font-size: 24rpx;
					color: #333333;
					text-align: left;
					white-space: nowrap;
					overflow: hidden;
					text-overflow: ellipsis;
					.name{
						text{
							font-size: 16rpx;
						}
					}
				}

				.shopnum {
					flex: 1;
					text-align: right;
					font-size: 24rpx;
					color: #176CDC;
					align-self: center;
				}
			}
		}

		.text-area {
			border: 1rpx solid #ccc;
			position: relative;
			margin-left: 10rpx;
			.text-max {
				color: #888;
				font-size: 24rpx;
				position: absolute;
				bottom: 0rpx;
				right: 15rpx;
			}

			textarea {
				font-size: 24rpx;
				padding: 10rpx;
				border-radius: 10rpx;
				box-sizing: border-box;
				width: 415rpx;
				height: 170rpx;
				background: #FAFAFA;
				border-radius: 10rpx;
			}
		}

		.demand-goods {
			display: flex;
			// justify-content: space-between;
			// padding-right: 30rpx;
			// box-sizing: border-box;
			view{
				flex:1;
				.but{
					width: 80%;
					vertical-align: middle;
					// margin-right: 15rpx;
				}
			}
			
			// text {
			// 	// display: inline-block;
			// 	// border: 1rpx #007AFF solid;
			// 	padding: 20rpx 28rpx;
			// 	font-size: 28rpx;
			// 	color: #57A1F9;
			// }
		}
	}

	.u-field {
		padding-left: 0;

		.u-textarea-inner {
			display: flex;
			align-items: center !important;
		}

		.fild-body {
			border: 1rpx solid #C0C0C0 !important;
		}
	}

	.u-form-item {
		// line-height: 0rpx;
		font-size: 28rpx;
	}

	.u-border-bottom:after {
		// border: 0 solid #E3E3E3;
		// border-bottom-width: 1px;
	}

	.uni-textarea-placeholder {
		color: #888888;
		padding: 10rpx;
		box-sizing: border-box;
	}

	.u-label {
		flex: 0 0 20rpx !important;
	}

	.select-easy {
		width: 400rpx !important;
		height: 60rpx !important;
	}

	/deep/.u-line-1 {
		height: 100% !important;
		line-height: 200% !important;
	}

	.address-inp {
		width: 400rpx;
		height: 60rpx;
		padding-left: 20rpx;
		box-sizing: border-box;
		border-radius: 10rpx;
		border: 1rpx solid #bbb;
		font-size: 28rpx;

		&::after {
			content: ">";
			position: absolute;
			right: 80rpx;
			top: 50rpx;
			transform: rotate(90deg);
			width: 14px;
			height: 8px;
			color: #888;
			font-weight: 1000;
		}
	}

	.submit-btn {
		color: #fff !important;
		height: 88rpx !important;
		margin-bottom: 90rpx !important;
		margin-top: 70rpx !important;
		width: 80%;
	}
	/deep/.uni-input-input{
		font-size: 24rpx;
	}
</style>
