<template>
	<view class="products">
		<uni-nav-bar status-bar left-icon="back" @clickRight	="eEdit" @clickLeft="back()" title="已选产品">
			<view class="header-rigth" slot="right">管理</view>
		</uni-nav-bar>
		<view style="margin-bottom: 100rpx;">
			<view v-for="(menus,index) in products" style="">
				<view class="products-icon">
						{{menus.categoryName}}>{{menus.menuName}}
					</view>
				<view v-if="menus.categoryName!='常用套餐'" class="products-in" v-for="(product,index) in menus.medicalOrderGoodsDtoList" :key="index">
					<view class="products-card">
							<u-checkbox-group class="u-checkbox-1">
								<u-checkbox v-model="product.checked" class="menuName" shape="circle" @change="select(product)">
									<text class="text">{{menus.threeName}}</text>
								</u-checkbox>
							</u-checkbox-group>
						<view class="products-info">
							<view class="products-price">
								<text class="title" style="color:#000000;">
								{{product.name}}
								<text v-if="product.specificationsParam" style="margin-left: 10rpx;color:#666666;font-size: 20rpx;">
									({{product.specificationsParam}})
								</text>
								<text v-if="product.specificationsName" style="margin-left: 10rpx;color:#666666;font-size: 20rpx;">
									{{product.specificationsName}}
								</text>
								<!-- <text style="margin-left: 10rpx;color:#666666;font-size: 20rpx;">
									{{product.specificationsValue}}
								</text> -->
								</text>
								<text class="count">x{{product.count}}</text>
							</view>
							<view class="products-price">
								<text class="price"><text style="font-size: 20rpx;">￥</text>{{parseFloat(product.money)*parseFloat(product.count)}}</text>
								<u-number-box positive-integer @change="numClick(product)" :min="1" v-model="product.count" :max="product.allCount"></u-number-box>
							</view>
						</view>
					</view>
				</view>
				<!-- 常用套餐 -->
				<view v-if="menus.categoryName=='常用套餐'" class="products-in-2">
					<view class="products-card-2">
						<u-checkbox-group class="u-checkbox-2">
							<u-checkbox class="menuName" v-model="menus.checked" shape="circle" @change="select(menus,1)">
								<text class="text">{{menus.threeName}}</text>
							</u-checkbox>
						</u-checkbox-group>
						<view class="content">
							<view class="products-info-2"  v-for="(product,index) in menus.medicalOrderGoodsDtoList" :key="index">
								<hr v-if="index!=0" class="divide">
								<view class="products-price-2">
									<!-- 商品名称和规格 -->
									<text class="title" style="color:#000000">
									{{product.name}}
									<text v-if="product.specificationsParam" style="margin-left: 10rpx;color:#666666;font-size: 20rpx;">({{product.specificationsParam}})</text>
									<text v-if="product.specificationsName" style="margin-left: 10rpx;color:#666666;font-size: 20rpx;">({{product.specificationsName}})</text>
									<!-- <text style="margin-eft: 10rpx;color:#666666;font-size: 20rpx;">{{product.name}}</text> -->
									</text>
									<!-- 商品购买数量 -->
									<text class="title">x{{parseInt(product.singleCount)*parseInt(menus.times)}}</text>
								</view>
								<view class="products-price-2">
									<text class="price-2"><text style="font-size: 20rpx;">￥</text>{{parseFloat(product.money)*parseFloat(product.times)}}</text>
									<!-- <u-number-box v-show="isEdit" @change="numClick(product)" :min="1" v-model="product.count" :max="product.allCount"></u-number-box> -->
								</view>
							</view>
							<view class="products-2-count" style="text-align: right;">
								<u-number-box 
								 v-model="menus.times" 
								@change="changeNum(menus)" :min="1" :max="menus.max" positive-integer></u-number-box>
							</view>
						</view>
					</view>
				</view>
			
			</view>
		</view>
		<view class="products-footer">
			<u-checkbox-group class="checkbox-all">
				<u-checkbox v-model="checked" shape="circle" @change="allselect">全选</u-checkbox>
			</u-checkbox-group>
			<view>
				<u-button v-show="isEdit" class="button-tow" size="medium" shape="circle" @click="delect">删除</u-button>
				<u-button class="button-tow" type="primary" size="medium" shape="circle" @click="toDemand">立即下单</u-button>
			</view>
		</view>
		<u-toast ref="uToast" />
	</view>
</template>

<script>
	import {lookselect,deleteselect,updateMeal,editselect} from '@/util/request.js'
	export default {
		data() {
			return {
				isEdit:false,
				checked:true,
				ids:[],
				products:[],
				delectShop:false
			};
		},
		onLoad(option) {
			this.init()
		},
		onShow() {
			this.init()
		},
		methods:{
			init(){
				lookselect().then(res=>{
					if(res.code===200){
						let arr=res.data?res.data:[]
						for(let i=0;i<arr.length;i++){
							arr[i].checked=true
							arr[i].times=arr[i].medicalOrderGoodsDtoList[0].times?arr[i].medicalOrderGoodsDtoList[0].times:0
							if(arr[i].categoryName=="常用套餐"){
								let max=1000000
								arr[i].medicalOrderGoodsDtoList.forEach(value=>{
									value.singleCount=parseInt(parseInt(value.count)/parseInt(value.times))
									if((value.allCount/value.singleCount)<max){
										max=parseInt(value.allCount/value.singleCount)
									}
								})
								arr[i].max=max
								if(max<arr[i].times){
									arr[i].times=max
								}
								arr[i].medicalOrderGoodsDtoList.forEach(val=>{
									val.times=arr[i].times
								})
								// console.log(arr[i].max+"max")
								// console.log(arr[i].times+"time")
								// console.log(arr[i].max+"max")
							}
							arr[i].medicalOrderGoodsDtoList.forEach(value=>{
								value.checked=true
								if(value.count>value.allCount){
									value.count=value.allCount
								}
								// value.money=parseFloat(value.money)
								// value.times=parseFloat(value.times)
								
								// value.name=arr[i].name
							})
						}
						this.products=arr
						if(this.products.length==0){
							this.checked=false
						}else{
							this.checked=true
						}
						
						// console.log(arr,'11')
					}
				})
			},
			eEdit(){
				// console.log(132);
				this.isEdit=!this.isEdit
			},
			changeClick(inde){
				// console.log(inde);
			},
			// 点击删除时触发事件
			delect(){
				let shoppes=[]
				this.products.forEach(value=>{
					let arr=value.medicalOrderGoodsDtoList.filter(function(val){
						return val.checked==true
					})
					shoppes=shoppes.concat(arr)
				})
				shoppes.forEach(val=>{
					this.ids.push(val.id)
				})
				console.log(this.ids)
				deleteselect(this.ids).then(res=>{
					if(res.code===200){
						// console.log(res.data)
						uni.removeStorageSync("selectShop");
						this.init()
						this.delectShop=true
						this.isEdit=false
						this.$refs.uToast.show({
							title: '删除成功',
							type: 'success'
						})
					}
				})
			},
			// 点击立即下单触发的事件
			toDemand(){
				console.log(this.products+"13")
				let shoppes=[]
				this.products.forEach(value=>{
					let arr=value.medicalOrderGoodsDtoList.filter(function(val){
						return val.checked==true && val.times>0
					})
					shoppes=shoppes.concat(arr)
				})
				console.log(shoppes)
				uni.setStorageSync('selectShop', shoppes);
				uni.navigateTo({
					url:"/pages/index/demand/demand",
					fail(){
						uni.switchTab({
						    url: '/pages/index/demand/demand'
						});
					}
				})
			},
			// 是否选中商品
			select(pro,t){
				let self=this
				// console.log(this.products);
				if(t===1){
					pro.medicalOrderGoodsDtoList.forEach(val=>{
						val.checked=!val.checked
					})
				}
				// console.log(this.isAllselect())
				if(this.isAllselect()){
					this.checked=true
				}else{
					this.checked=false
				}
				
			},
			// 是否全选
			isAllselect(){
				let blo=true
				this.products.forEach(val=>{
					val.medicalOrderGoodsDtoList.forEach(value=>{
						if(!value.checked){
							blo=false
						}
					})
				})
				return blo
			},
			// 全选的事件
			allselect(){
				// console.log(this.products.length)
				if(this.products.length==0){
					this.checked=false
					return
				}
				console.log(this.products)
				this.products.forEach(value=>{
					value.checked=this.checked
					value.medicalOrderGoodsDtoList.forEach(val=>{
						val.checked=this.checked
					})
				})
				console.log(this.checked)
			},
			back(){
				uni.navigateBack({
				    delta: 1
				});
			},
			// 非常用套餐商品数量改变时触发的事件
			numClick(product){
				// console.log(product)
				if(product.count<=0){
					return
				}
				product.times=product.count
				let arr=[]
				arr.push(product)
				updateMeal(arr).then(res=>{
					if(res.code==200){
						// console.log(res.data)
						// this.init()
					}
				})
			},
			// 常用套餐商品数量改变时触发的事件
			changeNum(product){
				let arr=product.medicalOrderGoodsDtoList
				console.log(product)
				if(product.times<=0){
					return
				}
				// console.log(product)
				arr.forEach(val=>{
					let time=parseInt(val.allCount/val.singleCount)
					if(product.times<=time){
						val.times=product.times
					}else{
						
					}
				})
				// console.log(arr)
				// 商品数量改变时调用接口
				updateMeal(arr).then(res=>{
					if(res.code==200){
						// console.log(res.data)
						// this.init()
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	.header-rigth{
		color: $zhbgColor;
	}
	page{
		background: #FAFAFA;
	}
	.products {
		background-color: #fff;
		.products-icon{
			font-size: 32rpx;
			font-weight: 600;
			color: $zhbgColor;
			margin: 24rpx 0 10rpx 30rpx;
		}
		.products-in {
			
			.products-card {
				padding: 16rpx 30rpx;
				border-top: 1rpx solid #EEEEEE;
				border-bottom: 1rpx solid #EEEEEE;
				display: flex;
				justify-content: space-between;
				.u-checkbox-1 {
					flex: 3;
					.menuName{
						.text{
							display: inline-block;
							width: 180rpx;
							vertical-align: middle;
							white-space: nowrap;
							overflow: hidden;
							text-overflow: ellipsis;
						}
					}
				}
				.products-info {
					height: 100rpx;
					flex: 6;
					display: flex;
					flex-direction: column;
					justify-content: space-between;
					.products-price {
						color: #666666;
						display: flex;
						align-items: center;
						justify-content: space-between;
						.title{
							// flex: 3;
							word-break: break-all;
							overflow: hidden;
						  display:-webkit-box; //将对象作为弹性伸缩盒子模型显示;
						  text-overflow:ellipsis;//溢出部分用省略号代替
							-webkit-line-clamp:1; //设置文本显示两行
							-webkit-box-orient:vertical;  //从上到下排列子元素;
						}
						.count{
							// flex:1;
						}
						.price {
							color: red;
							font-size: 32rpx;
							font-weight: 600;
						}
					}
				}
			}
		}
		.products-footer{
			position: fixed;
			bottom: 0;
			width: 100%;
			height: 100rpx;
			padding: 0 30rpx;
			display: flex;
			align-items: center;
			background-color: #FFFFFF;
			justify-content: space-between;
			view{
				display: flex;
				.button-tow{
					margin-left: 30rpx;
				}
			}
			.checkbox-all{
				color: $zhbgColor;
			}
		}
	}
	.products-in-2 {
		.products-card-2 {
			padding: 16rpx 30rpx;
			border-top: 1rpx solid #EEEEEE;
			border-bottom: 1rpx solid #EEEEEE;
			display: flex;
			justify-content: space-between;
			.u-checkbox-2 {
				flex: 3;
				.text{
					display: inline-block;
					width: 180rpx;
					vertical-align: middle;
					white-space: nowrap;
					overflow: hidden;
					text-overflow: ellipsis;
				}
				
			}
			.content{
				flex: 6;
				.products-info-2 {
					// height: 100rpx;
					flex: 6;
					display: flex;
					flex-direction: column;
					.divide{
						border-width: 0;
						border-bottom: 1rpx solid #EEEEEE;
						display: inline-block;
					}
					// justify-content: space-between;
					.products-price-2 {
						color: #666666;
						display: flex;
						align-items: center;
						justify-content: space-between;
						.price-2 {
							color: red;
							font-size: 32rpx;
							font-weight: 600;
						}
					}
				}
			}
			
		}
	}
	
	/deep/.u-checkbox__label{
		color: #000000;
	}
	/deep/.uni-navbar--border{
		border: none;
	}
</style>
