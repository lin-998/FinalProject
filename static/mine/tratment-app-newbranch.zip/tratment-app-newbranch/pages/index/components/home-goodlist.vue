<template>
	<view class="home-img">
		<view class="img-list" v-for="(Img,index) in imgList" :key="index" @click="changeClick(index)">
			<image :src="Img.attachmentUrl" mode="widthFix"></image>
		</view>
	</view>
</template>

<script>
	export default {
		props:['imgList'],
		data(){
			return {
			}
		},
		methods:{
			changeClick(index){
				console.log(index);
			}
		}
	}
</script>

<style lang="scss">
	.img-list{
		// padding: 20rpx;
		// padding-top: 20rpx;
		image{
			margin: 0 auto;
			width: 100%;
			display: block;
		}
	}
</style>
