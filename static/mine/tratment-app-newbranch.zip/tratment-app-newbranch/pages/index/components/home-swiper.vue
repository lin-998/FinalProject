<template>
	<view class="com-swiper">
		<swiper class="swiper" indicator-dots autoplay  circular>
			<swiper-item v-for="(swiperItem,index) in swiperList" :key="index" @click="toswiper(index)">
				<image :src="swiperItem.attachmentUrl" style="border-radius: 15rpx;"></image>
			</swiper-item>
		</swiper>
	</view>
</template>

<script>
	export default {
		props:['swiperList'],
		data(){
			return {
			}
		},
		methods:{
			toswiper(index){
				let user=uni.getStorageSync("userInfo").roles[0].roleName
				if(user=="游客"){
					uni.navigateTo({
						url:'/pages/index/visitshop/visitshop'
					})
				}else{
					uni.redirectTo({
						url:"../../goods/goods"
					})
				}
				
			}
		}
	}
</script>

<style lang="scss">
	.com-swiper {
		// background-color: skyblue;
		// margin-top: 30rpx;
		image{
			width: 100%;
			height: 100%;
		}
	}
</style>
