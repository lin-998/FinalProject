<template>
	<view>
		<uni-grid @change="changeClick" :column="4" :show-border="false" :square="false">
			<uni-grid-item :index="index" class="uni-grid" v-for="(item,index) in navList" :key="index">
					<image :src="item.img_url" v-bind:style="{width:width,height:height}"></image>
					<text>{{item.value}}</text>
			</uni-grid-item>
		</uni-grid>
	</view>
</template>

<script>
	export default {
		props: ['navList','width','height'],
		data() {
			return {}
		},
		created() {
			console.log(this.height)
		},
		methods: {
			changeClick(e) {
				let Val = this.navList[e.detail.index].value
				if(Val==="行业动态" || Val==="关于我们" || Val==="资料下载"){
					let id=2;
					if(Val==="资料下载"){id=0}else
					if(Val==="关于我们"){id=1}
					console.log(id);
					uni.setStorageSync("material",id)
					uni.switchTab({
						url:"/pages/material/material"
					});
				}else if(Val=="我要下单"){
					let user=uni.getStorageSync("userInfo")?uni.getStorageSync("userInfo").roles[0].roleName:"游客"
					console.log(user,"sda")
					if(user=="游客"||user=="会员商家"){
						this.toast("没有权限访问,请联系管理员∩_∩")
						return
					}
					uni.navigateTo({
						url:"/pages/index/demand/demand"
					})
				}else if(Val==="已选"){
					let user=uni.getStorageSync("userInfo")?uni.getStorageSync("userInfo").roles[0].roleName:"游客"
					if(user=="游客"||user=="会员商家"){
						this.toast("没有权限访问,请联系管理员∩_∩")
						return
					}
					uni.navigateTo({
						url:"/pages/index/Products/Products"
					})
					
				}else if(Val==="我的订单"){
					let user=uni.getStorageSync("userInfo")?uni.getStorageSync("userInfo").roles[0].roleName:"游客"
					if(user=="游客"||user=="会员商家"){
						this.toast("没有权限访问,请联系管理员∩_∩")
						return
					}
					uni.navigateTo({
						url:"/pages/user/myorder/myorder?current=0"
					})
				}else if(Val==="会员入驻"){
					let user=uni.getStorageSync("userInfo")?uni.getStorageSync("userInfo").roles[0].roleName:"游客"
					if(user=="游客"){
						this.toast("没有权限访问,请联系管理员∩_∩")
						return
					}
					uni.navigateTo({
						url:"/pages/business/business"
					})
				}else if(Val==="扫一扫"){
					uni.scanCode({
						success: (res) => {
							if(res.scanType==='QR_CODE'){
								uni.navigateTo({
								url:"/pages/user/myorder/qrorder/qrorder?id="+res.result
							})
							}else{
								this.toast('扫码失败')
							}
							console.log(123456);
							console.log(res);
						}
					})
				}
			}
		}
	}
</script>

<style lang="less">
	.uni-grid {
		width: 25%;
		text-align: center;
		image {
			margin: 0 auto;
			// background-color: blue;
		}
		text{
			font-size: 28rpx;
			margin-top: 10rpx;
		}
	}
</style>
