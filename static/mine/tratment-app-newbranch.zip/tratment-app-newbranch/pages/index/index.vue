<template>
	<view class="container">
		<!-- <uni-header></uni-header> -->
		<!-- 首页头部 -->
		<!-- 			<uni-nav-bar fixed class="home-navbar">
			<u-search placeholder="日照香炉生紫烟" shape='square' style="width: 550rpx;" v-model="keyword" :show-action="false"
			 bg-color="#fff"></u-search>
			<view slot="left" class="address">
				<view class="weather">
					<text>昆明</text>
					<u-icon style="margin-left:10rpx;" name="arrow-down" color="#fff" size="28"></u-icon>
				</view>
				<view class="weather forecast">
					<text>晴</text>
					<text>32C</text>
				</view>
			</view>
		</uni-nav-bar> -->
		<home-nav
			class="home-nav1"
			:navList="navlist1"
			width="50rpx"
			height="50rpx"
		></home-nav>
		<view class="home-center">
			<!-- 导航栏 -->
			<home-nav class="home-nav2" :navList='navlist2' width="100rpx" height="100rpx"></home-nav>
			<view class="home-count">
				<!-- 轮播图 -->
				<view class="title">欢迎下单</view>
				<view @click="productOrder">
					<home-swiper :swiperList="internalUsers"></home-swiper>
				</view>
				<!-- 商品展览 -->
				<view class="title">好货分享</view>
				<view @click="productDisplay">
					<home-swiper :swiperList="businessUsers"></home-swiper>
				</view>
				<view class="title">行业动态</view>
				<view @click="aboutUs" style="margin-bottom: 120rpx;">
					<home-swiper :swiperList="swiperlist"></home-swiper>
				</view>
		</view>
	</view>
		<u-picker @cancel="cancel()" mode="region" :area-code="defaultAddress" confirm-color="#176CDC" @confirm="confirmAddress" v-model="addressShow"
		 :params="params"></u-picker>
	</view>
</template>

<script>
// import {promise} from '../../util/httpApi.js'
	import {
		getRegister,
		Register,
		PublicK,
		getShuffling,
		gateGorylist,
		weatherInfo,
		getOurShuffling,
		imageUpload
	} from "@/util/request.js"
import {address} from "@/static/area.js"
	export default {
		data() {
			return {
				internalUsers:[],
				businessUsers:[{
					attachmentUrl: "https://tech.a6shop.net:8058/smartMedicalFile/file/goodsAttachment/2020-09-23/3a1f6d988cba47e293772e79acb57436.jpg",
					id: "68"
				}],
				cityWeather:'',
				addressShow: false,
				defaultAddress: [],
				params: {
					province: true,
					city: true,
					area: false
				},
				show: true,
				keyword: '',
				navlist1: [{
						img_url: '/static/image/ico_sys.png',
						value: '扫一扫'
					},
					{
						img_url: '/static/image/ico_hydt.png',
						value: '行业动态'
					},
					{
						img_url: '/static/image/ico_zlxz.png',
						value: '资料下载'
					},
					{
						img_url: '/static/image/ico_gywm.png',
						value: '关于我们'
					},
				],
				navlist2: [{
						img_url: '/static/image/ico_wyxd.png',
						value: '我要下单'
					},
					{
						img_url: '/static/image/ico_yx.png',
						value: '已选'
					},
					{
						img_url: '/static/image/ico_wddd.png',
						value: '我的订单'
					},
					{
						img_url: '/static/image/ico_gd.png',
						value: '会员入驻'
					},
				],
				swiperlist: []
			}
		},
		methods: {
			cancel(){
				uni.showTabBar()
			},
			toMenu(){
				let user=uni.getStorageSync("userInfo")?uni.getStorageSync("userInfo").roles[0].roleName:"游客"
				if(user=="游客"||user=="会员商家"){
					uni.navigateTo({
						url:'/pages/index/visitshop/visitshop'
					})
				}
			},
			// 获取当前地址的温度和天气
			confirmAddress(res) {
				uni.showTabBar({})
				weatherInfo({
					city: res.city.value + '00',
					key: "1bb7c7c22e4d5e95bed2796561a24a33"
				}).then(res1 => {
					// this.cityWeather=' ' + res1.lives[0].temperature + '℃ ' + res1.lives[0].weather + ' ' + res.city.label
					this.cityWeather=' ' + res1.lives[0].temperature + '℃ ' + res1.lives[0].weather
					// #ifdef APP-PLUS
					let webView = this.$mp.page.$getAppWebview();
					webView.setTitleNViewButtonStyle(0, {
						text: this.cityWeather
					});
					// #endif
				})
			},
			productOrder() {
				let user=uni.getStorageSync("userInfo")?uni.getStorageSync("userInfo").roles[0].roleName:"游客"
				console.log(user)
				if(user=="游客"||user=="会员商家"){
					uni.navigateTo({
						url:'/pages/index/visitshop/visitshop'
					})
				}else{
					uni.navigateTo({
						url:'/pages/goods/goods'
					})
				}
				
			},
			init(){
				this.getaddtes()
				// 获取轮播图
				getOurShuffling().then(res=>{
					if(res.code===200){
						this.swiperlist=res.data
					}
				})
				getShuffling({
					status: 0
				}).then(res => {
					if (res.code === 200) {
						if(!res.data)return;
						this.internalUsers = res.data
						// console.log(res.data);
						// this.$forceUpdate()
					}
				})
				getShuffling({
					status: 1
				}).then(res => {
					if (res.code === 200) {
						if(!res.data)return;
						this.businessUsers = res.data
						// console.log(res.data);
						// this.$forceUpdate()
					}
				})
			},
			productDisplay () {
				let user=uni.getStorageSync("userInfo")?uni.getStorageSync("userInfo").roles[0].roleName:"游客"
				if(user=="游客"||user=="会员商家"){
					uni.navigateTo({
						url:'/pages/index/visitshop/visitshop?active=1'
					})
				}else{
					uni.navigateTo({
						url:'/pages/goods/goods?active=1'
					})
				}
		},
		aboutUs () {
			uni.switchTab({
				url: "/pages/material/material"
			})
			console.log()
		},
			//获取当前位置及天气信息
			getaddtes(){
				uni.showTabBar({})
				let _this=this
				uni.getLocation({
					geocode:true,
					success(res) {
						for(let key in address.city_list){
							if(address.city_list[key]===res.address.city){
								weatherInfo({
									city: key,
									key: "1bb7c7c22e4d5e95bed2796561a24a33"
								}).then(res1 => {
									// _this.cityWeather=' ' + res1.lives[0].temperature + '℃ ' + res1.lives[0].weather + ' ' + res1.lives[0].city
									_this.cityWeather=' ' + res1.lives[0].temperature + '℃ ' + res1.lives[0].weather
									// #ifdef APP-PLUS
									let webView = _this.$mp.page.$getAppWebview();
										webView.setTitleNViewButtonStyle(0, {
											text: _this.cityWeather
										});
									// #endif
								})
						}
						}
						
					}
				})
				
			},
		},
		//点击城市
		onNavigationBarButtonTap() {
			this.addressShow = true
			uni.hideTabBar()
			// uni.navigateTo({
			// 	url: "/pages/index/choosecity/choosecity"
			// })
		},
		//点击搜索框
		onNavigationBarSearchInputClicked() {
			let user=uni.getStorageSync("userInfo")?uni.getStorageSync("userInfo").roles[0].roleName:"游客"
			if(user=="游客"){
				this.toast("没有权限访问,请联系管理员∩_∩")
				return
			}
			uni.navigateTo({
				url: "/pages/goods/vague-search/vague-search"
			})
		},
		//监听页面滚动
		// onPageScroll(res) {
		// 	if (res.scrollTop > 150) {
		// 		// #ifdef APP-PLUS
		// 		let webView = this.$mp.page.$getAppWebview();
		// 		webView.setTitleNViewButtonStyle(0, {
		// 			color: "#000000",
		// 		});
		// 		webView.setStyle({
		// 		titleNView: {
		// 			searchInput: {
		// 				backgroundColor: "#eeeeee",
		// 				},
		// 			}
		// 		});
		// 		// #endif
		// 	} else {
		// 		// #ifdef APP-PLUS
		// 		let webView = this.$mp.page.$getAppWebview();
		// 		webView.setTitleNViewButtonStyle(0, {
		// 			color: "#FFFFFF",
		// 		});
		// 		webView.setStyle({
		// 		titleNView: {
		// 			searchInput: {
		// 				backgroundColor: "#FFFFFF",
		// 				},
		// 			}
		// 		});
		// 		// #endif
		// 	}
		// },
		onShow() {
			this.init()
		},
}
</script>

<style lang="less" scoped>
	.home-count{
		padding: 20rpx 0;
	}
	.title {
		padding: 20rpx;
		font-size: 32rpx;
		// margin-top: 20rpx;
		// background: #eeeeee;
		width: 100%;
	}

.address {
	width: 150rpx;
	padding-left: 20rpx;
	color: #fff;
	display: flex;
	flex-direction: column;

	.weather {
		line-height: 40rpx;
		font-size: 32rpx;
	}

	.forecast {
		font-size: 20rpx;
	}
}

/deep/.uni-navbar__header {
	background: #176cdc !important;
}

/deep/.uni-navbar--border {
	border: none;
	width: 100%;
}

page {
	font-size: 28rpx;

	.container {
		background: #176cdc;
		height: 320rpx;
	}

	.home-center {
		position: relative;
		top: 60rpx;
		width: 94vw;
		left: 3vw;
		border-radius: 10rpx 10rpx 0 0;
		background: #ffffff;
	}
}

.home-nav2 {
	padding-top: 30rpx;
}

.home-nav1 {
	color: #fff;
	padding-top: 60rpx;
	// background-color: red;
	
}
</style>
