<template>
	<view v-if="isPassword" class="password">
		<view class="login-name">
			忘记密码
		</view>
		<form @submit="Login" class="from-ipt">
			<view class="login-inp">
				<image src="../../static/image/phone.png" mode="widthFix" style="width: 50rpx;"></image>
				<u-input class="input" placeholder-style="color:#aaa;" type="number" placeholder="请输入手机号码" v-model="form.phone" />
			</view>
			<view class="login-inp">
				<image src="../../static/image/password.png" mode="widthFix" style="width: 50rpx;"></image>
				<u-input class="input" placeholder-style="color:#aaa;" type="number" placeholder="请输入验证码" v-model="form.passwordCode" />
				<view class="btnCode">
					<u-button type="primary" @click="getregiterCode" :disabled="disabled" size="mini">{{codeText}}</u-button>
				</view>
			</view>
			<u-button class="submit" form-type="submit" type="primary" shape="circle">下一步</u-button>
			<view>
				<u-toast ref="uToast" />
			</view>
		</form>
	</view>
	<view v-else class="password">
		<view class="login-name">
			设置密码
		</view>
		<form @submit="forPassword" class="from-ipt">
			
			<view class="login-inp">
				<image src="../../static/image/password.png" mode="widthFix" style="width: 50rpx;"></image>
				<u-input class="input" placeholder-style="color:#aaa;" type="password" placeholder="请输入新密码" v-model="form.Password" />
			</view>
			<view class="login-inp">
				<image src="../../static/image/password.png" mode="widthFix" style="width: 50rpx;"></image>
				<u-input class="input" placeholder-style="color:#aaa;" type="password" placeholder="请再次输入新密码" v-model="form.newPassword" />
			</view>
			<u-button class="submit" form-type="submit" type="primary" shape="circle">完成</u-button>
			<view>
				<u-toast ref="uToast" />
			</view>
			
		</form>
	</view>
</template>

<script>
	import { JSEncrypt } from "@/common/jsencrypt.min.js";
	import {getPassword,forgetPassword,PublicK} from "@/util/request.js"
	export default {
		data() {
			return {
				disabled:false,
				isPassword: true,
				codeText: '获取验证码',
				iScode: false,
				form: {},
				publicKey:''
			}
		},
		methods: {
			// 获取注册验证码
			getregiterCode(){
				let re=/^1\d{10}$/
				if(!re.test(this.form.phone)){
					this.$refs.uToast.show({title: "手机格式不正确！！"})
					return
				}
				if (this.form.phone.trim() != '') {
						getPassword({phone: this.form.phone}).then(res => {
							if (res.code === 200) {
								this.$refs.uToast.show({title: "验证码已发送"})
								this.disabled = true
								let itme = 59
								let itmeval=setInterval(()=>{
									itme--
									if(itme===0){
										this.codeText="重新获取 "
										this.disabled = false
										clearInterval(itmeval)
									}else{
										this.codeText=itme+"重新获取 "
									}
								},1000)
							} else {
								this.$refs.uToast.show({title: res.msg})
							}
							
						});
				} else {
					this.$refs.uToast.show({
						title: '请输入手机号码',
						type: 'error'
					})
				}
			},
			// 获取公钥
			getPublicK() {
				let re=/^1\d{10}$/
				if(!re.test(this.form.phone)){
					this.$refs.uToast.show({title: "手机格式不正确！！"})
					return
				}
				PublicK({username: this.form.phone}).then(res => {
					if (res.code === 200) {
						// this.publicKey = res.data;
						delete this.form.Password
						
						var crypt = new JSEncrypt({
						  default_key_size: 1024,
						});
						crypt.setPublicKey(res.data);
						this.form.passwordCode = crypt.encrypt(this.form.passwordCode);
						forgetPassword(this.form).then(res => {
							if(res.code==200){
								this.toast("修改密码成功")
								uni.redirectTo({
									url:"login"
								})
							}else{
								this.toast(res.msg)
								this.isPassword=true
								this.form.newPassword=""
								this.form.Password=""
							}
						})
					} else {
						this.$refs.uToast.show({
							title: res.msg
						})
					}
				});
			},
			Login() {
				let re=/^1\d{10}$/
				if(!re.test(this.form.phone)){
					this.$refs.uToast.show({title: "手机格式不正确！！"})
					return
				}
				if(this.form.passwordCode==undefined||this.form.passwordCode==''){
					this.$refs.uToast.show({title: "请填写验证码！！"})
					return
				}
				this.isPassword = false
			},
			//找回密码
			forPassword() {
				if(this.form.Password==undefined||this.form.Password==''){
					this.$refs.uToast.show({
						title: '请输入密码',
						type: 'error'
					})
					return
				}
				if (this.form.Password !== this.form.newPassword) {
					this.$refs.uToast.show({
						title: '两次密码输入不一样，请重新输入',
						type: 'error'
					})
				} else {
					this.getPublicK()
				}
			}
		}
	}
</script>

<style lang="scss">
	.password {
		padding: 0 74rpx;
	}

	.login-name {
		font-size: 44rpx;
		font-weight: 600;
		margin: 158rpx 0 60rpx;
		color: #555555;
	}

	.from-ipt {
		.login-inp {
			display: flex;
			align-items: center;
			margin-bottom: 60rpx;
			.input{
				margin-left: 10rpx;
				border-bottom: 1rpx solid #DDDDDD;
				padding-bottom: 12rpx;
				flex: 1;
				font-size: 28rpx;
				padding-left: 20rpx;
			}
		}

		.submit {
			margin-top: 82rpx;
		}

		.hover-class {
			background: #EAEAEA;
		}
	}
	.btnCode{
		border-bottom: 1rpx solid #DDDDDD;
		padding: 0 0 18rpx 10rpx;
		box-sizing: border-box;
	}
	.register {
		padding: 0 74rpx;
	}
	
	.login-name {
		font-size: 44rpx;
		font-weight: 600;
		margin: 158rpx 0 60rpx;
		color: #555555;
	}
</style>
