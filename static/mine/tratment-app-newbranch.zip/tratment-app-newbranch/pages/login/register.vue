<template>
	<view class="register">
		<view class="login-name">
			注册
		</view>
		<form @submit="getPublicK" class="from-ipt">
			<view class="login-inp">
				<image src="../../static/image/phone.png" mode="widthFix" style="width: 50rpx;"></image>
				<u-input class="input" placeholder-style="color:#aaa;" type="number" placeholder="请输入手机号码" v-model="form.username" />
			</view>
			<view class="login-inp">
				<image src="../../static/image/password.png" mode="widthFix" style="width: 50rpx;"></image>
				<u-input class="input" placeholder-style="color:#aaa;" type="password" placeholder="请设置登录密码" v-model="form.password" />
			</view>
			<view class="login-inp">
				<image src="../../static/image/password.png" mode="widthFix" style="width: 50rpx;"></image>
				<u-input class="input" placeholder-style="color:#aaa;" type="number" placeholder="请输入验证码" v-model="form.phoneCode" />
				<view class="btnCode">
					<u-button type="primary" @click="getregiterCode" :disabled="disabled" size="mini">{{codeText}}</u-button>
				</view>
			</view>
			<u-button style="color: #176CDC;" shape="circle" form-type="submit">注册</u-button>
			<view>
				<u-toast ref="uToast" />
			</view>
		</form>
	</view>
</template>

<script>
	
	import { JSEncrypt } from "@/common/jsencrypt.min.js";
	import {getRegister,Register,PublicK} from "@/util/request.js"
	export default {
		data() {
			return {
				codeText:"获取验证码",
				disabled:false,
				form: {},
				rules: {
					// 字段名称
					phone: [{
						required: true,
						message: '请输入手机号',
						trigger: 'change',
					}],
					password: [{
						min: 5,
						message: '请输入密码',
						trigger: 'change',
					}],
				}
			}
		},
		methods: {
			// 获取公钥
			getPublicK() {
				let re=/^1\d{10}$/
				if(!re.test(this.form.username)){
					this.$refs.uToast.show({title: "手机格式不正确！！"})
					return
				}
				if(this.form.password==undefined||this.form.password==''){
					this.$refs.uToast.show({title: "请输入密码！！"})
					return
				}
				if(this.form.phoneCode==undefined||this.form.phoneCode==''){
					this.$refs.uToast.show({title: "请填写验证码！！"})
					return
				}
				
				console.log(132);
				PublicK({username: this.form.username}).then(res => {
					console.log(1465);
					if (res.code === 200) {
						this.publicKey = res.data;
						this.logo();
					} else {
						this.$refs.uToast.show({title: res.msg})
					}
				});
			},
			// 获取加密后的密码
			logo() {
				var crypt = new JSEncrypt({
				  default_key_size: 1024,
				});
				crypt.setPublicKey(this.publicKey);
				this.form.phoneCode = crypt.encrypt(this.form.phoneCode);
				// 调用登陆接口
				Register({phoneCode:this.form.phoneCode,userInfo:{phone:this.form.username,password:this.form.password}}).then(res=>{
					if(res.code===200){
						uni.redirectTo({
							url:"login"
						})
					}else{
						this.$refs.uToast.show({title: res.msg})
					}
				})
			},
			// 获取注册验证码
			getregiterCode(){
				if (this.form.username) {
						let re=/^1\d{10}$/
						if(!re.test(this.form.username)){
							this.$refs.uToast.show({title: "手机格式不正确！！"})
							return
						}
						getRegister({phone: this.form.username,password:this.form.password}).then(res => {
							console.log(res);
							this.disabled = true
							if (res.code === 200) {
								this.$refs.uToast.show({title: "验证码已发送"})
								let itme = 59
								let itmeval=setInterval(()=>{
									itme--
									if(itme===0){
										this.codeText="重新获取 "
										this.disabled = false
										clearInterval(itmeval)
									}else{
										this.codeText=itme+"重新获取 "
									}
								},1000)
							} else {
								this.disabled = false
								this.$refs.uToast.show({title: res.msg})
							}
						});
				} else {
					this.$refs.uToast.show({
						title: '请输入手机号码',
						type: 'error'
					})
				}
			},
		}
	}
</script>

<style lang="scss">
	.btnCode{
		border-bottom: 1rpx solid #DDDDDD;
		padding: 0 0 18rpx 10rpx;
		box-sizing: border-box;
	}
	.register {
		padding: 0 74rpx;
	}

	.login-name {
		font-size: 44rpx;
		font-weight: 600;
		margin: 158rpx 0 60rpx;
		color: #555555;
	}

	.from-ipt {
		.login-inp {
			display: flex;
			align-items: center;
			margin-bottom: 60rpx;
			.input{
				margin-left: 10rpx;
				border-bottom: 1rpx solid #DDDDDD;
				padding-bottom: 12rpx;
				flex: 1;
				font-size: 28rpx;
				padding-left: 20rpx;
			}
		}
	}
</style>
