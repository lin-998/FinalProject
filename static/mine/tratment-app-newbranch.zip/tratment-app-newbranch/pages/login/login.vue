<template>
	<view class="login">
		<view class="login-img">
			<image src="../../static/image/login.png" mode="widthFix"></image>
		</view>
		<view class="login-info">
			<view class="login-name">
				用户登录
			</view>
			<form @submit="getPublicK" class="from-ipt">
				<view class="login-inp">
					<u-icon name="lock" color="#AAAAAA" size="50"></u-icon>
					<input placeholder-style="color:#aaa;" type="text" placeholder="请输入手机号" v-model="form.username" />
				</view>
				<view class="login-inp">
					<u-icon name="lock" color="#AAAAAA" size="50"></u-icon>
					<input placeholder-style="color:#aaa;" type="password" placeholder="请输入密码" v-model="form.password" />
				</view>
				<u-checkbox-group>
					<u-checkbox v-model="checked">记住账号密码</u-checkbox>
				</u-checkbox-group>
				<u-button form-type="submit" type="primary" shape="circle">登录</u-button>
				<u-button style="color: #176CDC;" shape="circle" @click="register">注册</u-button>
				<!-- <u-button style="color: #176CDC;" shape="circle" @click="visit">游客浏览</u-button> -->
			</form>
			<view class="modify" style="margin-bottom: 100rpx;">
				<navigator url="./password">
					<text>忘记密码?</text>
				</navigator>
				<u-toast ref="uToast" />
			</view>
		</view>
	</view>
</template>

<script>
	import { JSEncrypt } from "@/common/jsencrypt.min.js";
	import {Login,PublicK} from "@/util/request.js"
	export default {
		data() {
			return {
				publicKey: '',
				form: {},
				allowClick:true,
				type:0,
				checked:true
			}
		},
		methods: {
			register() {
				uni.navigateTo({
					url: "/pages/login/register"
				})
			},
			visit(){
				uni.switchTab({
					url:"../index/index"
				})
			},
			getPublicK() {
				if(!this.allowClick){
					return
				}
				this.allowClick = false;
				setTimeout(()=>{
						this.allowClick = true;
				}, 3000)
				if(this.form.username==undefined||this.form.username==''){
					this.toast("请输入用户名")
					return
				}
				if(this.form.password==undefined||this.form.password==''){
					this.toast("请输入密码")
					return
				}
				PublicK({username: this.form.username}).then(res => {
					if (res.code === 200) {
						this.publicKey = res.data;
						this.logo();
					} else {
						this.$refs.uToast.show({title: res.msg})
					}
				});
			},
			// 获取加密后的密码
			logo() {
				
				var crypt = new JSEncrypt({
				  default_key_size: 1024,
				});
				crypt.setPublicKey(this.publicKey);
				const form=JSON.parse(JSON.stringify(this.form))
				form.password = crypt.encrypt(this.form.password);
				// 调用登陆接口
				Login(form).then(res => {
					console.log(123);
					if (res.code === 200) {
						uni.setStorageSync("token",res.data.token);
						if(this.checked){
							uni.setStorageSync("loginInfo",this.form);
						}else{
							uni.removeStorageSync("loginInfo")
						}
						uni.setStorageSync("userInfo",res.data);
						if(res.data.roles[0].roleName==="管理员（绝对不能删这个）"||res.data.roles[0].roleName==="分销商下单人员"){
							uni.redirectTo({
								url:"../index/demand/demand"
							})
						}else if(res.data.roles[0].roleName==="骑手管理员"){
							uni.redirectTo({
								url:"../rider/manage/manage"
							})
						}else if(res.data.roles[0].roleName==="骑手"){
							uni.redirectTo({
								url:"../rider/rider"
							})
						}else if(res.data.roles[0].roleName==="分销商复核人员"){
							uni.redirectTo({
								url:"../user/review/review?current=0"
							})
						}else if(res.data.roles[0].roleName==="游客"||res.data.roles[0].roleName==="会员商家"){
							uni.switchTab({
								url:"../index/index"
							})
						}
					} else {
						this.toast(res.msg)
					}
				});
			},
		},
		onLoad(option) {
			console.log(option.type,"onload")
			if(option.type){
				this.type=option.type
			}
		},
		onShow() {
			// 设置状态栏样式，使其更加美观  
			// console.log(uni.getStorageSync('userInfo'));
			// 已经登录的
			console.log(this.type,"onshow")
			if(uni.getStorageSync('userInfo')){
				const userInfo=uni.getStorageSync('userInfo')
				if(userInfo.roles[0].roleName==="管理员（绝对不能删这个）"||userInfo.roles[0].roleName==="分销商下单人员"){
						uni.switchTab({
							url:"../index/index"
						})
				}else if(userInfo.roles[0].roleName==="骑手管理员"){
						uni.redirectTo({
							url:"../rider/manage/manage"
						})
				}else if(userInfo.roles[0].roleName==="骑手"){
						uni.redirectTo({
							url:"../rider/rider"
						})
				}else if(userInfo.roles[0].roleName==="分销商复核人员"){
						uni.redirectTo({
							url:"../user/review/review?current=0"
						})
				}else if(userInfo.roles[0].roleName==="会员商家"){
						uni.redirectTo({
							url:"../index/demand/demand"
						})
				}else if(userInfo.roles[0].roleName==="游客"){
						uni.switchTab({
							url:"../index/index"
						})
				}
			}
			// 登录退出后有保存用户名密码的
			if(uni.getStorageSync('loginInfo')){
				let loginInfo = uni.getStorageSync('loginInfo');
				this.form.username=loginInfo.username?loginInfo.username:""
				this.form.password=loginInfo.password?loginInfo.password:""
			}
			if(!uni.getStorageSync('loginInfo')&&!uni.getStorageSync('userInfo')&&this.type!=1){
				console.log("首次进入")
				uni.switchTab({
					url:"../index/index"
				})
			}
			// let loginInfo = uni.getStorageSync('loginInfo');
			// console.log(uni.getStorageSync('loginInfo'));
			// this.form.username=loginInfo.username?loginInfo.username:""
			// this.form.username=loginInfo.username?loginInfo.username:""
		}
	}
</script>

<style lang="scss">
	.login {
		// padding: 100rpx 74rpx 0;
		.login-img {
			// width: 200rpx;
			// height: 200rpx;
			margin: 0 auto 100rpx;
			image {
				width: 100%;
			}
		}
		.login-info{
			padding: 0 74rpx 0;
		}
		.login-name {
			font-size: 44rpx;
			font-weight: 600;
			margin-bottom: 60rpx;
			color: #555555;
		}

		.from-ipt {
			.login-inp {
				display: flex;
				align-items: center;
				margin-bottom: 60rpx;
			}

			input {
				margin-left: 10rpx;
				border-bottom: 1rpx solid #BBBBBB;
				padding-bottom: 12rpx;
				flex: 1;
				font-size: 28rpx;
				// height: 60rpx;
				// line-height: 60rpx;
				padding-left: 20rpx;
			}

			button {
				width: 600rpx;
				height: 88rpx;
				margin: 40rpx auto;

			}

			.hover-class {
				background: #EAEAEA;
			}
		}

		.modify {
			text-align: center;
			font-size: 26rpx;
			margin-top: 50rpx;
			color: #333;
		}
	}
</style>
