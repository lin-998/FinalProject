<template>
	<!-- 待分配骑手 -->
	<view class="fenpei">
		<!-- <view class="nav">
			<text @click="changepage('1')" v-bind:class="[tab=='1' ? active : unactive,navleft]">待分配订单</text>
			<text @click="changepage('2')" v-bind:class="[tab=='2' ? active : unactive,navright]">已分配订单</text>
		</view> -->
		<u-tabs class="tab" bg-color="#eee" :list="list" :bold="false" :current="current" @change="change2"></u-tabs>
		<view class="content">
			<!-- 待分配订单模块 -->
			<view v-if="current==0">
				<manage-select v-on:rider="fenpei" ref="allocated"></manage-select>
			</view>
			<!-- 已分配订单模块 -->
			<view v-if="current==1">
				<manage-order ref="allocated"></manage-order>
			</view>
			<!-- <view v-if="current==2">
				<manage-unallocated v-on:rider="fenpei" ref="allocated"></manage-unallocated>
			</view> -->
			<!-- 已分配订单模块 -->
			<!-- <view v-if="current==3">
				<manage-allocated ref="allocated"></manage-allocated>
			</view> -->
		</view>
		<!-- 遮罩 -->
		<view class="mask" v-show="control==true" @click="control=false"></view>
		<!-- 点击弹出分配骑手 -->
		<manage-pop  class="pop" :current="current" :order-id="orderId" v-on:childconfirm="confirms" ref="confirm" v-show="control==true"></manage-pop>
	</view>
</template>

<script>
	import {getrider} from '@/util/request.js'
	export default{
		data:function(){
			return{
				navleft:"nav1",
				navright:"nav2",
				active:"active",
				unactive:"",
				items:[],
				control:false,
				orderId:'',
				current:0,
				list: [
					{name: '待分配骑手'}, 
					{name: '已分配'}
					// {name: '待分配骑手(退货)'}, 
					// {name: '已分配(退货)'}
				]
			}
		},
		onLoad() {
			
		},
		onPullDownRefresh(){
			this.$refs.allocated.refresh()
		},
		onNavigationBarButtonTap(){
			let loginInfo=uni.getStorageSync("loginInfo")
			uni.clearStorageSync()
			uni.setStorageSync("loginInfo",loginInfo);
			uni.redirectTo({
				url: "/pages/login/login?type=1"
			})
		},
		onReachBottom() {
			this.$refs.allocated.toBottom()
		},
		methods:{
			change2(index){
				this.current = index;
			},
			// 点击确认后关闭弹出界面
			confirms:function(id){
				console.log(id);
				this.control=!this.control
				this.$refs.allocated.refresh()
				this.changeRefush()
			},
			// 点击分配骑手时弹出界面
			fenpei:function(id){
				console.log(id)
				this.orderId=id
				this.control=!this.control
				this.$refs.confirm.refresh()
				this.changeRefush()
			},
			changeRefush(){
				//#ifdef APP-PLUS
					const pages = getCurrentPages();  
					const page = pages[pages.length - 1];  
					const currentWebview = page.$getAppWebview();
					currentWebview.setStyle({  
						pullToRefresh: {  
							support: !this.control,  
							style: plus.os.name === 'Android' ? 'circle' : 'default'  
						}  
					});  
					this.isSupport = !this.isSupport;
				//#endif
			}
		}
	}
</script>

<style scoped lang="scss">
	.fenpei{
		// background: #F6F6F6;
	}
	.nav{
		width: 100%;
		height: 88rpx;
		line-height: 88rpx;
		background-color: white;
		margin-bottom: 30rpx;
		text{
			font-size: 30rpx;
		}
		.nav1{
			text-align:left;
			margin-left:48rpx;
		}
		.nav2{
			font-weight: 400;
			margin-left: 64rpx;
			
		}
	
	}
	// 遮罩层
	.mask{
		// display: none;
		width: 750rpx;
		height: 1334rpx;
		z-index: 10;
		position: fixed;
		top: 0;
		background: rgba(0, 0, 0, 0.6);
		opacity: 1;
	}
	.pop{
		// display: none;
		z-index: 11;
	}
	.active{
		color: #176CDC;
		font-weight: bold;
	}
</style>
