<template>
	<!-- 弹出界面 -->
	<view class="pop">
		<!-- 弹出界面上部分 -->
		<view class="pop-top">
			<view v-for="(item,index) in items" class="select" :key="item.id">
				<text class="pop-name">{{item.userName}}</text>
				<view class="pop-num">
					<text>（当前任务</text>
					<text>{{item.taskCount}}</text>
					<text>个）</text>
				</view>
				<view class="pop-radio">
					<view class="out" v-show="item.select">
						<view class="inner"></view>
					</view>
					<view class="def" v-show="!item.select" @click="select(item,index)">
						
					</view>
					
				</view>			
			</view>
		</view>
		<!-- 弹出界面下部分 -->
		<view class="pop-bottom">
			<view class="but" @click="confirm()" v-if="this.items!=0">
				确定
			</view>
		</view>
	</view>
</template>

<script>
	import {getrider,distributionrider,distributionReturnRider} from "@/util/request.js"
	export default{
		data:function(){
			return{
				items:[],
				id:"",
				request:false,
				notAllowed:true
			}
		},
		props:[
			"orderId",
			"current"
		],
		created() {
			
		},
		methods:{
			init(){
				getrider().then(res=>{
					if(res.code===200){
						let arr=res.data;
						arr.forEach((val,index)=>{
							if(index==0){
								val.select=true
							}else{
								val.select=false
							}
						})
						this.items=arr
						this.id=this.items[0].id
					}
				})
			},
			refresh(){
				this.init()
			},
			select:function(item,i){
				for(let k=0;k<this.items.length;k++){
					this.items[k].select=false
				}
				this.items[i].select=true;
				this.id=item.id
			},
			confirm:function(name){
				if(!this.notAllowed){
					// this.toast("请勿重复点击")
					return
				}
				this.notAllowed=false
				setTimeout(()=>{
						this.notAllowed = true;
				}, 2000)
				if(this.current==0){
					distributionrider({riderId:this.id,orderId:this.orderId}).then(res=>{
						if(res.code===200){
							this.request=false
							this.notAllowed = true;
							console.log(res.data)
							this.$emit('childconfirm',this.id)
						}else{
							this.notAllowed = true;
							this.request=false
							this.toast(res.msg)
						}
					})
				}else{
					distributionReturnRider({riderId:this.id,roolbackId:this.orderId}).then(res=>{
						if(res.code===200){
							this.request=false
							this.notAllowed = true;
							console.log(res.data)
							this.$emit('childconfirm',this.id)
						}else{
							this.notAllowed = true;
							this.request=false
							this.toast("分配骑手失败")
						}
					})
				}
				
			}
		}
	}
</script>

<style lang="scss" scoped>
	.pop{
		width: 750rpx;
		height: 500rpx;
		box-sizing: border-box;
		background: #FFFFFF;
		border-radius: 10px 10px 0px 0px;
		position: fixed;
		bottom: 0rpx;
		
	}
	.pop-top{
		// display: flex;
		height: 400rpx;
		flex-direction: column;
		justify-content: space-around;
		box-sizing: border-box;
		padding: 28rpx 30rpx 0 30rpx;
		overflow: auto;
		.select{
			display: flex;
			align-items: center;
			justify-content: flex-end;
			height: 40rpx;
			margin-bottom: 27rpx;
			.pop-name{
				flex:1;
				font-size: 28rpx;
				font-weight: 400;
				color: #333333;
			}
			.pop-num{
				flex:2;
				font-size: 28rpx;
				font-weight: 400;
				color: #999999;
				letter-spacing: 7rpx;
				text:nth-child(1){
					
				}
				text:nth-child(2){
					color: #FF4040;
				}
				text:nth-child(3){
					
				}
		
			}
			.pop-radio{
				flex:1;			
				.out{
					width: 30rpx;
					height: 30rpx;
					border: 2rpx solid #176CDC;
					border-radius: 50%;
					position: relative;
					margin-left: auto;
					box-sizing: border-box;
					.inner{
						position: absolute;
						top:16%;
						left:11%;
						width: 20rpx;
						height: 20rpx;
						background: #176CDC;
						border-radius: 50%;
					}
				}
				.def{
					width: 30rpx;
					height: 30rpx;
					border: 2rpx solid #DDDDDD;
					border-radius: 50%;
					margin-left: auto;
				}
				
			}
		}
	}
	.pop-bottom{
		text-align: center;
		border-top: 1px solid #DDDDDD;
		width: 750rpx;
		height: 100rpx;
		box-sizing: border-box;
		line-height: 100rpx;
		.but{
			display: inline-block;
			width: 600rpx;
			height: 68rpx;
			background: #176CDC;
			border-radius: 100px;
			text-align: center;
			font-size: 32rpx;
			font-family: PingFang SC;
			font-weight: 400;
			line-height: 68rpx;
			color: #FFFFFF;
		}
	}
</style>
