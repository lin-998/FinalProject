<template>
	<!-- 已分配订单 -->
	<view class="content">
		<view v-if="orderLists.length==0" class="null" style="text-align: center;background-color:#f3f3f3;;height: 100%;margin-top: 50%;">
			<image src="../../../../static/null.png" 
			style="width: 240rpx;height: 240rpx;"></image>
			<view style="width: 100%;text-align: center;">空空如也</view>
		</view>
		<view v-for="orderList in orderLists" class="orderlist" :key="orderList.id" >
			<view class="order-type">
				<text v-if="orderList.coding" class="coding">订单编号:{{orderList.coding}}</text>
			</view>
			<view v-for="(item,index) in orderList.medicalOrderDtos" class="main" :key="index">
				<view class="main-top">
					<view class="main-top-left">
						<image :src="item.attachmentUrl" mode=""></image>
					</view>
					<view class="main-top-center">
						<view>{{item.name}}</view>
						<view v-if="item.specificationsName">
							{{item.specificationsName}}({{item.specificationsValue}})
						</view>
						<view v-if="item.specificationsParam">{{item.specificationsParam}}</view>
					</view>
					<view class="main-top-right">
						<text>X{{item.count}}</text>
						<view>
							<text>￥</text>
							<text>{{item.money}}</text>
						</view>
					</view>
				</view>
			</view>
			<view class="main-bottom">
				<view class="main-bottom-left">
					<text>合计:</text>
					<text>￥</text>
					<text>{{orderList.sum}}</text>
				</view>
				<view class="main-bottom-right">
					<!-- <view @click="lookDetail(orderList.id)" class="btn-right">查看详情</view> -->
					<view class="btn-right">{{orderList.userName}}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {ridermanageinfo} from "@/util/request.js"
	export default{
		data:function(){
			return{
				tab:"1",
				navleft:"nav1",
				navright:"nav2",
				active:"active",
				unactive:"",
				orderLists:[],
				total:'',
				pageNum:1
			}
		},
		created(){
			this.init()
		},
		methods:{
			init(){
				uni.hideLoading()
				uni.showLoading({
				    title: '加载中'
				});
				ridermanageinfo({pageNum:this.pageNum,pageSize:10,status:2}).then(res=>{
					if(res.code===200){
						let arr=res.data.rows?res.data.rows:[]
						this.orderLists=this.orderLists.concat(arr)
						this.total=res.data.total
						this.orderLists.forEach(val=>{
							let theSum=0;
							if(val.medicalOrderDtos){
								val.medicalOrderDtos.forEach(value=>{
									value.money=parseFloat(value.money).toFixed(2)
									theSum+=parseFloat(value.money)
								})
								val.sum=theSum.toFixed(2)
							}
							
						})
					}
					uni.hideLoading()
					uni.stopPullDownRefresh()
					console.log(this.orderLists)
				}).catch(err=>{
					this.toast(err)
					uni.stopPullDownRefresh()
					uni.hideLoading()
				})
			},
			changepage:function(index){
				this.tab=index
			},
			lookDetail(id){
				uni.navigateTo({
					url:"/pages/rider/detail/detail?id="+id
				})
			},
			refresh(){
				this.pageNum=1
				this.orderLists=[]
				this.init()
			},
			toBottom(){
				if(this.total>this.pageNum*10){
					this.pageNum++
					this.init()
				}else{
					return
				}
			},
			// 点击确认后关闭弹出界面
			confirms:function(name){
				console.log(name);
				this.$refs.mask.$el.style.display="none"
				this.$refs.confirm.$el.style.display="none"
			},
			// 点击分配骑手时弹出界面
			fenpei:function(){
				this.$refs.mask.$el.style.display="block"
				this.$refs.confirm.$el.style.display="block"
			}
		}
	}
</script>

<style scoped lang="scss">
	.order{
		background-color: #f6f6f6;
	}
	.orderlist{
		background-color: #FFFFFF;
		margin-top: 30rpx;
		.order-type{
			// color: red;
			padding:0rpx 30rpx 10rpx 30rpx;
			font-size: 30rpx;
		}
	}
	.content{
		background-color: #f6f6f6;
		// height: 2000rpx;
	}
	.main{
		margin-left: 30rpx;
		box-sizing: border-box;
		width: 690rpx;
		// height: 290rpx;
		background: #FFFFFF;
		border-radius: 10rpx;
		// margin-top: 20rpx;
		// padding: 0rpx 30rpx 0 30rpx;
		.main-top{
			height: 200rpx;
			box-sizing: border-box;
			display: flex;
			// padding-top: 20rpx;
			border-top: 1rpx solid #DDDDDD;
			.main-top-left{
				flex:2;
				align-self: center;
				image{
					width: 140rpx;
					height: 140rpx;
	
				}
			}
			.main-top-center{
				flex:4;
				height: 180rpx;
				display: flex;
				margin-left:20rpx;;
				flex-direction: column;
				justify-content: space-around;
				view:nth-child(1){
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
	
				}
				view:nth-child(2){
					font-size: 22rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
				}
				view:nth-child(3){
					text:nth-child(1){
						font-size: 20rpx;
						color: #FF4040;
						
					}
					text:nth-child(2){
						font-size: 32rpx;
						font-family: PingFang SC;
						font-weight: bold;
						color: #FF4040;
					}
				}
			}
			.main-top-right{
				flex:2;
				padding: 30rpx 0;
				//height: 180rpx;
				display: flex;
				flex-direction: column;
				justify-content: space-between;
				text-align: right;
				text:nth-child(1){
					flex:1;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #FF4040;
				}
				text:nth-child(2){
					flex:1;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #FF4040;
				}
			}
		}
		
	}
	.main-bottom{
		display: flex;
		padding: 20rpx 30rpx;
		.main-bottom-left{
			flex: 1;
			text:nth-child(1){
				font-size: 24rpx;
				color:#333333;
			}
			text:nth-child(2){
				font-size: 20rpx;
				color: #FF4040;
			}
			text:nth-child(3){
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #FF4040;
			}
		}
		.main-bottom-right{
			flex:2;
			text-align: right;
			view{display: inline-block;}
			.btn-left{
				width: 140rpx;
				height: 48rpx;
				border: 1rpx solid #999999;
				border-radius: 100px;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #999999;
				text-align: center;
				line-height: 48rpx;
				
			}
			.btn-right{
				width: 140rpx;
				height: 48rpx;
				border: 1rpx solid #999999;
				border-radius: 100rpx;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #FFFFFF;
				background: #176CDC;
				text-align: center;
				line-height: 48rpx;
				margin-left: 42rpx;
			}
		}
	}
	
</style>
