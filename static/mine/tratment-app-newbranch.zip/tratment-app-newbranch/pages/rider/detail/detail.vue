<template>
	<!-- 订单详情界面 -->
	<view @click="">
		<view class="form-data">
			<u-form :model="form">
				<!-- 公司 -->
				<u-form-item label-width="140rpx" label="公司:" prop="name" class="company fornitem" label-align="right">
					<view>
						<u-input disabled border value="智慧医疗" class="uinput" label-align="right"></u-input>
					</view>
				</u-form-item>
				<!-- 医院 -->
				<u-form-item label-width="140rpx" label="医院:" prop="name" label-align="right" class="hospital fornitem">	
					<view>
						<u-input disabled v-model="form.hospital"></u-input>
					</view>
				</u-form-item>
				<!-- 品牌 -->
				<u-form-item label-width="140rpx" label-align="right" label="品牌:" prop="name" class="brand fornitem">
					<view>
						<u-input disabled v-model="form.brand" placeholder="无"></u-input>
					</view>
				</u-form-item>
				<!-- 显示已下单商品 -->
				<view class="shangpin" v-if="shopes.length>0">
					<text>已下单商品</text>
					<view v-for="(item,index) in shopes[0].medicalOrderDtos" class="shop" :key="index">
						<view>
							<image :src="item.attachmentUrl" mode=""></image>
						</view>
					<view class="shop-detail" v-if="item.specificationsName">
						<text>{{item.name}}</text>
						<text style="color: #999999;">{{item.specificationsName}}||{{item.specificationsValue}}</text>
					</view>
					<view class="shop-detail" v-if="item.specificationsParam">
						<text>{{item.name}}</text>
						<text style="color: #999999;">{{item.specificationsParam}}</text>
					</view>
						<view>
							<view class="num">X{{item.count}}</view>
							<view class="price"><text>￥</text>{{item.money}}</view>
						</view>
					</view>
				</view>
				</u-form-item>
				<!-- 联系人电话 -->
				<u-form-item label-width="140rpx" label="联系人:" prop="name" class="tel fornitem" label-align="right">
					<view>
						<u-input disabled v-model="form.createBy"/>
					</view>
				</u-form-item>
				<!-- 联系人电话 -->
				<u-form-item label-width="140rpx" label="联系电话:" prop="name" class="tel fornitem" label-align="right">
					<view>
						<u-input disabled v-model="form.phone"/>
					</view>
				</u-form-item>
				
				<!-- 备注图片 -->
				<u-form-item label-width="140rpx" label="备注图片:" class="img fornitem" label-align="right">
					<image v-for="(itme,index) in form.medicalOrderAttachments"
					:key="index" 
					:src="itme.attachmentUrl" 
					@click="previewImg(itme.attachmentUrl)"
					style="width:140rpx;height:140rpx;margin-right: 20rpx;"></image>
				</u-form-item>
				<!-- 物流方式 -->
				<u-form-item label-width="140rpx" label="物流方式:" prop="name" class="met fornitem" label-align="right">
					<u-input disabled v-model="logisticsMode"/>
				</u-form-item>
				<!-- 合格证 -->
				<u-form-item label-width="140rpx" label="带合格证:" class="swi fornitem" label-align="right">
					<u-switch slot="right" v-model="switchVal" disabled></u-switch>
				</u-form-item>
				<!-- 收货地址 -->
				<u-form-item label-width="140rpx" label="收货地址:" prop="name" class="address fornitem" label-align="right">
					<view>
						<u-input disabled v-model="form.address"/>
					</view>
				</u-form-item>
				<!-- 备注 -->
				<u-form-item label-width="140rpx" label="备注:" prop="name" class="remark fornitem" label-align="right">
					<view>
						<u-input disabled v-model="form.remark" placeholder=""/>
					</view>
				</u-form-item>
				<view class="fornitem order">
					<view class="title">
						订单信息
					</view>
					<view class="content">
						<view class="order-main">
							<view>订单编号：{{form.coding}}</view>
							<view>创建时间：{{form.createTime}}</view>
							<view class="img">
								<text>二维码：</text>
								<image :src="form.qrCode" @click="previewImg(form.qrCode)"></image>
							</view>
						</view>
						<view class="info-btn">
							<!-- <view class="btn">复制</view> -->
						</view>
					</view>
				</view>
			</u-form>
		</view>
	</view>
</template>

<script>
	import {getbaseorderinfo,
					checkorder,
					getorderdetail,
					confirmreceipt}from '@/util/request.js'
	export default {
		data() {
			return {
				fileList: [],
				// 物流方式
				logisticsMode:"0",
				certificate:"0",
				addressVal:'',
				selecValue: '',
				shopselect:"shopselect",
				shopcancle:"shopcancle",
				selectShop:[],
				shopes:[],
				form: {},
				// 是否带合格证
				switchVal: false,
				textareaVal: '',
				type:0,
				id:''
			}
		},
		onLoad(option){
			let storage=uni.getStorageSync('selectShop')
			this.selectShop=storage ? storage : [],
			this.type=option.type
			this.id=option.id
			getorderdetail({id:option.id}).then(res=>{
				if(res.code===200){
					this.form=res.data[0]
					console.log(this.switchVal)
					if(res.data[0].certificate==0){
						this.switchVal=false
					}else{
						this.switchVal=true
					}
					console.log(this.switchVal)
					this.logisticsMode=res.data[0].logisticsMode=='1'?'自提':'物流'
					this.shopes=res.data
					console.log(res.data)
				}
			})
		},
		methods: {
			previewImg(logourl) {
				let _this = this;
				let imgsArray = [];
				imgsArray[0] = logourl
				uni.previewImage({
					current: 0,
					urls: imgsArray
				});
			}
		},
		created(){
			// console.log(areaData);
		}
	}
</script>

<style lang="scss" scoped>
	/deep/.uni-navbar--border {
		border: none;
	  width: 100%;
	}
	/deep/.uni-searchbar__box{
		width: 100%;
		border: none;
	}
	.form-data {
		background-color: #FFFFFF;
		 .fornitem{
			 font-size: 28rpx;
			 font-family: PingFang SC;
			 font-weight: 400;
			 color: #333333;
			 padding: 30rpx;
			 background-color: #FFFFFF;
			 .uinput{
					margin-left: 10rpx;
					 width: 420rpx;
					 vertical-align: middle;
					 background: #FAFAFA;
					 border: 1rpx solid #DDDDDD;
					 border-radius: 10rpx;
					 box-sizing: border-box;
			 }
		 }
		 .shop-item{
			  padding: 30rpx;
			 width: 540rpx;
			 // height: 200rpx;
			 background: #FAFAFA;
			 border: 1rpx solid #DDDDDD;
			 border-radius: 10rpx;
			 .shop{
				 // padding-bottom: 25rpx;
				 display: flex;
				 view{
					 flex:1;
					 // text-align: right;
					 // padding-right: 10rpx;
					 width: 100%;
					 .shopselect{
						 width: 30rpx;
						 height: 30rpx;
						 border-radius:15rpx;
						 background: #176CDC;
					 }
					 .shopcancle{
						 width: 30rpx;
						 height: 30rpx;
						 border-radius:15rpx;
						 background: #ffffff;
						 display: inline-block;
						 border: 2rpx solid #DDDDDD;
					 }
				 }
				 .shopname{
					 flex:5;
					 // height: 33rpx;
					 font-size: 24rpx;
					 color: #333333;
					 text-align: left;
				 }
				 .shopnum{
					 flex:1;
					 text-align: right;
					 font-size: 24rpx;
					 color: #176CDC;
				 }
			 }
		 }
		 
		.text-area {
			border: 1rpx solid #ccc;
			position: relative;
			.text-max {
				color: #888;
				font-size: 24rpx;
				position: absolute;
				bottom: 30rpx;
				right: 30rpx;
			}

			textarea {
				padding: 10rpx;
				box-sizing: border-box;
				width: 540rpx;
				height: 170rpx;
				background: #FAFAFA;
				border: 1rpx solid #DDDDDD;
				opacity: 1;
				border-radius: 10rpx;
			}
		}

		.demand-goods {
			display: flex;
			justify-content: space-between;

			navigator {
				padding: 20rpx 28rpx;
				font-size: 28rpx;
				color: #57A1F9;
			}
		}
	}

	.u-field {
		padding-left: 0;

		.u-textarea-inner {
			display: flex;
			align-items: center !important;
		}

		.fild-body {
			border: 1rpx solid #C0C0C0 !important;
		}
	}

	.u-form-item {
		// line-height: 0rpx;
		font-size: 28rpx;
	}

	.u-border-bottom:after {
		border: 0 solid #bbbbbb;
		border-bottom-width: 1px;
	}

	.uni-textarea-placeholder {
		color: #888888;
		padding: 10rpx;
		box-sizing: border-box;
	}

	.u-label {
		flex: 0 0 20rpx !important;
	}

	.select-easy {
		width: 400rpx !important;
		height: 60rpx !important;
	}
	/deep/.u-line-1{
		height: 100% !important;
		line-height: 200% !important;
	}
	.address-inp{
		width: 400rpx;
		height: 60rpx;
		padding-left: 20rpx;
		box-sizing: border-box;
		border-radius: 10rpx;
		border: 1rpx solid #bbb;
		font-size: 28rpx;
		&::after{
			content: ">";
			position: absolute;
			right:80rpx;
			top: 50rpx;
			transform: rotate(90deg);
			width: 14px;
			height: 8px;
			color: #888;
			font-weight: 1000;
		}
	}
	.shangpin{
		padding: 25rpx 30rpx;
		background-color: #FFFFFF;
		text{
			font-size: 29rpx;
			font-family: PingFang SC;
			font-weight: bold;
			line-height: 40rpx;
			color: #333333;
		}
		.shop{
			display: flex;
			padding: 20rpx 0;
			border-bottom: 1rpx solid #DDDDDD;
			opacity: 1;
			.shop-detail{
				display: flex;
				flex-direction: column;
				justify-content: space-around;
			}
			view:nth-child(1){
				flex:1;
				image{
					width: 120rpx;
					height: 120rpx;
					border: 1px solid #707070;
					border-radius: 6px;
				
				}
			}
			view:nth-child(2){
				flex:3;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
				line-height: 33rpx;
				margin-left: 19rpx;
			}
			view:nth-child(3){
				flex:2;
				text-align: right;
				display: flex;
				flex-direction: column;
				justify-content: space-around;
				.num{
					flex:1;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #FF4040;
				}
				.price{
					flex:1;
					font-size: 32rpx;
					font-family: PingFang SC;
					font-weight: bold;
					color: #FF4040;
					text{
						font-size: 20rpx;
						color: #FF4040;
					}	
				}
			}
		}
	}
	// 订单信息
	.order{
		width: 100%;
		box-sizing: border-box;
		.title{
			font-size: 29rpx;
			font-weight: bold;
			padding-bottom: 28rpx;
		}
		.content{
			display: flex;
			.order-main{
				flex:2;
				font-size: 24rpx;
				display: flex;
				flex-direction: column;
				justify-content: space-between;
				view{
					flex:1;
					margin-bottom: 10rpx;
					font-size: 24rpx;
					text{
						display: inline-block;
						vertical-align: top;
					}
					image{
						width: 140rpx;
						height: 141rpx;
					}
				}
			}
			.info-btn{
				flex:1;
				text-align: right;
				.btn{
					display: inline-block;
					width: 110rpx;
					height: 38rpx;
					border: 1rpx solid #176CDC;
					border-radius: 100rpx;
					text-align: center;
					line-height: 38rpx;
					font-size: 24rpx;
					color: #176CDC;
				}
			}
		}	
	}
	.but{
		padding-bottom: 150rpx;
		.submit-btn{
			color: #fff !important;
			height: 88rpx !important;
			// margin-bottom: 90rpx !important;
			margin-top: 70rpx !important;
			width: 600rpx;
			background: #CCCCCC;
			border-radius: 44rpx;
		}
		
		.bg-btn2{
			background: #CCCCCC;;
		}
		.bg-btn3{
			background-color:#176CDC ;
		}
	}
	.bom-btn{
		font-size: 32rpx;
		display: flex;
		width: 100%;
		height: 98rpx;
		text-align: center;
		background: #FFFFFF;
		align-items: center;
		box-shadow: 0px -1px 4px rgba(86, 86, 86, 0.16);
		position: fixed;
		bottom:0rpx;
		z-index: 9999;
		.btn2{
			flex: 1;
			text-align: center;
			view{
				margin:0 auto;
				// margin-left: 25rpx;
				text-align: center;
				line-height: 68rpx;
				color: #FFFFFF;
				width: 560rpx;
				height: 68rpx;
				background: #176CDC;
				border-radius: 44rpx;
			}
		}
	}
	.text-area {
		border: 1rpx solid #ccc;
		padding: 10rpx;
		box-sizing: border-box;
		width: 540rpx;
		height: 170rpx;
		background: #FAFAFA;
		border: 1rpx solid #DDDDDD;
		opacity: 1;
		border-radius: 10rpx;
		color: red;
	}
	
</style>
