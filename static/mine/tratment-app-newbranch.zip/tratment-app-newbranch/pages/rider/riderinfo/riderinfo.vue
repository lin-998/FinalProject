<template>
	<!-- 订单信息 -->
	<view class="orederinfo">
		<view class="shangpin" v-if="shoppes.length>0">
			<!-- <text>已下单商品</text> -->
			<view v-for="(item,index) in shoppes" class="shop" :key="index">
				<view class="shop-image">
					<image :src="item.attachmentUrl" mode=""></image>
				</view>
				<view class="shop-detail" v-if="item.specificationsName">
					<text>{{item.name}}</text>
					<text style="color: #999999;">{{item.specificationsName}}||{{item.specificationsValue}}</text>
					<view>
						<view class="price"><text>￥</text>{{item.money}}</view>
						<view class="num">X{{item.count}}</view>
					</view>
				</view>
				<view class="shop-detail" v-if="item.specificationsParam">
					<text>{{item.name}}</text>
					<text style="color: #999999;">{{item.specificationsParam}}</text>
					<view>
						<view class="price"><text>￥</text>{{item.money}}</view>
						<view class="num">X{{item.count}}</view>
					</view>
				</view>
			</view>
		</view>
		<!-- 订单信息包括联系方式，备注，订单编号，，时间等 -->
		<view class="detail">
			<!-- 电话 -->
			
			<view class="tel">
				<text>联系人：</text>
				<text>{{baseInfo.createBy}}</text>
			</view>
			<view class="address">
				<text>联系电话：</text>
				<text>{{baseInfo.phone}}</text>
			</view>
			<view class="address">
				<text>收件地址：</text>
				<text>{{baseInfo.address}}</text>
			</view>
			<!-- 备注 -->
			<view class="beizhu">
				<text>备注：</text>
				<text>{{baseInfo.remark}}</text>
			</view>
			<!-- 订单编号二维码等 -->
			<view class="info">
				<view class="info-left">
					<text class="info-header">订单信息</text>
					<view class="info-id">
						<text>订单编号：</text>
						<text>{{baseInfo.coding}}</text>
					</view>
					<view  class="info-time">
						<text>创建时间：</text>
						<text>{{baseInfo.createTime}}</text>
					</view>
					<view class="info-ewm">
						<text>二维码：</text>
						<image :src="baseInfo.qrCode" @click="previewImg(baseInfo.qrCode)"></image>
					</view>
				</view>
				<view class="info-right">
					<!-- <view>复制</view> -->
				</view>
			</view>
		<!-- 	配送状态 -->
			<!-- <view class="state">
				<text>配送状态：</text>
				<select name="state" v-model="state"  style="text-align: center;">
					<option value="待配送">待配送</option>
					<option value="已配送">已配送</option>
				</select>
			</view> -->
		</view>
		<!-- 更新按钮 -->
		<!-- <view class="but">
			<view @click="updateState()">更新</view>
		</view> -->
	</view>
</template>

<script>
	import {getbaseorderinfo,
					getorderdetail,
					getbsaereturnorderinfo,
					getreturnordershopinfo,}from '@/util/request.js'
	export default{
		data:function(){
			return{
				baseInfo:[],
				shoppes:[],
				state:''
				}
		},
		onLoad(option) {
			if(option.type==0){
				// 获取商品基本信息
				// getbaseorderinfo({id:option.id}).then(res=>{
				// 	if(res.code===200){
						
				// 	}
				// })
				// 获取已下单商品信息
				getorderdetail({id:option.id}).then(res=>{
					if(res.code===200){
						this.baseInfo=res.data[0]
						this.shoppes=res.data[0].medicalOrderDtos
						console.log(this.shoppes)
					}
				})
			}else{
				getbsaereturnorderinfo({id:option.id}).then(res=>{
					if(res.code===200){
						this.baseInfo=res.data
					}
				})
				getreturnordershopinfo({id:option.id}).then(res=>{
					if(res.code===200){
						this.shoppes=res.data[0].medicalRoolBackOrderDtoList
					}
				})
			}
		},
		methods:{
			previewImg(logourl) {
				let _this = this;
				let imgsArray = [];
				imgsArray[0] = logourl
				uni.previewImage({
					current: 0,
					urls: imgsArray
				});
			},
			updateState(){
				if(this.state==""){
					uni.showToast({
						title: '请选择状态!!!',
						icon:"none"
					});
					return false
				}
				
			}
		}
	}
</script>
	
<style lang="scss" scoped>
	.orederinfo{
		background-color: #f6f6f6;
		// height: 2000rpx;
		// text-align: center;
	}
	.detail{
		background: #FFFFFF;
		margin-top:20rpx;
		box-sizing: border-box;
		padding: 25rpx 30rpx 0 30rpx;
		text-align: left;
		.address{
			// border-bottom: 1rpx solid #DDDDDD;
			padding: 24rpx 0;
			text:nth-child(1){
				// margin-left: 56rpx;
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
			}
			text:nth-child(2){
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
				opacity: 1;
			
			}
		}
		.tel{
			padding-bottom:24rpx; 
			// border-bottom: 1rpx solid #DDDDDD;
			text:nth-child(1){
				margin-left: 28rpx;
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
			}
			text:nth-child(2){
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
			}
		}
		.beizhu{
			// border-bottom: 1rpx solid #DDDDDD;
			padding: 24rpx 0;
			text:nth-child(1){
				margin-left: 56rpx;
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
			}
			text:nth-child(2){
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
				opacity: 1;

			}
		}
		.info{
			border-top: 1rpx solid #DDDDDD;
			display: flex;
			padding-top: 24rpx;
			.info-left{
				flex: 2;
				.info-header{
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: bold;
					color: #333333;
				}
				.info-id{
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					margin-top: 28rpx;
					line-height: 40rpx;
				}
				.info-time{
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					line-height: 40rpx;
				}
				// 二维码
				.info-ewm{
					line-height: 40rpx;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #333333;
					text{
						display: inline-block;
						margin-left: 24rpx;
						vertical-align: top;
					}
					image{
						width: 120rpx;
						height: 120rpx;
						opacity: 1;
				
					}
				}
			}
			.info-right{
				flex: 1;
				text-align: right;
				margin-top: 60rpx;
				view{
					display: inline-block;
					width: 110rpx;
					height: 38rpx;
					line-height: 38rpx;
					border: 1px solid #176CDC;
					border-radius: 100px;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #176CDC;
					text-align: center;
				}
			}
		}
		.state{
			height: 118rpx;
			line-height: 118rpx;
			text{
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
			}
			select{
				width: 420rpx;
				height: 58rpx;
				background: #FAFAFA;
				border: 1rpx solid #DDDDDD;
				border-radius: 10rpx;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #999999;
			}
		}
	}
	.shangpin{
		padding: 25rpx 30rpx;
		background-color: #FFFFFF;
		text{
			font-size: 29rpx;
			font-family: PingFang SC;
			font-weight: bold;
			line-height: 40rpx;
			color: #333333;
		}
		.shop{
			display: flex;
			padding: 20rpx 0;
			// border-bottom: 1rpx solid #DDDDDD;
			opacity: 1;
			.shop-image{
				flex:1;
				image{
					width: 120rpx;
					height: 120rpx;
					border: 1px solid #707070;
					border-radius: 6px;
				}
			}
			.shop-detail{
				display: flex;
				flex-direction: column;
				justify-content: space-around;
				flex:4;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 400;
				color: #333333;
				line-height: 33rpx;
				margin-left: 19rpx;
				view{
					display: flex;
					.num{
						flex:1;
						font-size: 24rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #FF4040;
						display: inline-block;
						text-align: right;
					}
					.price{
						flex:1;
						font-size: 32rpx;
						font-family: PingFang SC;
						font-weight: bold;
						color: #FF4040;
						text{
							font-size: 20rpx;
							color: #FF4040;
						}	
					}
				}
			}
		
		}
	}
	// 更新按钮
	.but{
		text-align: center;
		margin-bottom: 100rpx;
		view{
			width: 600rpx;
			height: 88rpx;
			display: inline-block;
			background: #176CDC;
			border-radius: 44rpx;
			font-size: 32rpx;
			font-family: PingFang SC;
			font-weight: 400;
			line-height: 88rpx;
			color: #FFFFFF;
			text-align: center;
			display: inline-block;
			margin-top: 60rpx;
		}
	}
</style>
