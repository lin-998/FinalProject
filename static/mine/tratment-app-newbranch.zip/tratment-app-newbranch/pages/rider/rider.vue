<template>
	<!-- 骑手页面 -->
	<view class="fenpei">
		<view class="status_bar">
			<!-- 这里是状态栏 -->
		</view>
		<view class="status_bar1">
			<!-- 这里是状态栏 -->
		</view>
		<uni-nav-bar fixed style="width: 100%;">
			<view slot="default" class="title">骑手订单</view>
			<view slot="left" @click="scan()" style="margin-left: 10rpx;">
				<u-icon name="scan" size="50" top="5" label-pos="bottom"></u-icon>
			</view>
			<view slot="right" @click="out()" style="font-size: 30rpx;color:#2B85E4 ;">退出</view>
		</uni-nav-bar>
		<u-tabs class="tab" bg-color="#eee" :list="list" :bold="false" :current="current" @change="change2"></u-tabs>
		<view class="content">
			<!-- 待配送订单模块 -->
			<view v-if="current==0">
				<rider-pick ref="riderList"></rider-pick>
			</view>
			<view v-if="current==1">
				<rider-wait ref="riderList"></rider-wait>
			</view>
			<!-- 已配送订单模块 -->
			<view v-if="current==2">
				<rider-complete ref="riderList"></rider-complete>
			</view>
			<!-- 待配送退货订单模块 -->
			<!-- <view v-if="current==2">
				<rider-undelivered ref="riderList"></rider-undelivered>
			</view> -->
			<!-- 已配送退货订单模块 -->
			<!-- <view v-if="current==3">
				<rider-delivered ref="riderList"></rider-delivered>
			</view> -->
		</view>
	</view>
</template>

<script>
	export default{
		data:function(){
			return{
				tab:"1",
				navleft:"nav1",
				navright:"nav2",
				active:"active",
				unactive:"",
				items:[],
				current:0,
				list: [
					{name: '待取货'},
					{name: '待配送'}, 
					{name: '已配送'}
					// {name: '待配送(退货)'}, 
					// {name: '已配送(退货)'}
				]
			}
		},
		created() {
			
		},
		methods:{
			change2(index){
				this.current = index;
			},
			changepage:function(index){
				this.tab=index
			},
			out(){
				let loginInfo=uni.getStorageSync("loginInfo")
				uni.clearStorageSync()
				uni.setStorageSync("loginInfo",loginInfo);
				uni.redirectTo({
					url: "/pages/login/login?type=1"
				})
			},
			scan(){
				uni.scanCode({
					success: (res) => {
						if(res.scanType==='QR_CODE'){
							uni.navigateTo({
							url:"/pages/user/myorder/qrorder/qrorder?id="+res.result
						})
						}else{
							this.toast('扫码失败')
						}
						console.log(123456);
						console.log(res);
					}
				})
			},
			onReachBottom() {
				console.log("bottom")
				this.$refs.riderList.toBottom()
			},
			// onNavigationBarButtonTap(){
				
			// }
		}
	}
</script>

<style scoped lang="scss">
	.fenpei{
		.title {
			margin: 0 auto;
			font-size: 42rpx;
			font-family: Source Han Sans CN;
			font-weight: 400;
			color: #333333;
		}
		
		.status_bar {
			height: var(--status-bar-height);
			width: 100%;
			background: #FFFFFF;
			position: fixed;
			top: 0;
			z-index: 999999;
		}
		
		.status_bar1 {
			height: var(--status-bar-height);
			width: 100%;
		}
		/deep/.uni-navbar--border {
			border: none;
			width: 100%;
		}
		
		/deep/.uni-searchbar__box {
			width: 100%;
			border: none;
		}
	}
	
	.nav{
		width: 100%;
		height: 88rpx;
		line-height: 88rpx;
		background-color: white;
		margin-bottom: 30rpx;
		text{
			font-size: 30rpx;
		}
		.nav1{
			text-align:left;
			margin-left:48rpx;
		}
		.nav2{
			// font-weight: 400;
			margin-left: 64rpx;
			
		}
	
	}
	// 遮罩层
	.mask{
		display: none;
		width: 750rpx;
		height: 1334rpx;
		z-index: 10;
		position: fixed;
		top: 0;
		background: rgba(0, 0, 0, 0.6);
		opacity: 1;
	}
	.pop{
		display: none;
		z-index: 11;
	}
	.active{
		color: #176CDC;
		font-weight: bold;
	}
</style>
