
<style lang="scss">
	/* 注意要写在第一行，同时给style标签加入lang="scss"属性 */
	@import "uview-ui/index.scss";
</style>
<script>
	import { javaHb } from "@/util/utils.js";
	export default {
	 mounted: function () {
			 // let vConsole = new VConsole()
			 setTimeout(() => {
				 try {
					 javaHb.plusReady();
				 } catch (error) {console.log(error)}
			 }, 3000);
		 },
		onLaunch: function() {
			// console.log('App Launch');
		},
		onShow: function() {
			// let token=uni.getStorageSync("token")
			// console.log(token);
		},
		onHide: function() {
			// console.log('App Hide');
		},

	};
</script>

<style lang="less">
	/deep/.uni-navbar--border{
		border: none !important;
	}
	.allColor{
		background: #176CDC !important;
	}
	page{
		background: #FAFAFA;
		height: 100%;
	}
// @import "https://cdn.bootcdn.net/ajax/libs/animate.css/2.0/animate.css";
	// page{
	// 	// height: 100%;
	// }
	// /* 解决头条小程序组件内引入字体不生效的问题 */
	// /* #ifdef MP-TOUTIAO */
	// @font-face {
	// 	font-family: uniicons;
	// 	src: url('/static/uni.ttf');
	// }

	// /* #endif */
	// .uni-tabbar {
	// 	.uni-tabbar__item {
	// 		&:nth-child(2) {
	// 			.uni-tabbar__bd{
	// 				background: #FFD700;
	// 				border-radius: 50%;
	// 				width: 100rpx;
	// 				font-size: 24rpx;
	// 			}
	// 		}
	// 	}

	// }
</style>
