import Vue from 'vue'
import App from './App'
//引入vuex
import store from './store'
// import router from './router'
import uView from "uview-ui";

import { Utils } from './common/common.js'
import httpUrl from './util/httpUrl.js'
Vue.prototype.$httpUrl = httpUrl;
Vue.use(uView);

//消息提示
Vue.prototype.toast = Utils.toast;
Vue.config.productionTip = false
App.mpType = 'app'
const app = new Vue({
	...App,
	store
})
app.$mount()