import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)
const store = new Vuex.Store({
    state: {
			iSselect:0,
			userinfo:{
				username:'你真是个人才',
				password:'123456'
			}
		},
    mutations: {},
    actions: {}
})
export default store