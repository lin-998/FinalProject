// const Url="http://192.168.105.31:7003/app-user-server"
// const websiteURL='http://192.168.105.31:7003/hd-website-server'
// const goodsUrl="http://192.168.105.31:7003/hd-goods-server"
// const orderUrl="http://192.168.105.31:7003/hd-order-server"
// const riderUrl="http://192.168.105.31:7003/hd-rider-server"

const Url="https://tech.a6shop.net:8058/smartMedical-app/app-user-server"
const websiteURL='https://tech.a6shop.net:8058/smartMedical-app/hd-website-server'
const goodsUrl="https://tech.a6shop.net:8058/smartMedical-app/hd-goods-server"
const orderUrl="https://tech.a6shop.net:8058/smartMedical-app/hd-order-server"
const riderUrl="https://tech.a6shop.net:8058/smartMedical-app/hd-rider-server"
const httpApi ={
	imageUpload:orderUrl+"/medicalOrderAttachment/upload",
	getPublicK:Url+"/login/getPublicKey",//获取公钥
	Login:Url+"/login/login",// 登录
	Logout:Url+"/login/logout",//退出登录
	loginSms:Url+"/login/loginSms",//手机号加验证码登录
	Register:Url+"/login/registeredUser",//注册用户
	forgetPassword:Url+"/login/forgetPassword",//找回密码
	// Company:websiteURL+"/medicalCompany/getCompanyList",
	getPassword:Url+"/send/forgetPasswordSendsms",//获取忘记密码验证码
	getRegister:Url+"/send/registerSendSms",//获取注册验证码
	
	// 首页
	// gethomeList:websiteURL+"/medicalHomePage/getAll",//获取首页轮播图
	getShuffling:goodsUrl+"/medicalGoods/getShuffling",//图片轮播
	getVisitorGoodsPage:goodsUrl+"/medicalGoods/getVisitorGoodsPage",//游客看到的商品
	
	//资料下载
	getNotice:websiteURL+"/medicalNotice/medicalnotice",//获取公告
	getOursList:websiteURL+"/medicalAboutOurs/getOursList",//关于我们
	getInformationList:websiteURL+"/medicalMaterialAttachment/getAttchmentByType",//获取资料信息
	// getInformationList:websiteURL+"/medicalMaterialAttachment/getAttchmentByType"	
	getDownload:websiteURL+"/medicalMaterialAttachment/download",//资料下载
	 
	getOurShuffling:websiteURL+"/medicalAboutOurs/getShuffling",//关于我们轮播图片
	// 商品分类
	gateGorylist:goodsUrl+"/medicalGoodsCategory/List",//获取所有类别
	getTreelist:goodsUrl+"/medicalCategoryMenu/getTree",//根据类别id获取子类别
	searchGoods:goodsUrl+"/medicalGoods/searchGoods",//模糊搜索商品
	viewGoods:goodsUrl+"/medicalGoods/view",//获取商品详情
	
	// 商家入驻
	uploadAttachment:websiteURL+"/medicalStoreAttachment/upload",//上传营业执照
	deleteAttachment:websiteURL+"/medicalStoreAttachment/delete",//删除营业执照
	createAttachment:websiteURL+"/MedicalStore/create",//商家入驻申请
	getResult:websiteURL+"/MedicalStore/getResult",//商家入驻申请结果
	submitAgain:websiteURL+"/MedicalStore/submitAgain",//商家入驻再次申请
	
	// 订单信息
	uploadremark:orderUrl+"/medicalOrderAttachment/upload",//上传备注图片
	deleteremark:orderUrl+"/medicalOrderAttachment/delete",//删除备注图片
	getorderinfo:orderUrl+"/medicalOrder/userPage",//获取订单信息
	getcheckinfo:orderUrl+"/medicalOrder/checkPage",//相应审核人审核订单page页面
	overBooking:orderUrl+"/medicalOrder/create",//添加订单
	getbaseorderinfo:orderUrl+"/medicalOrder/viewBasicInfo",//查看详情----基本信息
	checkorder:orderUrl+"/medicalOrder/check",//审核人员订单审核
	getorderdetail:orderUrl+"/medicalOrder/viewGoods",//查看详情----产品
	ridermanageinfo:orderUrl+"/medicalOrder/riderAdminOrderPage",//骑手管理员看到的订单信息---1是待分配骑手2已经分配就是配送中
	
	addselectshop:orderUrl+"/medicalOrderGoods/create",//商品加入已选
	deleteselect:orderUrl+"/medicalOrderGoods/delete",//删除已选
	editselect:orderUrl+"/medicalOrderGoods/update",//编辑已选
	lookselect:orderUrl+"/medicalOrderGoods/view",//查看已选
	cancleorder:orderUrl+"/medicalOrder/cancelOrder",//订单取消----下单人（未审核的订单）
	deleteorder:orderUrl+"/medicalOrder/deleteOrder",//删除已取消订单
	riderorderinfo:orderUrl+"/medicalOrder/riderOrderPage",// 对应骑手看到的订单--派送中的和派送完成的
	createQR:orderUrl+"/medicalOrder/createQR",//生成二维码丢到服务器
	confirmreceipt:orderUrl+"/medicalOrder/updateOrderStatus",//下单人跟新状态---已完成
	returngoodsinfo:orderUrl+"/medicalOrder/viewRoolbackGoodsDetail",//查看订单中的商品信息 -- 用于申请退货页面
	createRoolbackOrder:orderUrl+"/medicalOrderRoolback/createRoolbackOrder ",//创建退货订单
	createRoolbackQR:orderUrl+"/medicalOrderRoolback/createQR",//生成二维码丢到服务器
	getreturnorderinfo:orderUrl+"/medicalOrderRoolback/cancleOrderPage",// 退货人退货page
	canclereturnorder:orderUrl+"/medicalOrderRoolback/roolbackCancle",//  退货取消
	deletereturnorder:orderUrl+"/medicalOrderRoolback/deleteRoolbackOrder",// 删除订单----已经取消的
	getreturncheckorder:orderUrl+"/medicalOrderRoolback/cancleOrderCheckPage",// 审核退货page
	getbsaereturnorderinfo:orderUrl+"/medicalOrderRoolback/viewBasicInfoOfOrder",// 退货查看详情----基本信息
	getreturnordershopinfo:orderUrl+"/medicalOrderRoolback/viewGoodsInfo",//  退货单--商品信息
	checkreturnorder:orderUrl+"/medicalOrderRoolback/check",//审核人员订单审核（正常订单的审核）--1审核通过5不
	riderreturninfo:orderUrl+"/medicalOrderRoolback/cancleOrderRiderPage",//骑手退货page
	managereturninfo:orderUrl+"/medicalOrderRoolback/cancleOrderRiderAdminPage",// 骑手管理员退货page
	updateMeal:orderUrl+"/medicalOrderGoods/updateMeal",//编辑已选---套餐(goodsID，specID,Times)



	// 骑手信息
	distributionrider:riderUrl+"/medicalRiderOrder/distributionOrderToRider",//分配任务
	distributionReturnRider:riderUrl+"/medicalRiderOrder/distributionRoolbackOrderToRider",//分配退单的任务
	 
	getrider:riderUrl+"/userInfo/getRiderList",//获取骑手
	
	
	getAddressAll:Url+"/user/getAddressAll",//根据当前登录用户查询用户的所有地址
	 
	createAgain:orderUrl+"/medicalOrder/createAgain",// 再次下单 -- 已取消订单再次下单
	
	confirmPickupToRider:riderUrl+"/medicalRiderOrder/confirmPickupToRider",//骑手确定取货
	cancelPickupToRider:riderUrl+"/medicalRiderOrder/cancelPickupToRider",//骑手管理员取消骑手分配
	
	getMenuTwoList:goodsUrl+"/medicalGoodsCategory/getMenuTwoList",//获取第二级品牌列表
	
	
	getTree:goodsUrl+"/medicalCategoryMenu/getTree",//返回套餐商品树 ----status 0内部用户发布的产品1会员商家发布的产品
	
	viewSetMeal:goodsUrl+"/medicalGoods/viewSetMeal",//套餐商品的详情----详情
	
	insertSetMeal:orderUrl+"/medicalOrderGoods/insertSetMeal",//套餐加入已选
	
	confirmRollBack:orderUrl+"/medicalOrderRoolback/confirmRollBack",//下单人确认退货单
	
	reviewRollBack:orderUrl+"/medicalOrderRoolback/reviewRollBack",//复核人复核退货单
	
	getPatchManage:websiteURL+"/commonPatchManage/getPatchManage",// 获取最新补
	
}
export default httpApi