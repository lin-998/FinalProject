import {  getPatchManage } from '@/util/request.js';
// import axios from 'axios';
import Vue from 'vue';
import { Dialog } from 'uview-ui';
let baseUrl = 'https://tech.a6shop.net:8058/smartMedicalFile';
if(process.env.NODE_ENV === 'development') {
    // baseUrl = 'https://192.168.105.6/server';
    // baseUrl = 'https://tech.a6shop.net:8058/server';
    baseUrl = 'https://hqht.wljnpx.com/server';
}
export default baseUrl
export const Util = new class {
	checkEmpry(obj) {
		if (!obj)
			return null;
		let [arr, flag, arrKey, msg] = [Object.values(obj), true, Object.keys(obj), null];
		arr.forEach((item, index) => {
			if (flag)
				if (item == null || item == '' || item == ' ') {
					flag = false;
					switch (arrKey[index]) {
						case 'password_r':
							msg = '请确认登录密码！';
							break;
					}
				}
		})
		return msg;
	}

	
	

	checkEmpry(name) {
		var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
		if (arr = document.cookie.match(reg))
			return unescape(arr[2]);
		else
			return null;
	}
}
// https://tech.a6shop.net:8058/smartMedicalFile/file/attachment/2021-01-19/060b836e07784b4395fa1557ff40188f.apk
export const javaHb = new class {
	constructor() {
		this.appCheckAppVersion; //版本号变量[String]
		this.appCheckSystemType; //系统类型
		this.appCheckAppUrl = baseUrl + "/server/user/api/version/findNewVersion"; //检查App更新的请求地址
		this.appCheckWgtUrl = baseUrl + "sysconf/wgtVersion/findNewWgtVersion"; //检查补丁更新的请求地址
	}
	plusReady() {
		let that = this;   
		console.log(22) 
		plus.runtime.getProperty(plus.runtime.appid, function(inf) {
		console.log(33) 

			that.appCheckAppVersion = inf.version;
			console.log(that.appCheckAppVersion,1)
			console.log("start")
			uni.getSystemInfo({
			    success(res) {
			        console.log(res.platform);
							that.appCheckSystemType=res.platform
			    }
			});
			// that.appCheckSystemType = that.getCurrentSystem(); //系统类型
			console.log("end")
			that.checkFun(); // 更新方法
		});
	}   

	/**
 	* 版本更新
 	*/ 
	checkFun() {
		// {type: this.appCheckSystemType}
		// console.log(11111) 
		let staus=this.appCheckSystemType=='android'?0:1
		getPatchManage({device:staus}).then(res => {
			console.log(res)
			if(res.code ==  200) {
				this.checkJudge(res.data);
			} else {
				Dialog({ message: res.msg });
			}
		})
	}
	/**
	 * 版本更新判断,若版本一致,则检查是否有补丁更新,若版本不一致,则进行大版本更新
	 * 
	 * @param {Object} data 版本更新信息
	 */
	checkJudge(data) {
		if(this.appCheckSystemType) { // 系统类型 "安卓"或者"苹果"
			// var appData = data[this.appCheckSystemType]; //获取当前系统的数据信息
			var appData = data; //获取当前系统的数据信息
			if(appData == null) {
				return;
			}
			// //1、判断大版本更新
			// if(this.appCheckAppVersion.substr(0, 3) * 1 < appData.versionNum.substr(0, 3) * 1) {
			// 	console.log(1111111111)
			// 	// app.setVersionLocalStorage(appData.version);
			// 	this.checkAppFun(appData); //	大版本更新方法
			// 	return;
			// } else { //2、判断补丁更新`
			// console.log(222222222)
			// 	 //	补丁更新方法
			// 	return;
			// }
			this.checkWgtFun(appData);
		} else { //系统类型识别不了
			otherFun(data); // 手动下载
		}
	}

	/**
	 * 大版本更新
	 * 
	 * @param {Object} data	版本更新信息
	 */
	checkAppFun(data) {
		var apkUrl = data.apkUrl; //获取当前安装包的下载地址
		this.downApp(apkUrl); //执行App下载安装
		// var appCompel = data.compel; // 是否强制更新
		// var btn; //弹框按钮
		// if(appCompel == 1) { //	强制更新
		// 	btn = ['前往下载'];
		// } else {
		// 	btn = ['前往下载', '稍后下载'];
		// }
		// mui.confirm('发现有新版本可以升级!', '提示', btn, function(e) {
		// 	console.log(e.index)
		// 	if(e.index == 0) {
		// 		var appUrl = data.appUrl; //获取当前安装包的下载地址
		// 		downApp(appUrl); //执行App下载安装
		// 	} else {
		// 		if(appCompel == 1) {
		// 			plus.runtime.quit();
		// 		}
		// 	}
		// });
	}

	/**
	 * 
	 * 补丁更新
	 * @param {Object} data	版本更新信息
	 */
	checkWgtFun(data) {
		let that = this;
		// Base.findNewWgtVersion({}).then(data => {
			// if("200" == data.code) {
				// if(data.data) {
					let appCheckAppVersionNum=0;
					let versionNum=0
					let power=1
					data.versionNum.split(".").forEach((val,index)=>{
						if(index==0){power=100}else if(index==1){power=10}else{power=1}
						versionNum+=parseInt(val)*power
					})
					that.appCheckAppVersion.split(".").forEach((val,index)=>{
						if(index==0){power=100}else if(index==1){power=10}else{power=1}
						// console.log(parseInt(val))
						appCheckAppVersionNum+=parseInt(val)*power
					})
					console.log(appCheckAppVersionNum)
					console.log(versionNum)
					
					if(appCheckAppVersionNum < versionNum) {
						
						console.log(33)
						that.downWgt(data.patchUrl);
					}
				// } else {
				// 	return;
				// }
			// } else {
			// 	Dialog({ message: data.msg });
			// }
		// })
		// mui.ajax(that.appCheckWgtUrl, {
		// 	type: "GET", //HTTP请求类型
		// 	dataType: 'json', //服务器返回json格式数据
		// 	timeout: 10000, //超时时间设置为10秒；
		// 	success: function(data) {
		// 		// console.log(JSON.stringify(data));
		// 		if("200" == data.code) {
		// 			if(data.data) {
		// 				if(that.appCheckAppVersion.substr(0, 3) * 1 > data.data.wgtVersion.substr(0, 3) * 1) {
		// 					return;
		// 				}
		// 				if(that.appCheckAppVersion.replace(/\./g, "") * 1 >= data.data.wgtVersion.replace(/\./g, "") * 1) {
		// 					return;
		// 				}
		// 				if(that.appCheckAppVersion != data.data.wgtVersion && data.data.wgtVersion.split(".").pop() * 1 > that.appCheckAppVersion.substr(-1).split(".").pop() * 1) {
		// 					that.downWgt(data.data.wgtUrl);
		// 					// app.setVersionLocalStorage(data.data.wgtVersion);
		// 					// mui.confirm("发现有新版本可以升级!", "提示", "前往下载", "稍后下载", function(e) {
		// 					// 	if(e.index == 0) {
		// 					// 		app.openWin("mine/html/my/my_about_us.html", "mine/html/my/my_about_us.html", null, {
		// 					// 			data: data.data
		// 					// 		});
		// 					// 	}
		// 					// });
		// 				}
		// 			} else {
		// 				return;
		// 			}
		// 		} else {
		// 			mui.alert(data.msg);
		// 		}
		// 	},
		// 	error: function(xhr, type, errorThrown) {
		// 		//			console.log("网络异常，请检查网络状态");
		// 	}
		// })
	}
	/**
	 * 补丁下载，直接下载wgt文件
	 * @param {Object} wgtUrl	wgt文件补丁下载地址
	 */
	downWgt(wgtUrl) {
		let that = this;
		console.log(wgtUrl)
		var downloader = plus.downloader.createDownload(wgtUrl, {}, function(d, status) {
			if(status == 200) {
				
				that.installWgt(d.filename); // 安装wgt包
			} else {
				plus.nativeUI.alert('补丁下载失败');
			}
		});
		downloader.start();
	}

	/**
	 * 补丁升级安装
	 * @param {Object} path wgt文件存放路径
	 */
	installWgt(path) {
		console.log(path)
		// plus.nativeUI.showWaiting('补丁升级中...');
		
		plus.runtime.install(path, {}, function() {
			console.log(123)
			plus.nativeUI.closeWaiting();
			console.log(3)
			plus.nativeUI.alert('补丁升级成功！', function() {
				plus.runtime.restart();
			});
		}, function(e) {
			plus.nativeUI.closeWaiting();
			console.log(e,'eeeeee')
			plus.nativeUI.alert('补丁升级失败');
		});
	}
	/**
	 * 大版本更新，重新下载新版本App
	 * @param {Object} appUrl 新版本app下载地址
	 */
	downApp(appUrl) {
		plus.runtime.openURL(appUrl);
	}
	/**
 	* 获取当前系统类型
 	*/ 
	getCurrentSystem() {
		//是否为IOS
		// var isIos = mui.os.ios || mui.os.ipad || mui.os.iphone;
		var isIos = !!navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
		//是否为安卓
		// var isAndroid = mui.os.android;
		var isAndroid = navigator.userAgent.indexOf('Android') > -1 || navigator.userAgent.indexOf('Adr') > -1;
		if(isIos) {   
			return "2";
		} else if(isAndroid) {
			return "1";
		} else {
			return null; // 识别不了
		}
	}
}
