// import Url from 'httpUrl.js'
import { Utils } from '@/common/common.js'
export const myPomise = (pro) => {
	return new Promise((resolve, reject) => {
		const headers= {
			...pro.header,
			'X-Requested-Token': uni.getStorageSync('token')
		}
		
		uni.request({
			url: pro.url || "",
			data: pro.data || {},
			method: pro.method || "GET",
			header: headers ||{},
			success: (res) => {
				if(res.statusCode == 401){
					Utils.toast(res.data.msg)
					uni.removeStorageSync('userInfo')
					uni.removeStorageSync('token')
					uni.reLaunch({
						url:"/pages/login/login"
					})
				}
				resolve(res.data)
			},
			fail: (err) => {
				reject(err)
			}
		})
	})
};

// export default myPomise
