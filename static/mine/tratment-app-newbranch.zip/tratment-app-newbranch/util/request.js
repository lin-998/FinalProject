import {myPomise} from './httpApi.js'
import httpUrl from './httpUrl.js'
const header={
	'Content-Type': 'application/x-www-form-urlencoded'
}
// 登录
export const Login = (data) => {
	return myPomise({
		url: httpUrl.Login,
		data: data,
		method: "POST",
		header
	})
}
// 获取公钥
export const PublicK = (data) => {
	return myPomise({url: httpUrl.getPublicK,data})
}
// 获取注册验证码
export const getRegister = (data)=>{
	return myPomise({url:httpUrl.getRegister,data,})
}
//注册
export const Register = (data)=>{
	return myPomise({url:httpUrl.Register,data,method: "POST"})
}
//获取忘记密码验证码
export const getPassword = (data)=>{
	return myPomise({url:httpUrl.getPassword,data})
}
//找回密码
export const forgetPassword = (data)=>{
	return myPomise({url:httpUrl.forgetPassword,data,method: "POST",header})
}

//获取首页轮播图
export const getShuffling = (data)=>{
	return myPomise({url:httpUrl.getShuffling,data})
}

//获取关于我们
export const getOursList = (data)=>{
	return myPomise({url:httpUrl.getOursList,data})
}
//获取公告
export const getNotice = (data)=>{
	return myPomise({url:httpUrl.getNotice,data})
}
//获取资料信息
export const getInformationList = (data)=>{
	return myPomise({url:httpUrl.getInformationList,data})
}
//资料下载
export const getDownload = (data)=>{
	return myPomise({url:httpUrl.getDownload,data})
}

//获取所有商品类别
export const gateGorylist = (data)=>{
	return myPomise({url:httpUrl.gateGorylist,data})
}
//根据类别id获取子类别
export const getTreelist = (data)=>{
	return myPomise({url:httpUrl.getTreelist,data})
}
//模糊搜索商品
export const searchGoods = (data)=>{
	return myPomise({url:httpUrl.searchGoods,data})
}
//获取商品详情
export const viewGoods = (data)=>{
	return myPomise({url:httpUrl.viewGoods,data})
}

// 获取订单信息
export const getorderinfo=(data)=>{
	return myPomise({url:httpUrl.getorderinfo,data})
}
//相应审核人审核订单page页面
export const getcheckinfo=(data)=>{
	return myPomise({url:httpUrl.getcheckinfo,data})
}
// 查看详情----基本信息
export const getbaseorderinfo=(data)=>{
	return myPomise({url:httpUrl.getbaseorderinfo,data})
}
// 下单
export const overBooking=(data)=>{
	return myPomise({url:httpUrl.overBooking,data,method: "POST"})
}
//审核人员订单审核
export const checkorder=(data)=>{
	return myPomise({url:httpUrl.checkorder,data,method: "POST",header})
}
//查看详情----产品
export const getorderdetail=(data)=>{
	return myPomise({url:httpUrl.getorderdetail,data})
}

export const ridermanageinfo=(data)=>{
	return myPomise({url:httpUrl.ridermanageinfo,data})
}
//商家入驻申请
export const createAttachment = (data)=>{
	return myPomise({url:httpUrl.createAttachment,data ,method: "POST"})
}
//商家入驻申请结果
export const getResult = (data)=>{
	return myPomise({url:httpUrl.getResult,data})
}
//商家入驻再次申请
export const submitAgain = (data)=>{
	return myPomise({url:httpUrl.submitAgain,data ,method: "POST"})
}
//上传营业执照
export const uploadAttachment = (data)=>{
	return myPomise({url:httpUrl.uploadAttachment,data})
}
//删除营业执照
export const deleteAttachment = (data)=>{
	return myPomise({url:httpUrl.deleteAttachment,data ,method: "POST",header})
}
// 获取骑手
export const getrider=(data)=>{
	return myPomise({url:httpUrl.getrider,data })
}
//分配任务
export const distributionrider= (data)=>{
	return myPomise({url:httpUrl.distributionrider,data,method: "POST"})
}
//分配退单的任务
export const distributionReturnRider= (data)=>{
	return myPomise({url:httpUrl.distributionReturnRider,data,method: "POST"})
}
//商品加入已选
export const addselectshop = (data)=>{
	return myPomise({url:httpUrl.addselectshop,data,method: "POST"})
}
//删除已选
export const deleteselect=(data)=>{
	return myPomise({url:httpUrl.deleteselect,data,method: "POST"})
}
//编辑已选
export const editselect = (data)=>{
	return myPomise({url:httpUrl.editselect,data,method: "POST"})
}
//编辑已选---套餐(goodsID，specID,Times)
export const updateMeal = (data)=>{
	return myPomise({url:httpUrl.updateMeal,data,method: "POST"})
}
//查看已选
export const lookselect=(data)=>{
	return myPomise({url:httpUrl.lookselect,data })
}
//上传备注图片
export const uploadremark = (data)=>{
	return myPomise({url:httpUrl.uploadremark,data})
}
//订单取消----下单人（未审核的订单）
export const cancleorder = (data)=>{
	return myPomise({url:httpUrl.cancleorder,data ,method: "POST",header})
}
//删除已取消订单
export const deleteorder = (data)=>{
	return myPomise({url:httpUrl.deleteorder,data ,method: "POST",header})
}
//删除备注图片
export const deleteremark = (data)=>{
	return myPomise({url:httpUrl.deleteremark,data ,method: "POST",header})
}
//删除获取城市天气信息
export const weatherInfo = (data)=>{
	return myPomise({url:'https://restapi.amap.com/v3/weather/weatherInfo',data})
}
// 对应骑手看到的订单--派送中的和派送完成的
export const riderorderinfo=(data)=>{
	return myPomise({url:httpUrl.riderorderinfo,data})
}
//生成二维码丢到服务器
export const createQR = (data)=>{
	return myPomise({url:httpUrl.createQR,data ,method: "POST",header})
}
//下单人跟新状态---已完成,确定收货
export const confirmreceipt= (data)=>{
	return myPomise({url:httpUrl.confirmreceipt,data ,method: "POST",header})
}
//查看订单中的商品信息 -- 用于申请退货页面
export const returngoodsinfo=(data)=>{
	return myPomise({url:httpUrl.returngoodsinfo,data })
}
//创建退货订单
export const createRoolbackOrder= (data)=>{
	return myPomise({url:httpUrl.createRoolbackOrder,data ,method: "POST"})
}
//生成退货二维码丢到服务器
export const createRoolbackQR = (data)=>{
	return myPomise({url:httpUrl.createRoolbackQR,data ,method: "POST",header})
}
// 退货人退货page
export const getreturnorderinfo=(data)=>{
	return myPomise({url:httpUrl.getreturnorderinfo,data })
}
//  退货取消
export const canclereturnorder= (data)=>{
	return myPomise({url:httpUrl.canclereturnorder,data ,method: "POST",header})
}
// 删除订单----已经取消的
export const deletereturnorder= (data)=>{
	return myPomise({url:httpUrl.deletereturnorder,data ,method: "POST",header})
}
// 审核退货page
export const getreturncheckorder=(data)=>{
	return myPomise({url:httpUrl.getreturncheckorder,data })
}
// 退货查看详情----基本信息
export const getbsaereturnorderinfo=(data)=>{
	return myPomise({url:httpUrl.getbsaereturnorderinfo,data })
}
//  退货单--商品信息
export const getreturnordershopinfo=(data)=>{
	return myPomise({url:httpUrl.getreturnordershopinfo,data })
}
//  审核人员订单审核（正常订单的审核）--1审核通过5不
export const checkreturnorder= (data)=>{
	return myPomise({url:httpUrl.checkreturnorder,data ,method: "POST",header})
}
//骑手退货page
export const riderreturninfo=(data)=>{
	return myPomise({url:httpUrl.riderreturninfo,data })
}
// 骑手管理员退货pag
export const managereturninfo=(data)=>{
	return myPomise({url:httpUrl.managereturninfo,data })
}
//关于我们轮播图片
export const getOurShuffling=(data)=>{
	return myPomise({url:httpUrl.getOurShuffling,data })
}
//骑手确定取货
export const confirmPickupToRider= (data)=>{
	return myPomise({url:httpUrl.confirmPickupToRider,data ,method: "POST"})
}
//骑手管理员取消骑手分配
export const cancelPickupToRider= (data)=>{
	return myPomise({url:httpUrl.cancelPickupToRider,data ,method: "POST"})
}

//根据当前登录用户查询用户的所有地址
export const getAddressAll=(data)=>{
	return myPomise({url:httpUrl.getAddressAll,data})
}
// 再次下单 -- 已取消订单再次下单
export const createAgain= (data)=>{
	return myPomise({url:httpUrl.createAgain,data,method: "POST",header})
}

//获取第二级品牌列表
export const getMenuTwoList=(data)=>{
	return myPomise({url:httpUrl.getMenuTwoList,data })
}
//返回套餐商品树 ----status 0内部用户发布的产品1会员商家发布的产品
export const getTree=(data)=>{
	return myPomise({url:httpUrl.getTree,data })
}
//套餐商品的详情----详情
export const viewSetMeal=(data)=>{
	return myPomise({url:httpUrl.viewSetMeal,data })
}
//套餐加入已选
export const insertSetMeal=(data)=>{
	return myPomise({url:httpUrl.insertSetMeal,data })
}
//下单人确认退货单
export const confirmRollBack=(data)=>{
	return myPomise({url:httpUrl.confirmRollBack,data })
}
//复核人复核退货单
export const reviewRollBack=(data)=>{
	return myPomise({url:httpUrl.reviewRollBack,data })
}
// 获取最新补
export const getPatchManage=(data)=>{
	return myPomise({url:httpUrl.getPatchManage,data })
}

export const imageUpload=httpUrl.imageUpload